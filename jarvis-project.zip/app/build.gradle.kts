plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Versionsnummer wächst mit jedem GitHub-Build automatisch, damit Updates immer als neuer erkannt werden.
val runNumber = (System.getenv("GITHUB_RUN_NUMBER") ?: "0").toIntOrNull() ?: 0

android {
    namespace = "de.jarvis.assistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "de.jarvis.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = if (runNumber > 0) 100 + runNumber else 5
        versionName = if (runNumber > 0) "1.5.$runNumber" else "1.5"
    }
    // Feste Signatur: nur damit lassen sich neue APKs über die installierte App legen (Update ohne Deinstallation).
    // WICHTIG: Die Datei app/jarvis.jks darf nie gelöscht oder ausgetauscht werden.
    signingConfigs {
        create("jarvis") {
            storeFile = file("jarvis.jks")
            storePassword = "r4jr4EcyvfS7B8Ib4lng5uc9"
            keyAlias = "jarvis"
            keyPassword = "r4jr4EcyvfS7B8Ib4lng5uc9"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("jarvis") }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("jarvis")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("ai.picovoice:porcupine-android:3.0.+")
}
