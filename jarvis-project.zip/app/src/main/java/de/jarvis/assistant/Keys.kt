package de.jarvis.assistant

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.util.UUID

object Provider {
    const val GEMINI = "gemini"
    const val NVIDIA = "nvidia"
    const val CUSTOM = "custom"
    val ALL = listOf(GEMINI, NVIDIA, CUSTOM)

    fun label(p: String) = when (p) {
        NVIDIA -> "NVIDIA"
        CUSTOM -> "Eigene URL"
        else -> "Gemini"
    }

    fun defaultModel(p: String) = when (p) {
        NVIDIA -> "meta/llama-3.3-70b-instruct"
        CUSTOM -> ""
        else -> ""
    }

    fun hint(p: String) = when (p) {
        NVIDIA -> "Kostenloser Schlüssel auf build.nvidia.com (beginnt mit nvapi-). Nur Text, kein Bildschirmfoto."
        CUSTOM -> "Jeder Dienst mit OpenAI-kompatibler Schnittstelle (zum Beispiel Groq, OpenRouter). URL bis /v1 eintragen."
        else -> "Kostenloser Schlüssel auf aistudio.google.com/apikey. Nur Gemini kann den Bildschirm ansehen."
    }
}

/** Eine benannte Schlüssel-Ablage. Die Reihenfolge in der Liste ist die Priorität beim automatischen Wechsel. */
data class KeyEntry(
    val name: String,
    val provider: String,
    val key: String,
    val model: String = "",
    val url: String = "",
    val id: String = UUID.randomUUID().toString()
) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("name", name).put("provider", provider)
        .put("key", key).put("model", model).put("url", url)

    companion object {
        fun fromJson(o: JSONObject) = KeyEntry(
            o.optString("name"), o.optString("provider", Provider.GEMINI), o.optString("key"),
            o.optString("model"), o.optString("url"), o.optString("id").ifBlank { UUID.randomUUID().toString() }
        )
    }
}

@Composable
fun KeyEditor(entries: SnapshotStateList<KeyEntry>) {
    Text("API-Schlüssel", fontSize = 13.sp, color = Gold)
    Text(
        "Jede Ablage hat einen Namen. Die Reihenfolge ist die Priorität: Fällt der erste aus oder ist sein Kontingent leer, " +
            "nimmt JARVIS automatisch den nächsten (auch bei einem anderen Anbieter).",
        fontSize = 12.sp
    )
    Spacer(Modifier.height(6.dp))
    entries.forEachIndexed { i, e ->
        key(e.id) {
            val shape = RoundedCornerShape(6.dp)
            Column(
                Modifier.fillMaxWidth().padding(vertical = 4.dp).border(1.dp, Cyan.copy(alpha = 0.35f), shape).padding(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = e.name, onValueChange = { entries[i] = e.copy(name = it) },
                        label = { Text("Name") }, singleLine = true, modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { if (i > 0) { val x = entries[i]; entries[i] = entries[i - 1]; entries[i - 1] = x } }) { Text("▲", color = Gold) }
                    TextButton(onClick = { if (i < entries.size - 1) { val x = entries[i]; entries[i] = entries[i + 1]; entries[i + 1] = x } }) { Text("▼", color = Gold) }
                    TextButton(onClick = { entries.removeAt(i) }) { Text("✕", color = Gold) }
                }
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Provider.ALL.forEach { p ->
                        HudButton(Provider.label(p), filled = e.provider == p) { entries[i] = e.copy(provider = p) }
                    }
                }
                Spacer(Modifier.height(4.dp))
                OutlinedTextField(
                    value = e.key, onValueChange = { entries[i] = e.copy(key = it.trim()) },
                    label = { Text("Schlüssel") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    visualTransformation = PasswordVisualTransformation()
                )
                if (e.provider != Provider.GEMINI) {
                    OutlinedTextField(
                        value = e.model, onValueChange = { entries[i] = e.copy(model = it.trim()) },
                        label = { Text("Modell") },
                        placeholder = { Text(Provider.defaultModel(e.provider).ifEmpty { "z. B. llama-3.3-70b-versatile" }) },
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                }
                if (e.provider == Provider.CUSTOM) {
                    OutlinedTextField(
                        value = e.url, onValueChange = { entries[i] = e.copy(url = it.trim()) },
                        label = { Text("URL (z. B. https://api.groq.com/openai/v1)") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                }
                Text(Provider.hint(e.provider), fontSize = 11.sp, color = Color(0xFFE6F7FF).copy(alpha = 0.6f))
            }
        }
    }
    Spacer(Modifier.height(4.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Provider.ALL.forEach { p ->
            HudButton("＋ " + Provider.label(p).uppercase(), accent = Gold) {
                val n = entries.count { it.provider == p } + 1
                entries.add(KeyEntry(name = "${Provider.label(p)} $n", provider = p, key = "", model = Provider.defaultModel(p)))
            }
        }
    }
}
