package de.jarvis.assistant

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Fact(
    val id: Long,
    val text: String,
    val cat: String,
    /** "manual" = von dir eingetragen oder diktiert, "auto" = aus Gesprächen gelernt. */
    val source: String,
    val created: Long,
    val updated: Long
)

/**
 * Das zentrale JARVIS-Gehirn: Wissen über dich (Lernprofil), frühere Gespräche und die Dashboard-Daten
 * werden hier zu einem Kontext zusammengeführt, den alle KI-Aufrufe bekommen.
 * Alles ist lokal gespeichert und von dir bearbeitbar. Beim Fragen an die KI wird der passende Ausschnitt mitgeschickt.
 */
object Brain {
    const val MEMORY = "memory"
    val CATS = listOf("Person", "Vorlieben", "Gewohnheiten", "Stil", "Sonstiges")
    private const val MAX_FACTS = 150

    val facts = mutableStateListOf<Fact>()

    /** Zuletzt automatisch Gelerntes (für eine kurze Anzeige im Chat). */
    var lastLearned by mutableStateOf("")
        private set

    /** Die letzte Nutzer-Nachricht; dient zum Heraussuchen passender früherer Gespräche. */
    @Volatile
    var query = ""

    private var seq = 0L
    private var loaded = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val mutex = Mutex()
    private fun newId(): Long = System.currentTimeMillis() * 100 + (seq++ % 100)

    fun init() {
        if (loaded) return
        loaded = true
        load()
    }

    fun load() {
        facts.clear()
        val a = Store.read(MEMORY)
        val list = ArrayList<Fact>()
        for (i in 0 until a.length()) {
            try {
                val o = a.getJSONObject(i)
                list.add(
                    Fact(
                        o.getLong("id"), o.getString("text"), o.optString("cat", "Sonstiges"),
                        o.optString("src", "manual"), o.optLong("created"), o.optLong("updated")
                    )
                )
            } catch (_: Exception) {
            }
        }
        facts.addAll(list.sortedByDescending { it.updated })
    }

    private fun save() {
        val a = JSONArray()
        facts.forEach {
            a.put(
                JSONObject().put("id", it.id).put("text", it.text).put("cat", it.cat).put("src", it.source)
                    .put("created", it.created).put("updated", it.updated)
            )
        }
        Store.write(MEMORY, a)
    }

    // ---------------------------------------------------------------- Ähnlichkeit

    private val stop = setOf(
        "und", "oder", "aber", "dass", "nicht", "eine", "einen", "einem", "einer", "eines", "der", "die", "das", "dem", "den",
        "des", "ein", "ist", "sind", "war", "waren", "hat", "habe", "haben", "hast", "wird", "werden", "kann", "kannst",
        "soll", "sollst", "bitte", "dann", "auch", "noch", "schon", "wieder", "mehr", "sehr", "mein", "meine", "meinen",
        "meinem", "meiner", "dein", "deine", "wenn", "weil", "wie", "was", "wer", "wann", "wo", "warum", "jarvis", "sir",
        "über", "für", "mit", "von", "zum", "zur", "bei", "nach", "mir", "dir", "mich", "dich", "ich", "du", "wir", "ihr",
        "sie", "es", "mal", "gern", "gerne", "heute", "morgen", "kannst", "willst", "möchte", "möchtest"
    )

    private fun words(s: String): Set<String> =
        Regex("[\\p{L}\\p{N}]+").findAll(s.lowercase(Locale.GERMAN)).map { it.value }
            .filter { it.length >= 3 && it !in stop }.toSet()

    /** Überlappungs-Koeffizient: 1.0 = alle Wörter der kürzeren Menge kommen auch in der anderen vor. */
    private fun sim(a: Set<String>, b: Set<String>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        return a.intersect(b).size.toDouble() / minOf(a.size, b.size)
    }

    // ---------------------------------------------------------------- Bearbeiten

    fun add(text: String, cat: String = "Sonstiges", source: String = "manual"): Fact? {
        val t = text.trim().trim('.', ' ').take(200)
        if (t.length < 3) return null
        val w = words(t)
        val now = System.currentTimeMillis()
        val c = if (cat in CATS) cat else "Sonstiges"
        val dup = facts.indexOfFirst { it.text.equals(t, ignoreCase = true) || (w.size >= 2 && sim(w, words(it.text)) >= 0.8) }
        if (dup >= 0) {
            val old = facts[dup]
            // Von dir eingetragene Einträge werden von automatisch Gelerntem nicht überschrieben.
            val upd = if (old.source == "manual" && source == "auto") old.copy(updated = now)
            else old.copy(text = t, cat = c, updated = now)
            facts.removeAt(dup)
            facts.add(0, upd)
            save()
            return upd
        }
        val f = Fact(newId(), t, c, source, now, now)
        facts.add(0, f)
        while (facts.size > MAX_FACTS) {
            val idx = facts.indexOfLast { it.source == "auto" }
            facts.removeAt(if (idx >= 0) idx else facts.lastIndex)
        }
        save()
        return f
    }

    fun edit(id: Long, text: String) {
        val i = facts.indexOfFirst { it.id == id }
        val t = text.trim().trim('.', ' ').take(200)
        if (i < 0 || t.length < 3) return
        facts[i] = facts[i].copy(text = t, source = "manual", updated = System.currentTimeMillis())
        save()
    }

    fun setCat(id: Long, cat: String) {
        val i = facts.indexOfFirst { it.id == id }
        if (i >= 0 && cat in CATS) {
            facts[i] = facts[i].copy(cat = cat, updated = System.currentTimeMillis())
            save()
        }
    }

    fun remove(id: Long) {
        if (facts.removeAll { it.id == id }) save()
    }

    fun clear() {
        facts.clear()
        save()
    }

    fun clearLearned() {
        lastLearned = ""
    }

    /** Sucht den Eintrag, der am besten zu einer Beschreibung passt (für „Vergiss …“). */
    fun findByQuery(q: String): Fact? {
        val w = words(q)
        if (w.isEmpty()) return null
        var best: Fact? = null
        var bs = 0.0
        for (f in facts) {
            val s = sim(w, words(f.text))
            if (s > bs) {
                bs = s
                best = f
            }
        }
        return if (bs >= 0.5) best else null
    }

    // ---------------------------------------------------------------- Kontext für die KI

    /** Dein Lernprofil als kompakter Text für die System-Anweisung. */
    fun block(): String {
        if (facts.isEmpty()) return ""
        val sb = StringBuilder("Das weißt du über den Nutzer (er kann es jederzeit bearbeiten): ")
        for (c in CATS) {
            val l = facts.filter { it.cat == c }.take(12)
            if (l.isNotEmpty()) sb.append(c).append(": ").append(l.joinToString("; ") { it.text }).append(". ")
            if (sb.length > 1800) break
        }
        sb.append(
            "Nutze dieses Wissen natürlich und unaufdringlich. Zähle es nicht auf und erwähne nicht, dass du es gespeichert " +
                "hast, außer der Nutzer fragt danach. Einträge der Kategorie Stil sind Wünsche an deine Ausdrucksweise und gelten " +
                "immer. Widerspricht der Nutzer einem Eintrag, gilt seine aktuelle Aussage. "
        )
        return sb.toString()
    }

    private val fmtDay = SimpleDateFormat("d.M.", Locale.GERMANY)

    private class Hit(val chat: Chat, val score: Int, val idx: Int)

    /** Passende Ausschnitte aus früheren Gesprächen (einfache Stichwort-Suche, nur lokal). */
    fun related(text: String): String {
        if (!Prefs.useHistory) return ""
        val q = words(text)
        if (q.isEmpty()) return ""
        val hits = ArrayList<Hit>()
        for (c in Chats.chats) {
            if (c.id == Chats.currentId) continue
            var bestIdx = -1
            var bestScore = 0
            val seen = HashSet<String>()
            for ((i, m) in c.msgs.withIndex()) {
                if (!m.fromUser) continue
                val ov = words(m.text).intersect(q)
                seen.addAll(ov)
                if (ov.size > bestScore) {
                    bestScore = ov.size
                    bestIdx = i
                }
            }
            if (bestIdx >= 0 && (seen.size >= 2 || seen.any { it.length >= 7 })) hits.add(Hit(c, seen.size, bestIdx))
        }
        if (hits.isEmpty()) return ""
        val sb = StringBuilder("Früher besprochen (nur nutzen, wenn es zur Frage passt): ")
        for (h in hits.sortedWith(compareByDescending<Hit> { it.score }.thenByDescending { it.chat.updated }).take(2)) {
            val u = h.chat.msgs[h.idx].text.replace("\n", " ").take(140)
            val a = h.chat.msgs.getOrNull(h.idx + 1)?.takeIf { !it.fromUser }?.text?.replace("\n", " ")?.take(140)
            sb.append("[").append(fmtDay.format(Date(h.chat.updated))).append("] Nutzer: ").append(u)
            if (a != null) sb.append(" → JARVIS: ").append(a)
            sb.append(" ")
        }
        return sb.toString().take(700)
    }

    /** Alles, was die KI über dich wissen darf: Lernprofil plus passende frühere Gespräche. */
    fun context(): String = block() + related(query)

    /** Für „Was weißt du über mich?“ per Sprache. */
    fun spoken(anrede: String): String {
        if (facts.isEmpty()) {
            return "Ich habe noch nichts über dich gespeichert, $anrede. Sage zum Beispiel: Merk dir, dass ich Kaffee ohne Milch trinke."
        }
        val top = facts.take(5).joinToString(". ") { it.text.trim('.') }
        return "Ich habe ${facts.size} Dinge gespeichert, $anrede. Die neuesten: $top. Alles Weitere findest du im Dashboard unter Gedächtnis."
    }

    // ---------------------------------------------------------------- Lernen aus Gesprächen

    private val learnRe = Regex(
        "(ich bin|ich heiße|ich heisse|mein name|nenn mich|nenne mich|ich habe|ich hab |ich mag|ich liebe|ich hasse|" +
            "ich esse|ich trinke|ich wohne|ich lebe|ich arbeite|ich studiere|ich spiele|ich höre|ich fahre|ich brauche|" +
            "ich bevorzuge|mein |meine |meinen |meinem |meiner |immer|nie |niemals|normalerweise|meistens|morgens|abends|" +
            "am liebsten|lieblings|merk dir|merke dir|vergiss|nicht mehr|stattdessen|ich meinte|nein,|falsch|korrigier|" +
            "besser wäre|kürzer|ausführlicher|duze|siez|rede|sprich)",
        RegexOption.IGNORE_CASE
    )
    private val fixRe = Regex("(vergiss|nicht mehr|stimmt nicht|falsch|korrigier|stattdessen|ich meinte)", RegexOption.IGNORE_CASE)
    private val sensitive = Regex("(passwort|kennwort|\\bpin\\b|iban|kreditkarte|kontonummer|\\d{6,})", RegexOption.IGNORE_CASE)

    private const val LEARN_SYS =
        "Du bist das Gedächtnismodul eines Sprachassistenten. Entscheide, ob die Nachricht des Nutzers etwas DAUERHAFT " +
            "Nützliches über ihn enthält: Person (Name, Wohnort, Beruf, Familie), Vorlieben (Essen, Musik, Spiele, Marken), " +
            "Gewohnheiten und Routinen (Zeiten, Abläufe), Stil-Wünsche an den Assistenten (Länge, Ton, Anrede, Ausdrucksweise) " +
            "oder eine Korrektur an dem Assistenten. Speichere NICHT: Einmaliges (heutige Termine, Wetter, einzelne Aufgaben), " +
            "Fragen, Smalltalk, Sensibles (Passwörter, PINs, Kontodaten, Gesundheitsdiagnosen, Adressen, Telefonnummern). " +
            "Formuliere jeden Eintrag als kurzen deutschen Satz über den Nutzer, ohne ihn \"der Nutzer\" zu nennen, zum Beispiel " +
            "\"Wohnt in Hamburg.\" oder \"Trinkt Kaffee ohne Milch.\" oder \"Mag kurze Antworten.\". " +
            "Widerspricht die Nachricht einem vorhandenen Eintrag, nenne dessen id in remove und gib den neuen Eintrag in add. " +
            "Antworte NUR mit JSON: {\"add\":[{\"text\":\"...\",\"cat\":\"Person|Vorlieben|Gewohnheiten|Stil|Sonstiges\"}]," +
            "\"remove\":[123]}. Gibt es nichts zu speichern: {\"add\":[],\"remove\":[]}. Höchstens 3 Einträge."

    private fun parseJson(raw: String): JSONObject? {
        val clean = raw.replace(Regex("```(?:json)?"), "").trim()
        return try {
            JSONObject(clean)
        } catch (_: Exception) {
            val a = clean.indexOf('{')
            val b = clean.lastIndexOf('}')
            if (a >= 0 && b > a) try { JSONObject(clean.substring(a, b + 1)) } catch (_: Exception) { null } else null
        }
    }

    fun looksLearnable(t: String): Boolean = t.length in 12..600 && learnRe.containsMatchIn(t)

    /** Wird nach jeder Antwort von JARVIS aufgerufen. Lernt nur, wenn es danach aussieht und das Lernen an ist. */
    fun noteTurn(user: String, reply: String) {
        if (!Prefs.autoLearn || !AiActions.available() || !looksLearnable(user)) return
        scope.launch {
            mutex.withLock {
                try {
                    learn(user, reply)
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                }
            }
        }
    }

    private suspend fun learn(user: String, reply: String) {
        val existing = facts.take(60).joinToString("\n") {
            "[${it.id}] ${it.text} (${it.cat}, ${if (it.source == "auto") "gelernt" else "vom Nutzer"})"
        }.ifBlank { "(keine)" }
        val raw = GeminiClient.generate(
            LEARN_SYS,
            "Vorhandene Einträge:\n$existing\n\nNachricht des Nutzers: ${user.take(500)}\nAntwort des Assistenten: ${reply.take(300)}",
            null, true, true
        )
        val o = parseJson(raw) ?: return
        val allowManual = fixRe.containsMatchIn(user)
        val rems = o.optJSONArray("remove")
        if (rems != null) {
            for (i in 0 until rems.length()) {
                val id = rems.optLong(i)
                val f = facts.firstOrNull { it.id == id } ?: continue
                if (f.source == "auto" || allowManual) facts.remove(f)
            }
        }
        var firstNew = ""
        val adds = o.optJSONArray("add")
        if (adds != null) {
            for (i in 0 until minOf(adds.length(), 3)) {
                val x = adds.optJSONObject(i) ?: continue
                val t = x.optString("text").trim()
                if (t.length < 4 || sensitive.containsMatchIn(t)) continue
                val f = add(t, x.optString("cat"), "auto")
                if (f != null && firstNew.isEmpty()) firstNew = f.text
            }
        }
        save()
        if (firstNew.isNotEmpty()) lastLearned = firstNew
    }
}
