package de.jarvis.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import android.content.Intent
import java.util.Date
import java.util.Locale

/**
 * KI-Befehlserkennung als Auffangnetz: Was die festen Muster in MiniVoice nicht erkennen
 * („Kannst du mir morgen früh einen Termin beim Zahnarzt machen?“), übersetzt Gemini in Aktionen.
 * Ausgeführt werden die Aktionen von der App selbst; die Bestätigung stammt aus dem echten Ergebnis, nicht von der KI.
 */
object AiActions {
    /** Mit Gemini-Schlüssel versteht die KI jeden Satz. Ohne Schlüssel gelten nur die festen Muster. */
    fun available(): Boolean = Prefs.keyEntries.any { it.key.isNotBlank() }

    private val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.GERMANY)

    private fun system(): String {
        val now = SimpleDateFormat("EEEE, d. MMMM yyyy, HH:mm 'Uhr'", Locale.GERMANY).format(Date())
        val title = Prefs.title.ifBlank { "Sir" }
        return "Du bist die Befehlserkennung von J.A.R.V.I.S., einem deutschen Sprachassistenten. Jetzt ist $now. " +
            "Wandle die Äußerung in Aktionen für die App um oder beantworte sie. Antworte NUR mit JSON der Form " +
            "{\"actions\":[...],\"say\":\"...\"}. Erlaubte Aktionen (Feld type):\n" +
            "add_event {title, start:\"yyyy-MM-ddTHH:mm\"}: Termin in den Kalender\n" +
            "move_event {query, start:\"yyyy-MM-ddTHH:mm\"}: Termin verschieben\n" +
            "delete_event {query}\n" +
            "set_alarm {time:\"HH:mm\"}: Wecker stellen\n" +
            "set_timer {seconds:Zahl}\n" +
            "add_reminder {text, at:\"yyyy-MM-ddTHH:mm\"}\n" +
            "delete_reminder {query}\n" +
            "add_note {text}\n" +
            "delete_note {query}  (query leer = letzte Notiz, \"*\" = alle)\n" +
            "add_todo {text}\n" +
            "complete_todo {query}\n" +
            "delete_todo {query}\n" +
            "weather {city}: Wetter ansagen (city leer = Standardort)\n" +
            "news {category}: Nachrichten vorlesen (Top, Gaming, Technik, Sport, Wirtschaft, Politik, Wissenschaft)\n" +
            "Regeln: Zeitpunkte liegen in der Zukunft und werden aus Datum und Uhrzeit von jetzt berechnet. " +
            "Ein Termin ohne Uhrzeit bekommt 09:00. Fehlt eine nötige Angabe (z. B. die Uhrzeit beim Wecker), " +
            "gib keine Aktion und frage in \"say\" kurz nach. Bei Aktionen lässt du \"say\" leer, die App bestätigt selbst. " +
            "Ist die Äußerung keine App-Aktion, sondern eine Frage oder Unterhaltung, gib actions als leere Liste und " +
            "antworte in \"say\" als J.A.R.V.I.S. (gepflegter Butler-Ton, Anrede \"$title\", höchstens drei kurze Sätze, " +
            "kein Markdown, keine Emojis). Fragen zu gespeicherten Daten beantwortest du aus diesen DATEN: ${MiniData.summary()} ${Memory.context()}"
    }

    private fun parseJson(raw: String): JSONObject? {
        val clean = raw.replace(Regex("```(?:json)?"), "").trim()
        return try {
            JSONObject(clean)
        } catch (_: Exception) {
            val a = clean.indexOf('{')
            val b = clean.lastIndexOf('}')
            if (a >= 0 && b > a) try { JSONObject(clean.substring(a, b + 1)) } catch (_: Exception) { null } else null
        }
    }

    private fun time(s: String): Long? = try {
        iso.parse(s.trim().take(16))?.time
    } catch (_: Exception) {
        null
    }

    /** Liefert null, wenn die Antwort der KI unbrauchbar war (dann antwortet der normale Chat). */
    suspend fun run(text: String): MiniResult? {
        val raw = GeminiClient.generate(system(), text, null, true)
        val o = parseJson(raw) ?: return null
        val acts = o.optJSONArray("actions") ?: JSONArray()
        val say = o.optString("say").trim().let { if (it == "null") "" else it }
        if (acts.length() == 0) return if (say.isNotEmpty()) MiniResult(reply = say) else null

        val a = Prefs.title.ifBlank { "Sir" }
        val out = ArrayList<String>()
        var intent: Intent? = null
        var intentOk: String? = null

        for (i in 0 until acts.length()) {
            val x = acts.optJSONObject(i) ?: continue
            val q = x.optString("query").trim()
            when (x.optString("type")) {
                "add_event" -> {
                    val ms = time(x.optString("start"))
                    val title = MiniVoice.cap(x.optString("title").ifBlank { "Termin" })
                    if (ms == null) out.add("Für den Termin „$title“ fehlt mir die Zeit.")
                    else {
                        MiniData.addEvent(title, ms)
                        out.add("Eingetragen: $title, ${MiniVoice.relDay(ms)}.")
                    }
                }
                "move_event" -> {
                    val ms = time(x.optString("start"))
                    val e = MiniVoice.pick(MiniData.events.items, q) { it.title }
                    if (e == null || ms == null) out.add("Diesen Termin habe ich nicht gefunden, $a.")
                    else {
                        MiniData.editEvent(e.id, e.title, ms)
                        out.add("Der Termin „${e.title}“ ist jetzt ${MiniVoice.relDay(ms)}.")
                    }
                }
                "delete_event" -> {
                    val e = MiniVoice.pick(MiniData.events.items, q) { it.title }
                    if (e == null) out.add("Diesen Termin habe ich nicht gefunden.")
                    else {
                        MiniData.delEvent(e.id)
                        out.add("Der Termin „${e.title}“ ist gelöscht.")
                    }
                }
                "set_alarm" -> {
                    val p = x.optString("time").split(":")
                    val h = p.getOrNull(0)?.trim()?.toIntOrNull()
                    val m = p.getOrNull(1)?.trim()?.toIntOrNull() ?: 0
                    if (h == null || h !in 0..23 || m !in 0..59) out.add("Für den Wecker fehlt mir die Uhrzeit.")
                    else if (intent != null) out.add("Pro Befehl stelle ich nur einen Wecker oder Timer, $a.")
                    else {
                        intent = MiniVoice.alarmIntent(h, m)
                        intentOk = "Der Wecker ist auf ${"%02d:%02d".format(h, m)} Uhr gestellt, $a."
                    }
                }
                "set_timer" -> {
                    val secs = x.optInt("seconds", 0)
                    if (secs <= 0) out.add("Wie lange soll der Timer laufen?")
                    else if (intent != null) out.add("Pro Befehl stelle ich nur einen Wecker oder Timer, $a.")
                    else {
                        intent = MiniVoice.timerIntent(secs)
                        intentOk = "Der Timer läuft: ${MiniVoice.timerText(secs)}, $a."
                    }
                }
                "add_reminder" -> {
                    val ms = time(x.optString("at"))
                    val t = MiniVoice.cap(x.optString("text").ifBlank { "Erinnerung" })
                    if (ms == null || ms <= System.currentTimeMillis()) out.add("Für die Erinnerung brauche ich einen Zeitpunkt in der Zukunft.")
                    else {
                        MiniData.addReminder(t, ms)
                        out.add("Ich erinnere dich ${MiniVoice.relDay(ms)}: $t.")
                    }
                }
                "delete_reminder" -> {
                    val r = MiniVoice.pick(MiniData.reminders.items, q) { it.text }
                    if (r == null) out.add("Diese Erinnerung habe ich nicht gefunden.")
                    else {
                        MiniData.delReminder(r.id)
                        out.add("Die Erinnerung „${r.text}“ ist gelöscht.")
                    }
                }
                "add_note" -> {
                    val t = x.optString("text").trim()
                    if (t.isNotEmpty()) {
                        MiniData.addNote(MiniVoice.cap(t))
                        out.add("Notiert.")
                    }
                }
                "delete_note" -> {
                    val items = MiniData.notes.items
                    if (q == "*") {
                        val n = items.size
                        items.toList().forEach { MiniData.delNote(it.id) }
                        out.add(if (n == 0) "Es gab keine Notizen." else "Alle $n Notizen sind gelöscht.")
                    } else {
                        val n = if (q.isEmpty()) items.lastOrNull() else MiniVoice.pick(items, q) { it.text }
                        if (n == null) out.add("Diese Notiz habe ich nicht gefunden.")
                        else {
                            MiniData.delNote(n.id)
                            out.add("Die Notiz ist gelöscht.")
                        }
                    }
                }
                "add_todo" -> {
                    val t = x.optString("text").trim()
                    if (t.isNotEmpty()) {
                        MiniData.addTodo(MiniVoice.cap(t))
                        out.add("„${MiniVoice.cap(t)}“ steht auf der Liste.")
                    }
                }
                "complete_todo" -> {
                    val t = MiniVoice.pick(MiniData.todos.items.filter { !it.done }, q) { it.text }
                    if (t == null) out.add("Diese offene Aufgabe habe ich nicht gefunden.")
                    else {
                        MiniData.setTodoDone(t.id, true)
                        out.add("Erledigt: ${t.text}.")
                    }
                }
                "weather" -> out.add(Weather.speak(x.optString("city").trim().let { c -> if (c.isEmpty() || c == "null") Prefs.city else c }))
                "news" -> out.add(News.speak(News.categoryIn(x.optString("category"))))
                "delete_todo" -> {
                    val t = MiniVoice.pick(MiniData.todos.items, q) { it.text }
                    if (t == null) out.add("Diese Aufgabe habe ich nicht gefunden.")
                    else {
                        MiniData.delTodo(t.id)
                        out.add("Die Aufgabe „${t.text}“ ist gelöscht.")
                    }
                }
            }
        }
        if (out.isEmpty() && intent == null) return if (say.isNotEmpty()) MiniResult(reply = say) else null
        return MiniResult(reply = out.joinToString(" ").ifBlank { null }, intent = intent, intentOk = intentOk)
    }
}
