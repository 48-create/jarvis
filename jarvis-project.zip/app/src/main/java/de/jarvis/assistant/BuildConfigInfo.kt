package de.jarvis.assistant

import android.content.Context

object BuildConfigInfo {
    fun version(ctx: Context): String = try {
        val i = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        "${i.versionName} (${if (android.os.Build.VERSION.SDK_INT >= 28) i.longVersionCode else @Suppress("DEPRECATION") i.versionCode.toLong()})"
    } catch (e: Exception) {
        "?"
    }
}
