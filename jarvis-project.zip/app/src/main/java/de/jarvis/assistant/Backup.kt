package de.jarvis.assistant

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import org.json.JSONObject
import java.io.IOException

/**
 * Komplett-Sicherung: alle Einstellungen (API-Schlüssel, Modellnamen, Wetter-Ort, Stimme, Anrede, Dashboard-Reihenfolge,
 * Verbrauch …) plus alle Daten (Notizen, Aufgaben, Termine, Erinnerungen, Chats, Projekte).
 * ACHTUNG: Die Datei enthält deine API-Schlüssel im Klartext. Nicht weitergeben.
 */
object Backup {
    private const val VERSION = 2

    fun build(): String {
        val o = JSONObject().put("app", "JARVIS").put("version", VERSION).put("exported", System.currentTimeMillis())
        o.put("prefs", Prefs.exportAll())
        val data = JSONObject()
        for (n in Store.ALL) data.put(n, Store.read(n))
        o.put("data", data)
        return o.toString(2)
    }

    /** Stellt eine Sicherung wieder her (auch das ältere Format mit nur Mini-App-Daten). */
    fun restore(json: String): String {
        val o = JSONObject(json)
        if (o.optString("app") != "JARVIS") throw Exception("Das ist keine JARVIS-Sicherung.")
        var parts = 0
        o.optJSONObject("prefs")?.let {
            Prefs.importAll(it); parts++
        }
        val data = o.optJSONObject("data")
        for (name in Store.ALL) {
            val a = data?.optJSONArray(name) ?: o.optJSONArray(name) ?: continue
            Store.write(name, a)
            parts++
        }
        MiniData.reload()
        MiniData.rescheduleAll()
        Chats.load()
        Memory.load()
        Chats.startNew(0L)
        JarvisEngine.onSettingsChanged()
        return "Wiederhergestellt: $parts Bereiche (Einstellungen, Schlüssel, Notizen, Aufgaben, Termine, Erinnerungen, Chats, Projekte, Gedächtnis)."
    }

    /** Schreibt die Sicherung in den gewählten Ordner (überlebt auch eine Deinstallation der App). Fehler werden verschluckt. */
    fun auto(ctx: Context): Boolean {
        val tree = Prefs.backupTree
        if (tree.isBlank()) return false
        return try {
            val resolver = ctx.contentResolver
            val bytes = build().toByteArray(Charsets.UTF_8)
            fun write(uri: Uri) {
                val out = resolver.openOutputStream(uri, "wt") ?: throw IOException("kein Zugriff")
                out.use { it.write(bytes) }
            }
            val doc = Prefs.backupDoc
            if (doc.isNotBlank()) {
                try {
                    write(Uri.parse(doc))
                    return true
                } catch (_: Exception) {
                    Prefs.backupDoc = ""
                }
            }
            val treeUri = Uri.parse(tree)
            val parent = DocumentsContract.buildDocumentUriUsingTree(treeUri, DocumentsContract.getTreeDocumentId(treeUri))
            val created = DocumentsContract.createDocument(resolver, parent, "application/json", "jarvis-sicherung-auto.json")
                ?: return false
            Prefs.backupDoc = created.toString()
            write(created)
            true
        } catch (e: Exception) {
            false
        }
    }
}
