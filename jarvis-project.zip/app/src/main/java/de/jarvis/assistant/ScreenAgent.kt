package de.jarvis.assistant

import android.graphics.Bitmap
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume

/** Bedient das Handy Schritt für Schritt: Bildschirm lesen, KI fragt nach der nächsten Aktion, Aktion ausführen. */
object ScreenAgent {
    private const val MAX_STEPS = 12

    private val risky = Regex(
        "sende|senden|abschicken|bezahl|zahlen|kaufen|bestell|buchen|lösch|entfern|überweis|abonnier|" +
            "\\bpay\\b|\\bbuy\\b|delete|\\bsend\\b|order|purchase|remove|subscribe",
        RegexOption.IGNORE_CASE
    )
    private val blockedPkg = Regex(
        "bank|paypal|wallet|sparkasse|n26|revolut|authenticator|keepass|bitwarden|1password|lastpass|passwor",
        RegexOption.IGNORE_CASE
    )

    private const val SYS = """Du steuerst ein Android-Handy für den Nutzer, Schritt für Schritt. Du bekommst das Ziel, die bisherigen Schritte und eine Liste der sichtbaren Bedienelemente mit Nummern in eckigen Klammern. Antworte NUR mit einem JSON-Objekt mit genau einer Aktion. Erlaubte Aktionen: {"action":"click","id":3} | {"action":"tap","x":500,"y":800} (x und y von 0 bis 1000, nur wenn ein Bildschirmfoto beiliegt und kein passendes Element existiert) | {"action":"type","id":5,"text":"..."} | {"action":"scroll","direction":"down"} (oder "up") | {"action":"back"} | {"action":"home"} | {"action":"open_app","name":"YouTube"} | {"action":"wait"} | {"action":"ask_user","message":"..."} | {"action":"done","message":"kurze deutsche Antwort an den Nutzer"}. Regeln: Mache pro Antwort genau einen Schritt. Gib niemals Passwörter, Zahlungsdaten oder PINs ein. Kaufe, bezahle, lösche oder sende nur, wenn das Ziel es ausdrücklich verlangt. Wenn du unsicher bist oder Hilfe brauchst, nutze ask_user. Wenn das Ziel erreicht ist, nutze done. Verwende nur Elementnummern, die in der Liste stehen."""

    private const val READ_SYS =
        "Du bist JARVIS, ein höflicher deutscher Sprachassistent. Antworte kurz auf Deutsch, ohne Markdown, " +
            "Listen oder Sternchen, weil deine Antwort vorgelesen wird."

    private suspend fun prepare(): SendAssistService.Snap? {
        JarvisEngine.closePopup()
        delay(700)
        return SendAssistService.instance?.snapshot()
    }

    private fun blockedMsg(s: SendAssistService.Snap): String? =
        if (blockedPkg.containsMatchIn(s.pkg)) "Diese App bediene ich aus Sicherheitsgründen nicht." else null

    private suspend fun screenshotB64(svc: SendAssistService): String? {
        val bmp: Bitmap? = suspendCancellableCoroutine { cont ->
            svc.screenshot { b -> if (cont.isActive) cont.resume(b) }
        }
        if (bmp == null) return null
        return withContext(Dispatchers.Default) {
            val s = 1024f / maxOf(bmp.width, bmp.height)
            val scaled = if (s < 1f) {
                Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true)
            } else bmp
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 70, out)
            Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        }
    }

    private fun parse(raw: String): JSONObject? = try {
        val t = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        if (t.startsWith("[")) JSONArray(t).getJSONObject(0) else JSONObject(t)
    } catch (e: Exception) {
        null
    }

    suspend fun run(goal: String): String =
        withTimeoutOrNull(180_000L) { loop(goal) } ?: "Das hat zu lange gedauert, ich habe abgebrochen."

    private suspend fun loop(goal: String): String {
        val svc = SendAssistService.instance ?: return "Die Bedienungshilfe ist nicht aktiv."
        val log = StringBuilder()
        for (step in 1..MAX_STEPS) {
            val snap = prepare() ?: return "Ich komme gerade nicht an den Bildschirm."
            blockedMsg(snap)?.let { return it }
            val img = if (snap.count < 4) screenshotB64(svc) else null
            val prompt = "Ziel: $goal\nBisherige Schritte:\n${log.toString().ifBlank { "(keine)" }}\n" +
                "Aktuelle App: ${snap.pkg}\nBildschirm:\n${snap.text}"
            val raw = GeminiClient.generate(SYS, prompt, img, true)
            val j = parse(raw) ?: return "Die Antwort der KI war unverständlich."
            when (val action = j.optString("action")) {
                "click" -> {
                    val id = j.optInt("id", -1)
                    val label = snap.label(id)
                    if (risky.containsMatchIn(label)) {
                        val ok = JarvisEngine.askConfirm("Soll ich auf „$label“ tippen?")
                        JarvisEngine.closePopup()
                        delay(700)
                        if (!ok) return "Abgebrochen."
                    }
                    val ok = svc.click(snap, id)
                    log.append("Schritt $step: klick [$id] \"$label\" ${if (ok) "" else "(fehlgeschlagen)"}\n")
                }
                "tap" -> {
                    val (w, h) = svc.screenSize()
                    val x = j.optDouble("x", 500.0).toFloat() / 1000f * w
                    val y = j.optDouble("y", 500.0).toFloat() / 1000f * h
                    svc.tapAt(x, y)
                    log.append("Schritt $step: tippe auf Position\n")
                }
                "type" -> {
                    val id = j.optInt("id", -1)
                    val ok = svc.typeText(snap, id, j.optString("text"))
                    log.append("Schritt $step: Text eingegeben in [$id] ${if (ok) "" else "(fehlgeschlagen)"}\n")
                }
                "scroll" -> {
                    svc.scroll(j.optString("direction") != "up")
                    log.append("Schritt $step: scrolle ${j.optString("direction")}\n")
                }
                "back", "home", "recents" -> {
                    svc.global(action)
                    log.append("Schritt $step: $action\n")
                }
                "open_app" -> {
                    val name = j.optString("name")
                    val r = JarvisEngine.openAppForAgent(name)
                    if (r != Launch.OPENED) return "Ich konnte $name nicht selbst öffnen. Öffne die App bitte und sage den Befehl noch einmal."
                    log.append("Schritt $step: App $name geöffnet\n")
                    delay(1200)
                }
                "wait" -> {
                    log.append("Schritt $step: gewartet\n")
                    delay(1500)
                }
                "ask_user" -> return j.optString("message").ifBlank { "Ich brauche deine Hilfe." }
                "done" -> return j.optString("message").ifBlank { "Erledigt." }
                else -> return "Die KI hat eine unbekannte Aktion verlangt."
            }
            delay(900)
        }
        return "Ich habe nach $MAX_STEPS Schritten aufgehört. Das Ziel ist vielleicht noch nicht erreicht."
    }

    suspend fun readScreen(summarize: Boolean): String {
        val svc = SendAssistService.instance ?: return "Die Bedienungshilfe ist nicht aktiv."
        val snap = prepare() ?: return "Ich komme gerade nicht an den Bildschirm."
        blockedMsg(snap)?.let { return it }
        val img = screenshotB64(svc)
        val task = if (summarize) {
            "Beschreibe in höchstens drei Sätzen, was auf dem Bildschirm zu sehen ist."
        } else {
            "Lies den sichtbaren Text des Bildschirms sinnvoll zusammengefasst vor, höchstens sechs Sätze."
        }
        return GeminiClient.generate(READ_SYS, "$task\nAktuelle App: ${snap.pkg}\nBildschirmtext:\n${snap.text}", img, false)
    }

    suspend fun tapLabel(label: String): String {
        val svc = SendAssistService.instance ?: return "Die Bedienungshilfe ist nicht aktiv."
        val snap = prepare() ?: return "Ich komme gerade nicht an den Bildschirm."
        blockedMsg(snap)?.let { return it }
        if (risky.containsMatchIn(label)) {
            val ok = JarvisEngine.askConfirm("Soll ich auf „$label“ tippen?")
            JarvisEngine.closePopup()
            delay(700)
            if (!ok) return "Abgebrochen."
        }
        return if (svc.tapLabel(label)) "Erledigt." else "Ich habe „$label“ auf dem Bildschirm nicht gefunden."
    }

    suspend fun scroll(down: Boolean): String {
        val svc = SendAssistService.instance ?: return "Die Bedienungshilfe ist nicht aktiv."
        val snap = prepare() ?: return "Ich komme gerade nicht an den Bildschirm."
        blockedMsg(snap)?.let { return it }
        return if (svc.scroll(down)) "Erledigt." else "Das Scrollen hat nicht geklappt."
    }

    suspend fun nav(kind: String): String {
        val svc = SendAssistService.instance ?: return "Die Bedienungshilfe ist nicht aktiv."
        JarvisEngine.closePopup()
        delay(600)
        return if (svc.global(kind)) "Erledigt." else "Das hat nicht geklappt."
    }
}
