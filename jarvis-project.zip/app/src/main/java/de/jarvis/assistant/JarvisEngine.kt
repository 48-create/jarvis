package de.jarvis.assistant

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.Manifest
import android.annotation.SuppressLint
import android.app.Application
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Status { IDLE, WAKE, LISTENING, THINKING, SPEAKING }
enum class Purpose { WAKE, COMMAND }
enum class Launch { OPENED, NOTIFIED, FAILED }
data class ChatMsg(val fromUser: Boolean, val text: String)

/** Zentrale Steuerung: Spracherkennung, Sprachausgabe, Befehle, KI. Alles läuft auf dem Main-Thread. */
object JarvisEngine {
    private lateinit var app: Application
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    val messages = mutableStateListOf<ChatMsg>()
    var status by mutableStateOf(Status.IDLE)
        private set
    var pending by mutableStateOf<PendingWa?>(null)
        private set
    var wakeMode by mutableStateOf(false)
        private set

    @Volatile
    var appVisible = false

    private val anrede: String get() = Prefs.title.ifBlank { "Sir" }

    @Volatile
    var autoSendUntil = 0L

    private val autoSendCheck = Runnable {
        if (autoSendUntil != 0L) {
            autoSendUntil = 0L
            speak("Ich konnte den Senden-Knopf nicht finden. Bitte tippe in WhatsApp selbst auf Senden.")
        }
    }

    fun onAutoSent() {
        main.removeCallbacks(autoSendCheck)
        speak("Nachricht gesendet, $anrede.")
    }

    private var conversation = false
    private var purpose = Purpose.COMMAND
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var aiJob: Job? = null
    private val history = ArrayList<Pair<String, String>>()

    private val wakeRegex = Regex(
        """\b(?:jarvis|jarwis|dscharvis|tscharvis|charvis|jarvies|jarviss|jarwiss|dschawis)\b""",
        RegexOption.IGNORE_CASE
    )

    private val restart = Runnable {
        if (wakeMode && status == Status.WAKE && recognizer == null && !porcupineRunning) startWake()
    }

    fun init(a: Application) {
        app = a
        addAssistant("Guten Tag, $anrede. JARVIS ist bereit.")
        tts = TextToSpeech(a) { st ->
            if (st == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale.GERMANY)
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                applyVoice()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        main.post { afterSpeech() }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        main.post { afterSpeech() }
                    }
                })
                if (!ttsReady) {
                    main.post {
                        addAssistant(
                            "Hinweis: Die deutsche Sprachausgabe fehlt. Installiere die deutsche Stimme in " +
                                "den Android-Einstellungen unter Sprachausgabe."
                        )
                    }
                }
            } else {
                main.post { addAssistant("Hinweis: Die Sprachausgabe konnte nicht gestartet werden.") }
            }
        }
    }

    // ---------- Chat ----------
    private fun addUser(t: String) = addMsg(ChatMsg(true, t))
    private fun addAssistant(t: String) = addMsg(ChatMsg(false, t))
    private fun addMsg(m: ChatMsg) {
        messages.add(m)
        while (messages.size > 100) messages.removeAt(0)
    }

    // ---------- Bedienung aus der Oberfläche ----------
    fun micPressed() {
        if (status == Status.LISTENING || status == Status.SPEAKING || status == Status.THINKING) {
            stopAll()
        } else {
            tts?.stop()
            conversation = true
            listen(Purpose.COMMAND)
        }
    }

    fun stopAll() {
        conversation = false
        aiJob?.cancel()
        tts?.stop()
        killRecognizer()
        main.removeCallbacks(restart)
        resume()
    }

    fun setWake(on: Boolean) {
        wakeMode = on
        if (on) {
            ListenService.start(app)
            if (status == Status.IDLE) startWake()
        } else {
            ListenService.stop(app)
            releasePorcupine()
            if (status == Status.WAKE) {
                killRecognizer()
                main.removeCallbacks(restart)
                status = Status.IDLE
            }
        }
    }

    fun confirmPending() {
        val p = pending ?: return
        pending = null
        conversation = false
        killRecognizer()
        main.removeCallbacks(restart)
        val auto = Prefs.autoSend && p.number != null && Actions.accessibilityEnabled(app)
        if (auto) {
            autoSendUntil = System.currentTimeMillis() + 20000
            main.removeCallbacks(autoSendCheck)
            main.postDelayed(autoSendCheck, 21000)
        }
        val r = startExternal(Actions.whatsAppIntent(p), "WhatsApp mit Nachricht an ${p.name} öffnen")
        speak(
            when {
                r == Launch.FAILED -> {
                    autoSendUntil = 0L
                    main.removeCallbacks(autoSendCheck)
                    "WhatsApp konnte nicht geöffnet werden. Ist die App installiert?"
                }
                auto -> "Sehr wohl, ich sende die Nachricht."
                r == Launch.OPENED -> "WhatsApp ist bereit. Tippe dort selbst auf Senden, $anrede."
                else -> "Tippe auf die Benachrichtigung, um WhatsApp zu öffnen. Gesendet wird erst, wenn du dort auf Senden tippst."
            }
        )
    }

    fun cancelPending() {
        pending = null
        conversation = false
        killRecognizer()
        main.removeCallbacks(restart)
        speak("Verstanden, die Nachricht wurde verworfen.")
    }

    // ---------- Spracherkennung ----------
    private fun hasMic() =
        ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun killRecognizer(delayed: Boolean = false) {
        val r = recognizer ?: return
        recognizer = null
        fun doKill() {
            try {
                r.cancel()
                r.destroy()
            } catch (_: Exception) {
            }
        }
        if (delayed) main.post { doKill() } else doKill()
    }

    private fun resume() {
        if (wakeMode) {
            status = Status.WAKE
            main.removeCallbacks(restart)
            main.postDelayed(restart, 300)
        } else {
            status = Status.IDLE
        }
    }

    private fun listen(p: Purpose) {
        main.removeCallbacks(restart)
        stopPorcupine()
        if (!hasMic()) {
            addAssistant("Mir fehlt die Mikrofon-Berechtigung. Bitte erlaube sie in den Android-Einstellungen.")
            conversation = false
            wakeMode = false
            ListenService.stop(app)
            status = Status.IDLE
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(app)) {
            addAssistant("Auf diesem Gerät ist keine Spracherkennung verfügbar. Bitte aktiviere die Google-App.")
            conversation = false
            status = Status.IDLE
            return
        }
        killRecognizer()
        purpose = p
        val r = SpeechRecognizer.createSpeechRecognizer(app)
        r.setRecognitionListener(listener)
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, app.packageName)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
        }
        recognizer = r
        status = if (p == Purpose.WAKE) Status.WAKE else Status.LISTENING
        r.startListening(i)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            killRecognizer(delayed = true)
            val quiet = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                addAssistant("Mikrofon-Berechtigung fehlt.")
                conversation = false
                wakeMode = false
                ListenService.stop(app)
                status = Status.IDLE
                return
            }
            if (purpose == Purpose.WAKE) {
                if (wakeMode) {
                    status = Status.WAKE
                    main.postDelayed(restart, if (quiet) 150L else 1500L)
                } else {
                    status = Status.IDLE
                }
            } else {
                if (!quiet) addAssistant("Die Spracherkennung meldet Fehler $error. Prüfe die Internetverbindung.")
                conversation = false
                resume()
            }
        }

        override fun onResults(results: Bundle?) {
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
            killRecognizer(delayed = true)
            if (purpose == Purpose.WAKE) {
                onWakeResults(list)
            } else {
                val t = list.firstOrNull()
                if (t.isNullOrBlank()) {
                    conversation = false
                    resume()
                } else {
                    handleUserText(t)
                }
            }
        }
    }

    private fun onWakeResults(list: List<String>) {
        for (t in list) {
            val m = wakeRegex.find(t) ?: continue
            val rest = t.substring(m.range.last + 1).trim().trimStart(',', '.', '!', ':').trim()
            conversation = true
            showPopup()
            if (rest.isNotEmpty()) handleUserText(rest) else speak("Zu Diensten, $anrede.")
            return
        }
        if (wakeMode) {
            status = Status.WAKE
            main.postDelayed(restart, 150)
        } else {
            status = Status.IDLE
        }
    }

    // ---------- Aktivierungswort (Porcupine, offline) ----------
    private var porcupine: PorcupineManager? = null
    private var porcupineKeyUsed = ""
    private var porcupineFailedKey = ""

    @Volatile
    private var porcupineRunning = false

    private fun ensurePorcupine(): Boolean {
        val key = Prefs.picoKey
        if (key.isBlank() || key == porcupineFailedKey) return false
        if (porcupine != null && porcupineKeyUsed == key) return true
        releasePorcupine()
        return try {
            porcupine = PorcupineManager.Builder()
                .setAccessKey(key)
                .setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                .setSensitivity(0.7f)
                .build(app, PorcupineManagerCallback { main.post { onWakeDetected() } })
            porcupineKeyUsed = key
            true
        } catch (e: Exception) {
            porcupineFailedKey = key
            porcupine = null
            addAssistant("Die Offline-Aktivierung startet nicht (${e.message}). Ich nutze ersatzweise die Cloud-Erkennung.")
            false
        }
    }

    private fun startWake() {
        if (ensurePorcupine()) {
            killRecognizer()
            if (!porcupineRunning) {
                try {
                    porcupine?.start()
                    porcupineRunning = true
                } catch (e: Exception) {
                    porcupineFailedKey = Prefs.picoKey
                    releasePorcupine()
                    addAssistant("Die Offline-Aktivierung konnte das Mikrofon nicht öffnen (${e.message}). Ersatzweise Cloud-Erkennung.")
                    listen(Purpose.WAKE)
                    return
                }
            }
            status = Status.WAKE
        } else {
            listen(Purpose.WAKE)
        }
    }

    private fun stopPorcupine() {
        if (porcupineRunning) {
            try {
                porcupine?.stop()
            } catch (_: Exception) {
            }
            porcupineRunning = false
        }
    }

    private fun releasePorcupine() {
        stopPorcupine()
        try {
            porcupine?.delete()
        } catch (_: Exception) {
        }
        porcupine = null
        porcupineKeyUsed = ""
    }

    private fun onWakeDetected() {
        if (status != Status.WAKE || !wakeMode) return
        stopPorcupine()
        conversation = true
        showPopup()
        speak("Zu Diensten, $anrede.")
    }

    /** Wird nach dem Speichern der Einstellungen aufgerufen. */
    fun onSettingsChanged() {
        porcupineFailedKey = ""
        releasePorcupine()
        if (wakeMode && status == Status.WAKE) {
            main.removeCallbacks(restart)
            killRecognizer()
            startWake()
        }
    }

    /** Zeigt das Jarvis-Popup auch bei ausgeschaltetem oder gesperrtem Bildschirm. */
    @SuppressLint("MissingPermission")
    private fun showPopup() {
        if (appVisible) return
        val i = Intent(app, PopupActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        try {
            if (Settings.canDrawOverlays(app)) app.startActivity(i)
        } catch (_: Exception) {
        }
        try {
            val pi = PendingIntent.getActivity(
                app, 77, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(app, JarvisApp.CH_POPUP)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("JARVIS")
                .setContentText("Ich höre zu …")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setFullScreenIntent(pi, true)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setTimeoutAfter(10000)
                .build()
            NotificationManagerCompat.from(app).notify(3, n)
        } catch (_: Exception) {
        }
    }

    // ---------- Befehle ----------
    fun handleUserText(text: String) {
        addUser(text)

        if (pending != null) {
            when (Commands.yesNo(text)) {
                true -> confirmPending()
                false -> cancelPending()
                null -> {
                    conversation = true
                    speak("Bitte antworte mit Ja oder Nein, $anrede.")
                }
            }
            return
        }

        when (val c = Commands.parse(text)) {
            Cmd.Stop -> {
                conversation = false
                speak("Jederzeit, $anrede.")
            }
            Cmd.Time -> speak("Es ist ${SimpleDateFormat("HH:mm", Locale.GERMANY).format(Date())} Uhr, $anrede.")
            Cmd.Date -> speak(
                "Heute ist ${SimpleDateFormat("EEEE, 'der' d. MMMM yyyy", Locale.GERMANY).format(Date())}, $anrede."
            )
            is Cmd.OpenApp -> {
                val a = Commands.findApp(app, c.name)
                val i = a?.let { app.packageManager.getLaunchIntentForPackage(it.pkg) }
                if (a == null || i == null) {
                    speak("Die App ${c.name} habe ich nicht gefunden, $anrede.")
                } else {
                    conversation = false
                    val r = startExternal(i, "${a.label} öffnen")
                    speak(
                        when (r) {
                            Launch.OPENED -> listOf(
                                "Sehr wohl, $anrede. Ich öffne ${a.label}.",
                                "Selbstverständlich. ${a.label} wird gestartet.",
                                "Wird erledigt, $anrede."
                            ).random()
                            Launch.NOTIFIED -> "Tippe auf die Benachrichtigung, um ${a.label} zu öffnen."
                            Launch.FAILED -> "Das hat leider nicht geklappt."
                        }
                    )
                }
            }
            is Cmd.WhatsApp -> {
                val found = Actions.findContact(app, c.name)
                val number = found?.second?.let { Actions.digits(it) }
                val shown = found?.first ?: c.name
                pending = PendingWa(shown, number, c.text)
                conversation = true
                val hint = if (number == null) {
                    " Ich habe keine Nummer gefunden. Du wählst den Kontakt dann in WhatsApp selbst aus."
                } else ""
                speak("Nachricht an $shown: ${c.text}.$hint Soll ich WhatsApp damit öffnen? Sage Ja oder Nein.")
            }
            is Cmd.Ai -> askAi(c.text)
        }
    }

    private fun askAi(text: String) {
        status = Status.THINKING
        history.add("user" to text)
        while (history.size > 12 || (history.isNotEmpty() && history[0].first != "user")) history.removeAt(0)
        aiJob?.cancel()
        aiJob = scope.launch {
            try {
                val ans = GeminiClient.ask(history.toList())
                history.add("model" to ans)
                speak(ans)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                history.removeLastOrNull()
                conversation = false
                speak(e.message ?: "Unbekannter Fehler.")
            }
        }
    }

    // ---------- Sprachausgabe ----------
    fun germanVoices(): List<Voice> = try {
        tts?.voices?.filter { it.locale.language == "de" }
            ?.sortedWith(compareByDescending<Voice> { it.quality }.thenBy { it.name })
            ?: emptyList()
    } catch (e: Exception) {
        emptyList()
    }

    fun applyVoice() {
        val t = tts ?: return
        t.setPitch(Prefs.pitch)
        t.setSpeechRate(Prefs.rate)
        if (Prefs.voice.isNotBlank()) {
            germanVoices().firstOrNull { it.name == Prefs.voice }?.let { t.voice = it }
        }
    }

    /** Schaltet zur nächsten deutschen Stimme und spricht eine Probe. */
    fun nextVoice(): String {
        val l = germanVoices()
        if (l.isEmpty()) return "Keine deutsche Stimme gefunden"
        val i = l.indexOfFirst { it.name == Prefs.voice }
        val v = l[(i + 1) % l.size]
        Prefs.voice = v.name
        applyVoice()
        sample()
        return v.name
    }

    fun sample() {
        tts?.speak("Guten Tag, $anrede. So klinge ich.", TextToSpeech.QUEUE_FLUSH, null, "sample")
    }

    fun speak(text: String) {
        addAssistant(text)
        killRecognizer()
        stopPorcupine()
        main.removeCallbacks(restart)
        if (Prefs.speak && ttsReady) {
            status = Status.SPEAKING
            val clean = text.replace(Regex("[*_#`]"), "").take(3500)
            tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
        } else {
            afterSpeech()
        }
    }

    private fun afterSpeech() {
        if (conversation) listen(Purpose.COMMAND) else resume()
    }

    // ---------- Andere Apps starten ----------
    @SuppressLint("MissingPermission")
    private fun startExternal(intent: Intent, label: String): Launch {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (appVisible) {
            return try {
                app.startActivity(intent)
                Launch.OPENED
            } catch (e: Exception) {
                Launch.FAILED
            }
        }
        // Im Hintergrund: mit der Überlagerungs-Berechtigung direkt starten, sonst Benachrichtigung zum Antippen.
        var direct = false
        if (Settings.canDrawOverlays(app)) {
            direct = try {
                app.startActivity(intent)
                true
            } catch (e: Exception) {
                false
            }
        }
        val posted = try {
            val pi = PendingIntent.getActivity(
                app, (System.currentTimeMillis() % 100000).toInt(), intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val b = NotificationCompat.Builder(app, if (direct) JarvisApp.CH_FALLBACK else JarvisApp.CH_ACTION)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("JARVIS")
                .setContentText("Tippen: $label")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setPriority(if (direct) NotificationCompat.PRIORITY_LOW else NotificationCompat.PRIORITY_HIGH)
            if (direct) b.setTimeoutAfter(15000)
            NotificationManagerCompat.from(app).notify(2, b.build())
            true
        } catch (e: Exception) {
            false
        }
        return if (direct) Launch.OPENED else if (posted) Launch.NOTIFIED else Launch.FAILED
    }
}
