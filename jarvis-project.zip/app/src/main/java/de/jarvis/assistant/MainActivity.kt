package de.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

internal val Cyan = Color(0xFF2EE6FF)
internal val Gold = Color(0xFFFFC857)
internal val Dark = Color(0xFF05080F)
internal val Panel = Color(0xFF0D1B2A)
internal val TextC = Color(0xFFE6F7FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Cyan, onPrimary = Color.Black, secondary = Gold,
                    background = Dark, surface = Panel, onSurface = TextC, onBackground = TextC
                )
            ) { RootScreen() }
        }
    }

    override fun onStart() {
        super.onStart()
        JarvisEngine.appVisible = true
        JarvisEngine.resumeWakeIfWanted()
    }

    override fun onStop() {
        super.onStop()
        JarvisEngine.appVisible = false
        val app = applicationContext
        Thread { Backup.auto(app) }.start()
    }
}

internal fun statusText(s: Status) = when (s) {
    Status.IDLE -> "Bereit – tippe auf den Reaktor"
    Status.WAKE -> "Warte auf „Hey Jarvis“ …"
    Status.LISTENING -> "Ich höre zu …"
    Status.THINKING -> "Denke nach …"
    Status.SPEAKING -> "Spreche … (Reaktor tippen = stopp)"
}

@Composable
fun Bubble(m: ChatMsg) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start
    ) {
        val shape = RoundedCornerShape(12.dp)
        Box(
            Modifier
                .widthIn(max = 300.dp)
                .padding(vertical = 4.dp)
                .background(if (m.fromUser) Color(0xFF12304A) else Panel, shape)
                .border(1.dp, if (m.fromUser) Gold.copy(alpha = 0.6f) else Cyan.copy(alpha = 0.4f), shape)
                .padding(10.dp)
        ) {
            Text(m.text, color = TextC, fontSize = 15.sp)
        }
    }
}

@Composable
fun Reactor(status: Status, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "reactor")
    val pulse by t.animateFloat(
        initialValue = 0.55f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val rot by t.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)),
        label = "rot"
    )
    val active = status != Status.IDLE
    val color = when (status) {
        Status.LISTENING -> Gold
        Status.SPEAKING -> Color(0xFF7CF5FF)
        else -> Cyan
    }
    val glow = if (active) pulse else 0.5f
    Canvas(Modifier.size(140.dp).clickable { onClick() }) {
        val c = center
        val r = size.minDimension / 2f
        drawCircle(color.copy(alpha = 0.12f * glow), radius = r)
        drawCircle(color.copy(alpha = 0.8f), radius = r * 0.92f, style = Stroke(3.dp.toPx()))
        rotate(if (active) rot else 0f) {
            for (i in 0 until 8) {
                drawArc(
                    color = color.copy(alpha = 0.9f),
                    startAngle = i * 45f + 5f,
                    sweepAngle = 25f,
                    useCenter = false,
                    topLeft = Offset(c.x - r * 0.7f, c.y - r * 0.7f),
                    size = Size(r * 1.4f, r * 1.4f),
                    style = Stroke(8.dp.toPx())
                )
            }
        }
        drawCircle(color.copy(alpha = glow), radius = r * 0.3f)
        drawCircle(Color.White.copy(alpha = 0.9f), radius = r * 0.12f)
    }
}

@Composable
fun SettingsDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var autoSend by remember { mutableStateOf(Prefs.autoSend) }
    var pico by remember { mutableStateOf(Prefs.picoKey) }
    var screenCtl by remember { mutableStateOf(Prefs.screenControl) }
    val overlayOk = Settings.canDrawOverlays(ctx)
    val a11yOk = Actions.accessibilityEnabled(ctx)
    val entries = remember { mutableStateListOf<KeyEntry>().apply { addAll(Prefs.keyEntries) } }
    var fallback by remember { mutableStateOf(Prefs.fallbackModels) }
    var autoModel by remember { mutableStateOf(Prefs.autoModel) }
    var fastModel by remember { mutableStateOf(Prefs.fastModel) }
    var city by remember { mutableStateOf(Prefs.city) }
    var usage by remember { mutableStateOf(Usage.lines()) }
    var backupMsg by remember { mutableStateOf("") }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            backupMsg = try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(Backup.build().toByteArray(Charsets.UTF_8)) }
                "Sicherung gespeichert (mit Schlüsseln, Einstellungen, Chats und Daten)."
            } catch (e: Exception) {
                "Sicherung fehlgeschlagen: ${e.message}"
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            backupMsg = try {
                val txt = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
                val done = Backup.restore(txt)
                Toast.makeText(ctx, done, Toast.LENGTH_LONG).show()
                onClose() // Einstellungen neu laden, damit alte Werte die wiederhergestellten nicht überschreiben
                done
            } catch (e: Exception) {
                "Wiederherstellung fehlgeschlagen: ${e.message}"
            }
        }
    }
    var autoFolder by remember { mutableStateOf(Prefs.backupTree.isNotBlank()) }
    val folderLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                Prefs.backupTree = uri.toString()
                Prefs.backupDoc = ""
                autoFolder = true
                backupMsg = if (Backup.auto(ctx)) "Automatische Sicherung eingerichtet und gespeichert." else "Ordner gemerkt, aber das Schreiben hat nicht geklappt."
            } catch (e: Exception) {
                backupMsg = "Ordner konnte nicht gespeichert werden: ${e.message}"
            }
        }
    }
    var model by remember { mutableStateOf(Prefs.model) }
    var speak by remember { mutableStateOf(Prefs.speak) }
    var title by remember { mutableStateOf(Prefs.title) }
    var pitch by remember { mutableStateOf(Prefs.pitch) }
    var rate by remember { mutableStateOf(Prefs.rate) }
    var voiceName by remember { mutableStateOf(Prefs.voice.ifBlank { "Standard" }) }
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Color(0xFF07101C),
        shape = RoundedCornerShape(6.dp),
        title = { Text("Einstellungen") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                KeyEditor(entries)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = model, onValueChange = { model = it },
                    label = { Text("Hauptmodell") },
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = fallback, onValueChange = { fallback = it },
                    label = { Text("Reserve-Modelle (Komma getrennt)") },
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = autoModel, onCheckedChange = { autoModel = it })
                    Spacer(Modifier.width(8.dp))
                    Text("Modell automatisch wählen (kurze Fragen schnell)", fontSize = 13.sp)
                }
                if (autoModel) {
                    OutlinedTextField(
                        value = fastModel, onValueChange = { fastModel = it },
                        label = { Text("Schnelles Modell") },
                        singleLine = true
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text("Verbrauch und Fehler", fontSize = 13.sp, color = Gold)
                if (usage.isEmpty()) Text("Noch kein Schlüssel gespeichert.", fontSize = 12.sp)
                usage.forEach { Text(it, fontSize = 12.sp) }
                OutlinedButton(onClick = {
                    Usage.reset(); usage = Usage.lines()
                }) { Text("Zähler zurücksetzen") }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = city, onValueChange = { city = it },
                    label = { Text("Wetter-Ort (z. B. Hamburg)") },
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                Text("Sicherung (alles: Schlüssel, Modelle, Ort, Einstellungen, Chats, Projekte, Notizen, Aufgaben, Termine, Erinnerungen)", fontSize = 13.sp, color = Gold)
                Text("Die Datei enthält deine API-Schlüssel im Klartext. Nicht weitergeben.", fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { exportLauncher.launch("jarvis-sicherung.json") }) { Text("Sichern") }
                    OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) }) { Text("Wiederherstellen") }
                }
                OutlinedButton(onClick = { folderLauncher.launch(null) }) {
                    Text(if (autoFolder) "Sicherungs-Ordner ändern" else "Automatische Sicherung: Ordner wählen")
                }
                Text(
                    if (autoFolder) "Bei jedem Verlassen der App wird automatisch gesichert. Die Datei bleibt auch nach einer Deinstallation erhalten."
                    else "Tipp: Wähle einen Ordner (zum Beispiel Dokumente). Dann sichert JARVIS automatisch, auch vor einer Neuinstallation.",
                    fontSize = 11.sp
                )
                if (backupMsg.isNotEmpty()) Text(backupMsg, fontSize = 12.sp)
                Text("Version ${BuildConfigInfo.version(ctx)}", fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = title, onValueChange = { title = it },
                    label = { Text("Anrede (z. B. Sir oder dein Name)") },
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = speak, onCheckedChange = { speak = it })
                    Spacer(Modifier.width(8.dp))
                    Text("Antworten vorlesen")
                }
                Spacer(Modifier.height(12.dp))
                Text("Stimme: $voiceName", fontSize = 12.sp)
                OutlinedButton(onClick = {
                    Prefs.pitch = pitch
                    Prefs.rate = rate
                    voiceName = JarvisEngine.nextVoice()
                }) { Text("Nächste Stimme testen") }
                Text("Tonhöhe: ${(pitch * 100).toInt() / 100f}  (tiefer = kleiner)", fontSize = 12.sp)
                Slider(value = pitch, onValueChange = { pitch = it }, valueRange = 0.6f..1.2f)
                Text("Tempo: ${(rate * 100).toInt() / 100f}", fontSize = 12.sp)
                Slider(value = rate, onValueChange = { rate = it }, valueRange = 0.7f..1.3f)
                OutlinedButton(onClick = {
                    Prefs.pitch = pitch
                    Prefs.rate = rate
                    JarvisEngine.applyVoice()
                    JarvisEngine.sample()
                }) { Text("Probe sprechen") }
                Spacer(Modifier.height(16.dp))
                Text("Aktivierungswort „Jarvis“", fontSize = 15.sp, color = Gold)
                Text(
                    "Offline und ohne Cloud: kostenlosen AccessKey auf console.picovoice.ai erstellen und hier einfügen. " +
                        "Ohne Key nutzt JARVIS die Cloud-Erkennung von Google.",
                    fontSize = 12.sp
                )
                OutlinedTextField(
                    value = pico, onValueChange = { pico = it },
                    label = { Text("Picovoice-AccessKey") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )
                OutlinedButton(onClick = {
                    try {
                        ctx.startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
                    } catch (e: Exception) {
                        ctx.startActivity(Intent(Settings.ACTION_SETTINGS))
                    }
                }) { Text("Als Standard-Assistent festlegen") }
                if (Build.VERSION.SDK_INT >= 34) {
                    OutlinedButton(onClick = {
                        ctx.startActivity(
                            Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + ctx.packageName))
                        )
                    }) { Text("Popup bei Sperrbildschirm erlauben") }
                }
                Spacer(Modifier.height(16.dp))
                Text("Automatik", fontSize = 15.sp, color = Gold)
                Text("Apps im Hintergrund öffnen: ${if (overlayOk) "erlaubt" else "nicht erlaubt"}", fontSize = 12.sp)
                OutlinedButton(onClick = {
                    ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                    )
                }) { Text("„Über anderen Apps“ erlauben") }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = autoSend, onCheckedChange = { autoSend = it })
                    Spacer(Modifier.width(8.dp))
                    Text("WhatsApp nach meinem Ja automatisch senden", fontSize = 13.sp)
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = screenCtl, onCheckedChange = { screenCtl = it })
                    Spacer(Modifier.width(8.dp))
                    Text("Bildschirmsteuerung (Beta)", fontSize = 13.sp)
                }
                Text(
                    "JARVIS darf auf Befehl den Bildschirm lesen, tippen und scrollen. Bildschirmtext und Fotos gehen dafür " +
                        "an Googles KI. Bei Senden, Kaufen und Löschen fragt er vorher nach. Banking- und Passwort-Apps sind gesperrt.",
                    fontSize = 11.sp
                )
                Text("Bedienungshilfe: ${if (a11yOk) "aktiv" else "nicht aktiv"}", fontSize = 12.sp)
                OutlinedButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }) { Text("Bedienungshilfe öffnen") }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                Prefs.keyEntries = entries.toList()
                Prefs.fallbackModels = fallback
                Prefs.autoModel = autoModel
                Prefs.fastModel = fastModel.ifBlank { "gemini-2.5-flash-lite" }
                Prefs.city = city
                Prefs.model = model.ifBlank { "gemini-2.5-flash" }
                Prefs.speak = speak
                Prefs.autoSend = autoSend
                Prefs.screenControl = screenCtl
                Prefs.picoKey = pico
                Prefs.title = title.ifBlank { "Sir" }
                Prefs.pitch = pitch
                Prefs.rate = rate
                JarvisEngine.applyVoice()
                JarvisEngine.onSettingsChanged()
                onClose()
            }) { Text("Speichern") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Abbrechen") } }
    )
}
