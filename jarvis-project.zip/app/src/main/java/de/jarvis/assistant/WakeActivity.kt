package de.jarvis.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat

/** Unsichtbare Zwischenstation: schaltet „Hey Jarvis“ ein (Android erlaubt das nur aus sichtbarer App heraus). */
class WakeActivity : ComponentActivity() {
    private var done = false

    override fun onResume() {
        super.onResume()
        if (done) return
        done = true
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            JarvisEngine.setWake(true)
            Toast.makeText(this, "JARVIS hört jetzt auf „Jarvis“", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Bitte erlaube JARVIS zuerst das Mikrofon (in der App).", Toast.LENGTH_LONG).show()
        }
        finish()
    }
}
