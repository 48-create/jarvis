package de.jarvis.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

@Composable
fun JarvisScreen() {
    val ctx = LocalContext.current
    var showSettings by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val msgs = JarvisEngine.messages
    val pending = JarvisEngine.pending
    val status = JarvisEngine.status
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    LaunchedEffect(Unit) {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray())
    }
    LaunchedEffect(msgs.size) {
        if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1)
    }

    Box(Modifier.fillMaxSize()) {
        HudBackground()
        Column(Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 18.dp)) {

            // Kopfzeile
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "J.A.R.V.I.S.",
                        style = TextStyle(
                            color = Cyan, fontSize = 26.sp, fontWeight = FontWeight.Light, letterSpacing = 6.sp,
                            shadow = Shadow(Cyan.copy(alpha = 0.7f), Offset.Zero, 24f)
                        )
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        BlinkDot()
                        Spacer(Modifier.width(8.dp))
                        Text(
                            hudLabel(status),
                            color = Gold, fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace, letterSpacing = 2.sp
                        )
                    }
                }
                HudButton("⚙") { showSettings = true }
            }

            // Gespräch als schwebender Text
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth().padding(top = 14.dp),
                state = listState,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                itemsIndexed(msgs) { i, m -> TranscriptLine(m, animate = i == msgs.lastIndex && !m.fromUser) }
            }

            // WhatsApp-Bestätigung
            if (pending != null) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .background(Color(0x14FFC857), RoundedCornerShape(4.dp))
                        .border(1.dp, Gold.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                        .padding(14.dp)
                ) {
                    Text(
                        "WHATSAPP · NACHRICHT VORBEREITEN",
                        color = Gold, fontSize = 11.sp, fontFamily = FontFamily.Monospace, letterSpacing = 1.5.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    Text("An: ${pending.name}", color = TextC, fontSize = 15.sp)
                    Text(pending.text, color = TextC, fontSize = 15.sp, fontWeight = FontWeight.Light)
                    if (pending.number == null) {
                        Text("Keine Nummer gefunden – Kontakt wählst du in WhatsApp.", color = Gold, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        HudButton("BESTÄTIGEN", filled = true) { JarvisEngine.confirmPending() }
                        HudButton("ABBRECHEN", accent = Gold) { JarvisEngine.cancelPending() }
                    }
                }
            }

            // Bestätigung für Bildschirmsteuerung
            val ac = JarvisEngine.agentConfirm
            if (ac != null) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .background(Color(0x14FFC857), RoundedCornerShape(4.dp))
                        .border(1.dp, Gold.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                        .padding(14.dp)
                ) {
                    Text(
                        "BILDSCHIRMSTEUERUNG · BESTÄTIGEN",
                        color = Gold, fontSize = 11.sp, fontFamily = FontFamily.Monospace, letterSpacing = 1.5.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(ac.text, color = TextC, fontSize = 15.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        HudButton("JA", filled = true) { JarvisEngine.answerAgent(true) }
                        HudButton("NEIN", accent = Gold) { JarvisEngine.answerAgent(false) }
                    }
                }
            }

            // Orb
            Box(Modifier.fillMaxWidth().height(250.dp), contentAlignment = Alignment.Center) {
                JarvisOrb(status, 230.dp) { JarvisEngine.micPressed() }
            }

            // Aktivierungswort
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Switch(
                    checked = JarvisEngine.wakeMode,
                    onCheckedChange = { on ->
                        if (on && ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO)
                            != PackageManager.PERMISSION_GRANTED
                        ) {
                            permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                            Toast.makeText(ctx, "Bitte Mikrofon erlauben und Schalter erneut antippen.", Toast.LENGTH_LONG).show()
                        } else {
                            JarvisEngine.setWake(on)
                        }
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Dark,
                        checkedTrackColor = Cyan,
                        uncheckedThumbColor = Cyan.copy(alpha = 0.7f),
                        uncheckedTrackColor = Color.Transparent,
                        uncheckedBorderColor = Cyan.copy(alpha = 0.5f)
                    )
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "HEY JARVIS · DAUERLAUSCHEN",
                    color = TextC.copy(alpha = 0.8f), fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace, letterSpacing = 1.5.sp
                )
            }

            // Texteingabe
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Befehl eingeben …", color = Cyan.copy(alpha = 0.4f)) },
                    singleLine = true,
                    shape = RoundedCornerShape(4.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Cyan,
                        unfocusedBorderColor = Cyan.copy(alpha = 0.35f),
                        cursorColor = Cyan,
                        focusedTextColor = TextC,
                        unfocusedTextColor = TextC
                    )
                )
                Spacer(Modifier.width(8.dp))
                HudButton("▶", filled = true) {
                    if (input.isNotBlank()) {
                        JarvisEngine.handleUserText(input.trim())
                        input = ""
                    }
                }
            }
        }
    }

    if (showSettings) SettingsDialog { showSettings = false }
}

@Composable
fun TranscriptLine(m: ChatMsg, animate: Boolean) {
    if (m.fromUser) {
        Text(
            "› " + m.text,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.End,
            style = TextStyle(color = Cyan.copy(alpha = 0.75f), fontSize = 13.sp, fontFamily = FontFamily.Monospace)
        )
    } else {
        val style = TextStyle(
            color = TextC, fontSize = 16.sp, fontWeight = FontWeight.Light,
            shadow = Shadow(Cyan.copy(alpha = 0.35f), Offset.Zero, 12f)
        )
        val mod = Modifier
            .fillMaxWidth()
            .drawBehind {
                drawLine(Cyan.copy(alpha = 0.6f), Offset(0f, 0f), Offset(0f, size.height), 2.dp.toPx())
            }
            .padding(start = 12.dp)
        if (animate) TypeText(m.text, style, mod) else Text(m.text, style = style, modifier = mod)
    }
}

@Composable
fun BlinkDot() {
    val t = rememberInfiniteTransition(label = "dot")
    val a by t.animateFloat(
        0.25f, 1f,
        infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "dota"
    )
    Canvas(Modifier.size(8.dp)) {
        drawCircle(Cyan.copy(alpha = a))
    }
}
