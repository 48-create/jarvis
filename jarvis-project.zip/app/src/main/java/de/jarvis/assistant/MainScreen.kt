package de.jarvis.assistant

import android.Manifest
import android.graphics.Bitmap
import android.util.Base64
import android.net.Uri
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

@Composable
fun JarvisScreen() {
    val ctx = LocalContext.current
    var showSettings by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val msgs = JarvisEngine.messages
    val pending = JarvisEngine.pending
    val status = JarvisEngine.status
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) {
            val bytes = java.io.ByteArrayOutputStream().use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 82, out)
                out.toByteArray()
            }
            val encoded = Base64.encodeToString(bytes, Base64.NO_WRAP)
            JarvisEngine.analyzePhoto(encoded, input.ifBlank { "Beschreibe dieses Foto." })
            input = ""
        }
    }
    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                val bitmap = ctx.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it) }
                    ?: throw IllegalStateException("Bild konnte nicht geöffnet werden")
                val scaled = if (bitmap.width > 1600 || bitmap.height > 1600) {
                    val ratio = minOf(1600f / bitmap.width, 1600f / bitmap.height)
                    Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt(), (bitmap.height * ratio).toInt(), true)
                } else bitmap
                val bytes = java.io.ByteArrayOutputStream().use { out ->
                    scaled.compress(Bitmap.CompressFormat.JPEG, 82, out)
                    out.toByteArray()
                }
                JarvisEngine.analyzePhoto(Base64.encodeToString(bytes, Base64.NO_WRAP), input.ifBlank { "Beschreibe dieses Bild." })
                input = ""
            } catch (e: Exception) {
                Toast.makeText(ctx, "Bild konnte nicht geladen werden: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    LaunchedEffect(Unit) {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray())
    }
    LaunchedEffect(msgs.size) {
        if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1)
    }

    Box(Modifier.fillMaxSize()) {
        HudBackground()
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp).padding(top = 12.dp, bottom = 8.dp)) {

            // Kopfzeile: Name, Status, Hey-Jarvis-Schalter, Einstellungen
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "JARVIS",
                        style = TextStyle(color = Cyan, fontSize = 20.sp, fontWeight = FontWeight.Light, letterSpacing = 6.sp)
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        BlinkDot()
                        Spacer(Modifier.width(6.dp))
                        Text(
                            hudLabel(status),
                            color = TextC.copy(alpha = 0.55f), fontSize = 10.sp, letterSpacing = 1.5.sp
                        )
                    }
                    if (Chats.activeProjectName().isNotBlank()) {
                        Text("📁 " + Chats.activeProjectName(), color = Gold, fontSize = 10.sp, letterSpacing = 1.sp)
                    }
                }
                HudButton("HEY JARVIS", filled = JarvisEngine.wakeMode) {
                    val on = !JarvisEngine.wakeMode
                    if (on && ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO)
                        != PackageManager.PERMISSION_GRANTED
                    ) {
                        permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                        Toast.makeText(ctx, "Bitte Mikrofon erlauben und noch einmal tippen.", Toast.LENGTH_LONG).show()
                    } else {
                        JarvisEngine.setWake(on)
                    }
                }
                Text(
                    "☰", color = TextC.copy(alpha = 0.7f), fontSize = 22.sp,
                    modifier = Modifier.clickable { showHistory = true }.padding(start = 10.dp, top = 6.dp, bottom = 6.dp, end = 2.dp)
                )
                Text(
                    "⚙", color = TextC.copy(alpha = 0.7f), fontSize = 22.sp,
                    modifier = Modifier.clickable { showSettings = true }.padding(start = 10.dp, top = 6.dp, bottom = 6.dp, end = 2.dp)
                )
            }

            if (JarvisEngine.planNote.isNotBlank()) {
                Text(
                    "◌  " + JarvisEngine.planNote, color = Gold, fontSize = 11.sp, letterSpacing = 1.sp,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }

            // Gespräch
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth().padding(top = 10.dp),
                state = listState,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                itemsIndexed(msgs) { i, m -> TranscriptLine(m, animate = i == msgs.lastIndex && !m.fromUser) }
            }

            // WhatsApp-Bestätigung
            if (pending != null) {
                ConfirmCard("WHATSAPP · NACHRICHT VORBEREITEN") {
                    Text("An: ${pending.name}", color = TextC, fontSize = 15.sp)
                    Text(pending.text, color = TextC, fontSize = 15.sp, fontWeight = FontWeight.Light)
                    if (pending.number == null) {
                        Text("Keine Nummer gefunden – Kontakt wählst du in WhatsApp.", color = Gold, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        HudButton("BESTÄTIGEN", filled = true) { JarvisEngine.confirmPending() }
                        HudButton("ABBRECHEN", accent = Gold) { JarvisEngine.cancelPending() }
                    }
                }
            }

            // Bestätigung für Bildschirmsteuerung
            val ac = JarvisEngine.agentConfirm
            if (ac != null) {
                ConfirmCard("BILDSCHIRMSTEUERUNG · BESTÄTIGEN") {
                    Text(ac.text, color = TextC, fontSize = 15.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        HudButton("JA", filled = true) { JarvisEngine.answerAgent(true) }
                        HudButton("NEIN", accent = Gold) { JarvisEngine.answerAgent(false) }
                    }
                }
            }

            // Plan zur Bestätigung
            val pl = JarvisEngine.plan
            if (pl != null) {
                ConfirmCard(if (pl.running) "PLAN · WIRD AUSGEFÜHRT" else "PLAN · BITTE PRÜFEN") {
                    Column(Modifier.heightIn(max = 240.dp).verticalScroll(rememberScrollState())) {
                        if (pl.summary.isNotBlank()) Text(pl.summary, color = TextC, fontSize = 14.sp, fontWeight = FontWeight.Light)
                        Spacer(Modifier.height(6.dp))
                        pl.steps.forEachIndexed { i, s ->
                            Text(
                                (if (pl.running && i < pl.done) "✓ " else "${i + 1}. ") + s.title,
                                color = if (pl.running && i < pl.done) Cyan else TextC, fontSize = 14.sp,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                        }
                        pl.assumptions.forEach { Text("Annahme: $it", color = Gold.copy(alpha = 0.8f), fontSize = 12.sp) }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (!pl.running) HudButton("STARTEN", filled = true) { JarvisEngine.confirmPlan() }
                        HudButton(if (pl.running) "ANHALTEN" else "VERWERFEN", accent = Gold) { JarvisEngine.cancelPlan() }
                    }
                    if (!pl.running) {
                        Text(
                            "Oder schreibe bzw. sage, was ich am Plan ändern soll.",
                            color = TextC.copy(alpha = 0.5f), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            }

            // Eingabeleiste: kleiner Reaktor als Mikrofon, Textfeld, Senden
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("📷", color = Cyan, fontSize = 19.sp, modifier = Modifier.clickable { cameraLauncher.launch(null) }.padding(horizontal = 5.dp, vertical = 2.dp))
                    Text("Kamera", color = TextC.copy(alpha = 0.55f), fontSize = 8.sp, modifier = Modifier.clickable { cameraLauncher.launch(null) })
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("▧", color = Gold, fontSize = 21.sp, modifier = Modifier.clickable { galleryLauncher.launch("image/*") }.padding(horizontal = 7.dp, vertical = 1.dp))
                    Text("Galerie", color = TextC.copy(alpha = 0.55f), fontSize = 8.sp, modifier = Modifier.clickable { galleryLauncher.launch("image/*") })
                }
                JarvisOrb(status, 58.dp) { JarvisEngine.micPressed() }
                Spacer(Modifier.width(6.dp))
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Befehl eingeben …", color = TextC.copy(alpha = 0.35f)) },
                    singleLine = true,
                    shape = RoundedCornerShape(26.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Cyan.copy(alpha = 0.8f),
                        unfocusedBorderColor = Cyan.copy(alpha = 0.25f),
                        cursorColor = Cyan,
                        focusedTextColor = TextC,
                        unfocusedTextColor = TextC
                    )
                )
                Spacer(Modifier.width(8.dp))
                HudButton("▶", filled = true) {
                    if (input.isNotBlank()) {
                        JarvisEngine.handleUserText(input.trim())
                        input = ""
                    }
                }
            }
        }
    }

    if (showSettings) SettingsDialog { showSettings = false }
    if (showHistory) HistoryScreen { showHistory = false }
}

@Composable
private fun ConfirmCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .background(Color(0x1AFFC857), shape)
            .border(1.dp, Gold.copy(alpha = 0.45f), shape)
            .padding(14.dp)
    ) {
        Text(title, color = Gold, fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        content()
    }
}

@Composable
fun TranscriptLine(m: ChatMsg, animate: Boolean) {
    if (m.fromUser) {
        Text(
            m.text,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.End,
            style = TextStyle(color = Cyan.copy(alpha = 0.8f), fontSize = 14.sp, fontWeight = FontWeight.Medium)
        )
    } else {
        val style = TextStyle(color = TextC, fontSize = 16.sp, fontWeight = FontWeight.Light, lineHeight = 22.sp)
        val mod = Modifier.fillMaxWidth()
        if (animate) TypeText(m.text, style, mod) else Text(m.text, style = style, modifier = mod)
    }
}

@Composable
fun BlinkDot() {
    val t = rememberInfiniteTransition(label = "dot")
    val a by t.animateFloat(
        0.25f, 1f,
        infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "dota"
    )
    Canvas(Modifier.size(6.dp)) {
        drawCircle(Cyan.copy(alpha = a))
    }
}
