package de.jarvis.assistant

import android.content.Context
import android.content.Intent
import java.util.Locale

sealed class Cmd {
    object Stop : Cmd()
    object Time : Cmd()
    object Date : Cmd()
    data class OpenApp(val name: String) : Cmd()
    data class WhatsApp(val name: String, val text: String) : Cmd()
    data class Ai(val text: String) : Cmd()
}

data class AppInfo(val label: String, val pkg: String)

object Commands {
    private val STOP = setOf(
        "stopp", "stop", "halt", "ruhe", "sei still", "hör auf", "abbrechen",
        "das reicht", "danke", "dankeschön", "danke dir", "tschüss", "ende"
    )
    private val YES = setOf("ja", "jawohl", "okay", "ok", "genau", "klar", "passt", "bestätigen", "bestätige", "senden", "mach", "gerne", "bitte")
    private val NO = setOf("nein", "nee", "abbrechen", "abbruch", "stopp", "stop", "nicht", "lieber")

    private val wakePrefix = Regex("""^(?:hey |hallo |hi |ok )?jarvis[,.:!]?\s*""", RegexOption.IGNORE_CASE)

    private val waA = Regex(
        """(?:schreib|schick|send)\w*\s+(?:eine?\s+)?(?:whatsapp[- ]?)?(?:nachricht\s+)?(?:an\s+)?(.+?)\s+(?:auf|per|über|via|bei)\s+whatsapp\s*[:,]?\s*(.+)""",
        RegexOption.IGNORE_CASE
    )
    private val waC = Regex(
        """whatsapp[- ]?(?:nachricht\s+)?an\s+([^\s:,]+)\s*[:,]?\s*(.+)""",
        RegexOption.IGNORE_CASE
    )
    private val openRe = Regex(
        """^(?:öffne|öffnen|starte|starten|open|start)\s+(?:bitte\s+)?(?:die\s+|den\s+|das\s+)?(?:app\s+)?(.+?)(?:\s+(?:bitte|auf))?\s*\z""",
        RegexOption.IGNORE_CASE
    )
    private val textLead = Regex("""^(?:dass|und sag(?:e)? (?:ihm|ihr|ihnen)(?: dass)?)\s+""", RegexOption.IGNORE_CASE)

    fun parse(raw: String): Cmd {
        val t = raw.trim().replace(wakePrefix, "").trim()
        val low = t.lowercase(Locale.GERMAN).trimEnd('.', '!', '?')

        if (low in STOP) return Cmd.Stop
        if (low.contains("wie spät") || low.contains("uhrzeit")) return Cmd.Time
        if (low.contains("welches datum") || low.contains("welcher tag") || low.contains("welchen tag") ||
            low.contains("welcher wochentag")
        ) return Cmd.Date

        waA.find(t)?.let { return Cmd.WhatsApp(it.groupValues[1].trim(), cleanText(it.groupValues[2])) }
        waC.find(t)?.let { return Cmd.WhatsApp(it.groupValues[1].trim(), cleanText(it.groupValues[2])) }
        openRe.find(t)?.let { return Cmd.OpenApp(it.groupValues[1].trim()) }

        return Cmd.Ai(t.ifEmpty { raw.trim() })
    }

    private fun cleanText(s: String): String =
        s.trim().replace(textLead, "").trim().replaceFirstChar { it.uppercase() }

    /** true = Ja, false = Nein, null = unklar */
    fun yesNo(text: String): Boolean? {
        val words = text.lowercase(Locale.GERMAN).split(Regex("[^\\p{L}]+")).filter { it.isNotBlank() }
        if (words.any { it in NO }) return false
        if (words.any { it in YES }) return true
        return null
    }

    private fun norm(s: String) = s.lowercase(Locale.GERMAN).replace(Regex("[^\\p{L}\\p{N}]"), "")

    fun installedApps(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
    }

    fun findApp(ctx: Context, query: String): AppInfo? {
        val q = norm(query)
        if (q.isEmpty()) return null
        val apps = installedApps(ctx).map { it to norm(it.label) }
        return (apps.firstOrNull { it.second == q }
            ?: apps.firstOrNull { it.second.startsWith(q) }
            ?: apps.firstOrNull { it.second.contains(q) }
            ?: apps.firstOrNull { it.second.length >= 3 && q.contains(it.second) })?.first
    }
}
