package de.jarvis.assistant

import java.util.Calendar
import java.util.Locale

/** Versteht Angaben wie „morgen um 15 Uhr“, „in 20 Minuten“, „am Freitag um halb vier“, „am 12.3.“. */
object DateParse {
    /** time = Zeitpunkt in ms (oder null), hour/minute nur wenn eine Uhrzeit genannt wurde, rest = Text ohne Zeitangabe. */
    data class R(val time: Long?, val hour: Int?, val minute: Int?, val hasDay: Boolean, val rest: String)

    private val I = RegexOption.IGNORE_CASE

    private val numWords = mapOf(
        "ein" to 1, "eine" to 1, "einer" to 1, "einem" to 1, "zwei" to 2, "drei" to 3, "vier" to 4, "fünf" to 5,
        "sechs" to 6, "sieben" to 7, "acht" to 8, "neun" to 9, "zehn" to 10, "fünfzehn" to 15, "zwanzig" to 20,
        "dreißig" to 30, "vierzig" to 40, "fünfundvierzig" to 45, "sechzig" to 60
    )
    private val weekdays = mapOf(
        "montag" to Calendar.MONDAY, "dienstag" to Calendar.TUESDAY, "mittwoch" to Calendar.WEDNESDAY,
        "donnerstag" to Calendar.THURSDAY, "freitag" to Calendar.FRIDAY, "samstag" to Calendar.SATURDAY,
        "sonnabend" to Calendar.SATURDAY, "sonntag" to Calendar.SUNDAY
    )

    private val relRe = Regex("""\bin\s+(\d+|[a-zäöüß]+)\s+(sekunden?|minuten?|stunden?|tagen?|wochen?)\b""", I)
    private val dateRe = Regex("""\b(?:am\s+)?(\d{1,2})\.(\d{1,2})\.(\d{2,4})?""")
    private val uhrRe = Regex("""\b(?:um\s+)?(\d{1,2})(?:[:.](\d{2}))?\s*uhr(?:\s+(\d{2}))?\b""", I)
    private val colonRe = Regex("""\b(?:um\s+)?(\d{1,2}):(\d{2})\b""")
    private val halbRe = Regex("""\b(?:um\s+)?halb\s+(\d{1,2})\b""", I)
    private val umRe = Regex("""\bum\s+(\d{1,2})\b(?![.:])""", I)
    private val pmRe = Regex("""\b(abends?|nachmittags?|nachts)\b""", I)
    private val amRe = Regex("""\b(morgens|früh|vormittags)\b""", I)

    private fun clean(x: String): String {
        var r = x.replace(Regex("\\s+"), " ").trim().trim(',', '.', ':', ';', '!', '?', ' ')
        val lead = Regex("^(?:um|am|an|für|dass|daran|zu|ein|bitte|nämlich)\\s+", I)
        val trail = Regex("\\s+(?:um|am|an|für|ein|bitte)$", I)
        var prev: String
        do {
            prev = r
            r = r.replace(lead, "").replace(trail, "").trim(',', ' ')
        } while (r != prev)
        return r
    }

    fun parse(input: String, now: Calendar = Calendar.getInstance()): R {
        var s = input
        val cal = now.clone() as Calendar
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)

        // 1) relative Angabe: „in 20 Minuten“
        relRe.find(s)?.let { m ->
            val n = m.groupValues[1].toIntOrNull() ?: numWords[m.groupValues[1].lowercase(Locale.GERMAN)]
            if (n != null) {
                val u = m.groupValues[2].lowercase(Locale.GERMAN)
                val field = when {
                    u.startsWith("sekunde") -> Calendar.SECOND
                    u.startsWith("minute") -> Calendar.MINUTE
                    u.startsWith("stunde") -> Calendar.HOUR_OF_DAY
                    u.startsWith("tag") -> Calendar.DAY_OF_YEAR
                    else -> Calendar.WEEK_OF_YEAR
                }
                val c2 = now.clone() as Calendar
                c2.add(field, n)
                c2.set(Calendar.MILLISECOND, 0)
                return R(c2.timeInMillis, c2.get(Calendar.HOUR_OF_DAY), c2.get(Calendar.MINUTE), true, clean(s.removeRange(m.range)))
            }
        }

        // 2) Tag
        var dayAdd: Int? = null
        var absolute = false
        val over = Regex("\\bübermorgen\\b", I)
        val morgen = Regex("\\bmorgen\\b", I)
        val heute = Regex("\\bheute\\b", I)
        when {
            over.containsMatchIn(s) -> { dayAdd = 2; s = s.replace(over, " ") }
            morgen.containsMatchIn(s) -> { dayAdd = 1; s = s.replace(morgen, " ") }
            heute.containsMatchIn(s) -> { dayAdd = 0; s = s.replace(heute, " ") }
        }
        dateRe.find(s)?.let { m ->
            val d = m.groupValues[1].toInt()
            val mo = m.groupValues[2].toInt()
            if (d in 1..31 && mo in 1..12) {
                var y = m.groupValues[3].toIntOrNull() ?: cal.get(Calendar.YEAR)
                if (y < 100) y += 2000
                cal.set(y, mo - 1, d)
                if (m.groupValues[3].isEmpty() && cal.before(now)) cal.add(Calendar.YEAR, 1)
                absolute = true
                s = s.removeRange(m.range)
            }
        }
        if (dayAdd == null && !absolute) {
            for ((name, wd) in weekdays) {
                val re = Regex("\\b(?:am\\s+|nächsten\\s+|kommenden\\s+)?$name\\b", I)
                val m = re.find(s) ?: continue
                var diff = (wd - now.get(Calendar.DAY_OF_WEEK) + 7) % 7
                if (diff == 0) diff = 7
                dayAdd = diff
                s = s.removeRange(m.range)
                break
            }
        }

        // 3) Uhrzeit
        var h: Int? = null
        var mi = 0
        val pm = pmRe.containsMatchIn(s)
        val am = amRe.containsMatchIn(s)
        fun take(m: MatchResult, hh: Int, mm: Int) {
            h = hh; mi = mm; s = s.removeRange(m.range)
        }
        val m1 = uhrRe.find(s)
        val m2 = colonRe.find(s)
        val m3 = halbRe.find(s)
        val m4 = umRe.find(s)
        when {
            m1 != null -> take(m1, m1.groupValues[1].toInt(), (m1.groupValues[2].ifEmpty { m1.groupValues[3] }).toIntOrNull() ?: 0)
            m2 != null -> take(m2, m2.groupValues[1].toInt(), m2.groupValues[2].toInt())
            m3 != null -> {
                val n = m3.groupValues[1].toInt()
                take(m3, if (n == 1) 12 else n - 1, 30)
            }
            m4 != null -> take(m4, m4.groupValues[1].toInt(), 0)
        }
        s = s.replace(pmRe, " ").replace(amRe, " ")
        var hour = h
        if (hour != null) {
            if (pm && hour < 12) hour += 12
            if (am && hour == 12) hour = 0
            if (hour !in 0..23 || mi !in 0..59) hour = null
        }

        if (dayAdd == null && !absolute && hour == null) {
            return R(null, null, null, false, clean(input))
        }

        if (dayAdd != null) cal.add(Calendar.DAY_OF_YEAR, dayAdd)
        val hasDay = dayAdd != null || absolute
        if (hour != null) {
            cal.set(Calendar.HOUR_OF_DAY, hour); cal.set(Calendar.MINUTE, mi)
            if (!hasDay && cal.timeInMillis <= now.timeInMillis) cal.add(Calendar.DAY_OF_YEAR, 1)
        } else {
            cal.set(Calendar.HOUR_OF_DAY, 9); cal.set(Calendar.MINUTE, 0)
        }
        return R(cal.timeInMillis, hour, if (hour != null) mi else null, hasDay, clean(s))
    }
}
