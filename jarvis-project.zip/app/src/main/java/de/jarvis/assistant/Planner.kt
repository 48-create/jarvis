package de.jarvis.assistant

import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class PlanStep(val title: String, val kind: String, val command: String)

data class PlanState(
    val goal: String,
    val summary: String,
    val assumptions: List<String>,
    val steps: List<PlanStep>,
    val running: Boolean = false,
    val done: Int = 0
)

/**
 * Erst nachdenken, dann handeln: Bei größeren Aufgaben erstellt die KI einen Plan, der dem Nutzer
 * vorgelegt wird. Ausgeführt wird erst nach seinem Ja. Der Plan darf nur Schritte enthalten,
 * die JARVIS wirklich selbst ausführen kann.
 */
object Planner {
    const val ANSWER_SYS =
        "Du bist JARVIS, ein höflicher deutscher Sprachassistent. Beantworte die Aufgabe knapp und sachlich in " +
            "höchstens vier Sätzen auf Deutsch, ohne Markdown, Listen oder Sternchen. Du hast keinen Internetzugriff " +
            "außer für Wetter und Nachrichten. Erfinde keine Fakten und sage ehrlich, wenn du etwas nicht sicher weißt."

    fun available(): Boolean = AiActions.available()

    private val verbs = Regex(
        "(?<!\\p{L})(?:trag|erinner|stell|schreib|öffn|such|notier|setz|plan|erstell|organisier|buch|schick|send|ruf|" +
            "bereit|recherchier|vergleich|sortier|zusammenfass|lösch|änder|verschieb|prüf)\\p{L}*",
        RegexOption.IGNORE_CASE
    )
    private val connectors = Regex(
        "(?<!\\p{L})(?:und|dann|danach|anschließend|außerdem|zusätzlich|sowie|bevor|nachdem)(?!\\p{L})",
        RegexOption.IGNORE_CASE
    )
    private val triggers = Regex(
        "(mach(e)? (mir )?(einen )?plan|erstelle (mir )?(einen )?plan|(?<!\\p{L})plane |planung|organisier|" +
            "kümmere dich|denk(e)? (gründlich|in ruhe)|überleg dir|zeitplan|strategie|schritt für schritt|ausführlich)",
        RegexOption.IGNORE_CASE
    )

    /** Grobe, schnelle Einschätzung ohne KI-Aufruf, ob ein Satz eine größere Aufgabe ist. */
    fun looksComplex(text: String): Boolean {
        val s = text.trim()
        if (s.length < 25) return false
        if (triggers.containsMatchIn(s)) return true
        val v = verbs.findAll(s).count()
        val c = connectors.findAll(s).count()
        return (v >= 3 && s.length >= 60) || (s.length >= 110 && c >= 2 && v >= 2)
    }

    private fun system(): String {
        val now = SimpleDateFormat("EEEE, d. MMMM yyyy, HH:mm 'Uhr'", Locale.GERMANY).format(Date())
        val screen = Prefs.screenControl && Actions.accessibilityEnabled(JarvisApp.instance) &&
            SendAssistService.instance != null
        return "Du bist das Planungsmodul von J.A.R.V.I.S., einem deutschen Sprachassistenten auf dem Handy des Nutzers. " +
            "Jetzt ist $now. " +
            "Denke gründlich und in Ruhe nach, bevor du antwortest: Was will der Nutzer wirklich, welche Reihenfolge ist " +
            "sinnvoll, was kann schiefgehen? " +
            "Ist die Aufgabe in Wahrheit einfach (ein einzelner Befehl oder eine Frage), antworte nur mit {\"simple\":true}. " +
            "Sonst erstelle einen Plan. Er darf NUR Schritte enthalten, die JARVIS selbst ausführen kann. " +
            "Erlaubte Arten (kind): \"app\" = Aktion in den Dashboard-Mini-Apps (Termin eintragen, verschieben oder " +
            "löschen; Erinnerung; Notiz; Aufgabe; Wecker; Timer; Wetter ansagen; Nachrichten vorlesen). " +
            (if (screen) "\"screen\" = andere Apps per Bildschirmsteuerung bedienen (öffnen, suchen, tippen; niemals bezahlen oder bestellen). "
            else "Die Bildschirmsteuerung ist AUS: verwende keine Schritte der Art screen. ") +
            "\"answer\" = Auskunft oder Analyse aus eigenem Wissen (kein Internet). " +
            "\"todo\" = etwas, das der Nutzer selbst tun muss; es wird als Aufgabe eingetragen. " +
            "Nicht möglich sind zum Beispiel Anrufe, Zahlungen, Bestellungen und Live-Websuche; das gehört als todo in den " +
            "Plan oder in die Annahmen. " +
            "Jeder Schritt hat: title (kurz, höchstens 8 Wörter), kind und command (ein vollständiger deutscher Befehl in " +
            "Alltagssprache mit allen Details wie Datum und Uhrzeit, der für sich allein ausführbar ist; Zeitangaben " +
            "rechnest du vom jetzigen Zeitpunkt aus). " +
            "Höchstens 8 Schritte in sinnvoller Reihenfolge. Fehlen Angaben, triff vernünftige Annahmen und nenne sie in " +
            "assumptions. " +
            "Antworte NUR mit JSON: {\"simple\":false,\"goal\":\"...\",\"summary\":\"ein bis zwei Sätze\"," +
            "\"assumptions\":[\"...\"],\"steps\":[{\"title\":\"...\",\"kind\":\"app\",\"command\":\"...\"}]}. " +
            "Vorhandene Daten des Nutzers: ${MiniData.summary()}"
    }

    private fun parse(raw: String): JSONObject? {
        val clean = raw.replace(Regex("```(?:json)?"), "").trim()
        return try {
            JSONObject(clean)
        } catch (_: Exception) {
            val a = clean.indexOf('{')
            val b = clean.lastIndexOf('}')
            if (a >= 0 && b > a) try { JSONObject(clean.substring(a, b + 1)) } catch (_: Exception) { null } else null
        }
    }

    /** Liefert null, wenn die Aufgabe doch einfach ist. Wirft eine Exception mit deutscher Meldung bei Fehlern. */
    suspend fun make(goal: String): PlanState? {
        val raw = GeminiClient.generate(system(), goal, null, true)
        val o = parse(raw)
            ?: throw Exception("Der Plan der KI war unverständlich. Bitte formuliere die Aufgabe noch einmal.")
        if (o.optBoolean("simple", false)) return null
        val arr = o.optJSONArray("steps") ?: return null
        val steps = ArrayList<PlanStep>()
        for (i in 0 until arr.length()) {
            val x = arr.optJSONObject(i) ?: continue
            val cmd = x.optString("command").trim()
            if (cmd.isEmpty()) continue
            val title = x.optString("title").trim().ifBlank { cmd.take(40) }
            var kind = x.optString("kind").trim().lowercase(Locale.ROOT)
            if (kind !in setOf("app", "screen", "answer", "todo")) kind = "app"
            steps.add(PlanStep(title, kind, cmd))
        }
        if (steps.isEmpty()) return null
        val ass = ArrayList<String>()
        val aa = o.optJSONArray("assumptions")
        if (aa != null) {
            for (i in 0 until aa.length()) {
                val t = aa.optString(i).trim()
                if (t.isNotEmpty()) ass.add(t)
            }
        }
        return PlanState(o.optString("goal").ifBlank { goal }, o.optString("summary").trim(), ass, steps.take(8))
    }
}
