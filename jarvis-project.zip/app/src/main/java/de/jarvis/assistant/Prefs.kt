package de.jarvis.assistant

import android.content.Context

object Prefs {
    private fun sp() = JarvisApp.instance.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    /** Mehrere Gemini-Schlüssel, einer pro Zeile. Der alte Einzelschlüssel wird weiter gelesen. */
    var apiKeys: List<String>
        get() {
            val multi = sp().getString("keys", null)
            val raw = if (multi != null) multi else sp().getString("key", "") ?: ""
            return raw.split('\n', ',', ' ', ';').map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        }
        set(v) = sp().edit().putString("keys", v.joinToString("\n")).apply()

    val apiKey: String get() = apiKeys.firstOrNull() ?: ""

    /** Reserve-Modelle, durch Komma getrennt; werden bei Ausfall des Hauptmodells der Reihe nach probiert. */
    var fallbackModels: String
        get() = sp().getString("fallback", "gemini-2.5-flash-lite") ?: ""
        set(v) = sp().edit().putString("fallback", v.trim()).apply()

    /** Kurze Alltagsfragen an das schnelle Modell, Bildschirm und lange Anfragen an das Hauptmodell. */
    var autoModel: Boolean
        get() = sp().getBoolean("automodel", true)
        set(v) = sp().edit().putBoolean("automodel", v).apply()

    var fastModel: String
        get() = sp().getString("fastmodel", "gemini-2.5-flash-lite") ?: "gemini-2.5-flash-lite"
        set(v) = sp().edit().putString("fastmodel", v.trim()).apply()

    var city: String
        get() = sp().getString("city", "") ?: ""
        set(v) = sp().edit().putString("city", v.trim()).apply()

    var dashOrder: List<String>
        get() {
            val saved = (sp().getString("dash", "") ?: "").split(',').filter { it in Dash.ALL }
            return saved + Dash.ALL.filter { it !in saved }
        }
        set(v) = sp().edit().putString("dash", v.joinToString(",")).apply()

    var usageJson: String
        get() = sp().getString("usage", "{}") ?: "{}"
        set(v) = sp().edit().putString("usage", v).apply()

    var model: String
        get() = sp().getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        set(v) = sp().edit().putString("model", v.trim()).apply()

    var speak: Boolean
        get() = sp().getBoolean("speak", true)
        set(v) = sp().edit().putBoolean("speak", v).apply()

    var title: String
        get() = sp().getString("title", "Sir") ?: "Sir"
        set(v) = sp().edit().putString("title", v.trim()).apply()

    var pitch: Float
        get() = sp().getFloat("pitch", 0.85f)
        set(v) = sp().edit().putFloat("pitch", v).apply()

    var rate: Float
        get() = sp().getFloat("rate", 0.95f)
        set(v) = sp().edit().putFloat("rate", v).apply()

    var voice: String
        get() = sp().getString("voice", "") ?: ""
        set(v) = sp().edit().putString("voice", v).apply()

    var autoSend: Boolean
        get() = sp().getBoolean("autosend", false)
        set(v) = sp().edit().putBoolean("autosend", v).apply()

    var picoKey: String
        get() = sp().getString("picokey", "") ?: ""
        set(v) = sp().edit().putString("picokey", v.trim()).apply()

    var wakeOn: Boolean
        get() = sp().getBoolean("wakeon", false)
        set(v) = sp().edit().putBoolean("wakeon", v).apply()

    var screenControl: Boolean
        get() = sp().getBoolean("screenctl", false)
        set(v) = sp().edit().putBoolean("screenctl", v).apply()
}
