package de.jarvis.assistant

import android.content.Context

object Prefs {
    private fun sp() = JarvisApp.instance.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp().getString("key", "") ?: ""
        set(v) = sp().edit().putString("key", v.trim()).apply()

    var model: String
        get() = sp().getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        set(v) = sp().edit().putString("model", v.trim()).apply()

    var speak: Boolean
        get() = sp().getBoolean("speak", true)
        set(v) = sp().edit().putBoolean("speak", v).apply()

    var title: String
        get() = sp().getString("title", "Sir") ?: "Sir"
        set(v) = sp().edit().putString("title", v.trim()).apply()

    var pitch: Float
        get() = sp().getFloat("pitch", 0.85f)
        set(v) = sp().edit().putFloat("pitch", v).apply()

    var rate: Float
        get() = sp().getFloat("rate", 0.95f)
        set(v) = sp().edit().putFloat("rate", v).apply()

    var voice: String
        get() = sp().getString("voice", "") ?: ""
        set(v) = sp().edit().putString("voice", v).apply()

    var autoSend: Boolean
        get() = sp().getBoolean("autosend", false)
        set(v) = sp().edit().putBoolean("autosend", v).apply()

    var picoKey: String
        get() = sp().getString("picokey", "") ?: ""
        set(v) = sp().edit().putString("picokey", v.trim()).apply()

    var wakeOn: Boolean
        get() = sp().getBoolean("wakeon", false)
        set(v) = sp().edit().putBoolean("wakeon", v).apply()
}
