package de.jarvis.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Prefs {
    private fun sp() = JarvisApp.instance.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    private fun legacyKeys(): List<String> {
        val multi = sp().getString("keys", null)
        val raw = if (multi != null) multi else sp().getString("key", "") ?: ""
        return raw.split('\n', ',', ' ', ';').map { it.trim() }.filter { it.isNotEmpty() }.distinct()
    }

    /** Benannte Schlüssel-Ablagen (Gemini, NVIDIA, eigene URL) in Prioritätsreihenfolge. Alte Einzelschlüssel werden übernommen. */
    var keyEntries: List<KeyEntry>
        get() {
            val raw = sp().getString("keyentries", null)
                ?: return legacyKeys().mapIndexed { i, k -> KeyEntry(name = "Gemini ${i + 1}", provider = Provider.GEMINI, key = k) }
            return try {
                val a = JSONArray(raw)
                (0 until a.length()).map { KeyEntry.fromJson(a.getJSONObject(it)) }
            } catch (e: Exception) {
                emptyList()
            }
        }
        set(v) {
            val a = JSONArray()
            v.forEach { a.put(it.toJson()) }
            sp().edit().putString("keyentries", a.toString()).apply()
        }

    /** Nur die Gemini-Schlüssel (für Bildschirm-Analyse und Zähler). */
    val apiKeys: List<String>
        get() = keyEntries.filter { it.provider == Provider.GEMINI && it.key.isNotBlank() }.map { it.key }

    val apiKey: String get() = apiKeys.firstOrNull() ?: ""

    /** Reserve-Modelle, durch Komma getrennt; werden bei Ausfall des Hauptmodells der Reihe nach probiert. */
    var fallbackModels: String
        get() = sp().getString("fallback", "gemini-2.5-flash-lite") ?: ""
        set(v) = sp().edit().putString("fallback", v.trim()).apply()

    /** Kurze Alltagsfragen an das schnelle Modell, Bildschirm und lange Anfragen an das Hauptmodell. */
    var autoModel: Boolean
        get() = sp().getBoolean("automodel", true)
        set(v) = sp().edit().putBoolean("automodel", v).apply()

    var fastModel: String
        get() = sp().getString("fastmodel", "gemini-2.5-flash-lite") ?: "gemini-2.5-flash-lite"
        set(v) = sp().edit().putString("fastmodel", v.trim()).apply()

    var city: String
        get() = sp().getString("city", "") ?: ""
        set(v) = sp().edit().putString("city", v.trim()).apply()

    var dashOrder: List<String>
        get() {
            val saved = (sp().getString("dash", "") ?: "").split(',').filter { it in Dash.ALL }
            return saved + Dash.ALL.filter { it !in saved }
        }
        set(v) = sp().edit().putString("dash", v.joinToString(",")).apply()

    var usageJson: String
        get() = sp().getString("usage", "{}") ?: "{}"
        set(v) = sp().edit().putString("usage", v).apply()

    var model: String
        get() = sp().getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        set(v) = sp().edit().putString("model", v.trim()).apply()

    var speak: Boolean
        get() = sp().getBoolean("speak", true)
        set(v) = sp().edit().putBoolean("speak", v).apply()

    var title: String
        get() = sp().getString("title", "Sir") ?: "Sir"
        set(v) = sp().edit().putString("title", v.trim()).apply()

    var pitch: Float
        get() = sp().getFloat("pitch", 0.85f)
        set(v) = sp().edit().putFloat("pitch", v).apply()

    var rate: Float
        get() = sp().getFloat("rate", 0.95f)
        set(v) = sp().edit().putFloat("rate", v).apply()

    var voice: String
        get() = sp().getString("voice", "") ?: ""
        set(v) = sp().edit().putString("voice", v).apply()

    var autoSend: Boolean
        get() = sp().getBoolean("autosend", false)
        set(v) = sp().edit().putBoolean("autosend", v).apply()

    var picoKey: String
        get() = sp().getString("picokey", "") ?: ""
        set(v) = sp().edit().putString("picokey", v.trim()).apply()

    var wakeOn: Boolean
        get() = sp().getBoolean("wakeon", false)
        set(v) = sp().edit().putBoolean("wakeon", v).apply()

    var screenControl: Boolean
        get() = sp().getBoolean("screenctl", false)
        set(v) = sp().edit().putBoolean("screenctl", v).apply()

    // ---------- Sicherung ----------
    var backupTree: String
        get() = sp().getString("backuptree", "") ?: ""
        set(v) = sp().edit().putString("backuptree", v).apply()

    var backupDoc: String
        get() = sp().getString("backupdoc", "") ?: ""
        set(v) = sp().edit().putString("backupdoc", v).apply()

    /** Gerätespezifisch, wird nicht in die Sicherung geschrieben. */
    private val SKIP = setOf("backuptree", "backupdoc")

    /** Alle Einstellungen (Schlüssel, Modelle, Ort, Stimme, Anrede, Dashboard …) als JSON. */
    fun exportAll(): JSONObject {
        val o = JSONObject()
        for ((k, v) in sp().all) {
            if (k in SKIP) continue
            val e = JSONObject()
            when (v) {
                is Boolean -> e.put("t", "b").put("v", v)
                is Int -> e.put("t", "i").put("v", v)
                is Long -> e.put("t", "l").put("v", v)
                is Float -> e.put("t", "f").put("v", v.toDouble())
                is String -> e.put("t", "s").put("v", v)
                is Set<*> -> e.put("t", "ss").put("v", JSONArray(v.map { it.toString() }))
                else -> continue
            }
            o.put(k, e)
        }
        return o
    }

    fun importAll(o: JSONObject) {
        val ed = sp().edit()
        for (k in o.keys()) {
            if (k in SKIP) continue
            val e = o.optJSONObject(k) ?: continue
            try {
                when (e.optString("t")) {
                    "b" -> ed.putBoolean(k, e.getBoolean("v"))
                    "i" -> ed.putInt(k, e.getInt("v"))
                    "l" -> ed.putLong(k, e.getLong("v"))
                    "f" -> ed.putFloat(k, e.getDouble("v").toFloat())
                    "s" -> ed.putString(k, e.getString("v"))
                    "ss" -> {
                        val a = e.getJSONArray("v")
                        ed.putStringSet(k, (0 until a.length()).map { a.getString(it) }.toSet())
                    }
                }
            } catch (_: Exception) {
            }
        }
        ed.apply()
    }

    /** Anrede ohne Kommas: „Guten Morgen, Sir,“ wird zu „Guten Morgen Sir“ (Anzeige und Sprachausgabe). */
    fun tidy(text: String): String {
        val a = Regex.escape(title.ifBlank { "Sir" })
        return text
            .replace(Regex(",\\s*($a)(?![\\p{L}])", RegexOption.IGNORE_CASE), " \$1")
            .replace(Regex("(?<![\\p{L}])($a)\\s*,\\s*", RegexOption.IGNORE_CASE), "\$1 ")
    }
}
