package de.jarvis.assistant

import android.content.Context

object Prefs {
    private fun sp() = JarvisApp.instance.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp().getString("key", "") ?: ""
        set(v) = sp().edit().putString("key", v.trim()).apply()

    var model: String
        get() = sp().getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        set(v) = sp().edit().putString("model", v.trim()).apply()

    var speak: Boolean
        get() = sp().getBoolean("speak", true)
        set(v) = sp().edit().putBoolean("speak", v).apply()
}
