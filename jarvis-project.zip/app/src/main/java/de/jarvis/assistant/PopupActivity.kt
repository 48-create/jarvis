package de.jarvis.assistant

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** Kleines Jarvis-Fenster, das über dem Sperrbildschirm erscheint, wenn das Aktivierungswort erkannt wurde. */
class PopupActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Cyan, onPrimary = Color.Black, secondary = Gold,
                    background = Dark, surface = Panel, onSurface = TextC, onBackground = TextC
                )
            ) { PopupScreen { finish() } }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_ASSIST) JarvisEngine.onAssistantInvoked()
    }

    override fun onStart() {
        super.onStart()
        JarvisEngine.appVisible = true
    }

    override fun onStop() {
        super.onStop()
        JarvisEngine.appVisible = false
    }
}

@Composable
fun PopupScreen(onClose: () -> Unit) {
    val st = JarvisEngine.status
    val msgs = JarvisEngine.messages
    val lastUser = msgs.lastOrNull { it.fromUser }
    val lastBot = msgs.lastOrNull { !it.fromUser }

    LaunchedEffect(st) {
        if (st == Status.WAKE || st == Status.IDLE) {
            delay(4000)
            onClose()
        }
    }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
        val shape = RoundedCornerShape(24.dp)
        Column(
            Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .background(Brush.verticalGradient(listOf(Panel, Dark)), shape)
                .border(1.dp, Cyan.copy(alpha = 0.5f), shape)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(statusText(st), color = Gold, fontSize = 13.sp)
            Reactor(st) { JarvisEngine.micPressed() }
            if (lastUser != null) Text(lastUser.text, color = Cyan, fontSize = 14.sp)
            if (lastBot != null) Text(lastBot.text, color = TextC, fontSize = 15.sp)
            TextButton(onClick = {
                JarvisEngine.stopAll()
                onClose()
            }) { Text("Schließen", color = Cyan) }
        }
    }
}
