package de.jarvis.assistant

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** Durchsichtiges Jarvis-Fenster: schwebender Orb mit Text darüber, erscheint auch über dem Sperrbildschirm. */
class PopupActivity : ComponentActivity() {
    companion object {
        @Volatile
        var current: PopupActivity? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        current = this
        handleIntent(intent)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Cyan, onPrimary = Color.Black, secondary = Gold,
                    background = Dark, surface = Panel, onSurface = TextC, onBackground = TextC
                )
            ) { PopupScreen { finish() } }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_ASSIST) JarvisEngine.onAssistantInvoked()
    }

    override fun onStart() {
        super.onStart()
        JarvisEngine.appVisible = true
        JarvisEngine.resumeWakeIfWanted()
    }

    override fun onDestroy() {
        if (current === this) current = null
        super.onDestroy()
    }

    override fun onStop() {
        super.onStop()
        JarvisEngine.appVisible = false
    }
}

@Composable
fun PopupScreen(onClose: () -> Unit) {
    val st = JarvisEngine.status
    val startCount = remember { JarvisEngine.messages.size }
    val fresh = JarvisEngine.messages.drop(startCount)
    val lastUser = fresh.lastOrNull { it.fromUser }
    val lastBot = fresh.lastOrNull { !it.fromUser }

    var appear by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { appear = true }
    val sc by animateFloatAsState(
        if (appear) 1f else 0.2f,
        spring(dampingRatio = 0.55f, stiffness = 200f), label = "appear"
    )

    LaunchedEffect(st) {
        if (st == Status.WAKE || st == Status.IDLE) {
            delay(4000)
            onClose()
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                JarvisEngine.stopAll()
                onClose()
            }
    ) {
        // nur ein ganz zarter Schatten unten, damit der Text auf hellen Hintergründen lesbar bleibt
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(460.dp)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.35f))))
        )
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(start = 28.dp, end = 28.dp, bottom = 56.dp)
                .graphicsLayer {
                    scaleX = sc
                    scaleY = sc
                    alpha = sc.coerceIn(0f, 1f)
                },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (lastUser != null) {
                Text(
                    "› " + lastUser.text,
                    textAlign = TextAlign.Center,
                    style = TextStyle(
                        color = Cyan, fontSize = 14.sp, fontFamily = FontFamily.Monospace,
                        shadow = Shadow(Color.Black.copy(alpha = 0.8f), Offset(0f, 2f), 10f)
                    )
                )
                Spacer(Modifier.height(10.dp))
            }
            if (lastBot != null) {
                TypeText(
                    lastBot.text,
                    TextStyle(
                        color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Light,
                        shadow = Shadow(Cyan.copy(alpha = 0.7f), Offset.Zero, 22f)
                    ),
                    align = TextAlign.Center
                )
            }
            if (JarvisEngine.agentConfirm != null) {
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    HudButton("JA", filled = true) { JarvisEngine.answerAgent(true) }
                    HudButton("NEIN", accent = Gold) { JarvisEngine.answerAgent(false) }
                }
            }
            Spacer(Modifier.height(18.dp))
            JarvisOrb(st, 200.dp) { JarvisEngine.micPressed() }
            Text(
                hudLabel(st),
                color = Cyan.copy(alpha = 0.8f), fontSize = 10.sp,
                fontFamily = FontFamily.Monospace, letterSpacing = 3.sp
            )
        }
    }
}
