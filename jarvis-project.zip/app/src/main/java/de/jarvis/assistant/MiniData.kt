package de.jarvis.assistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.compose.runtime.mutableStateListOf
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Dauerhafte JSON-Ablage in filesDir/data. Dieser Ordner bleibt bei APK-Updates erhalten
 * (solange die App nicht deinstalliert wird und die neue APK mit demselben Schlüssel signiert ist).
 */
object Store {
    private val lock = Any()
    private fun dir(): File = File(JarvisApp.instance.filesDir, "data").apply { mkdirs() }

    fun read(name: String): JSONArray {
        synchronized(lock) {
            val f = File(dir(), "$name.json")
            if (!f.exists()) return JSONArray()
            return try {
                JSONArray(f.readText())
            } catch (e: Exception) {
                try {
                    f.copyTo(File(dir(), "$name.broken.json"), overwrite = true)
                } catch (_: Exception) {
                }
                JSONArray()
            }
        }
    }

    fun write(name: String, arr: JSONArray) {
        synchronized(lock) {
            val f = File(dir(), "$name.json")
            val tmp = File(dir(), "$name.json.tmp")
            tmp.writeText(arr.toString())
            if (!tmp.renameTo(f)) {
                f.writeText(arr.toString())
                tmp.delete()
            }
        }
    }

    /** Alle Datenbereiche, die in die Sicherung gehören. */
    val ALL: List<String> get() = MiniData.NAMES + listOf(Chats.CHATS, Chats.PROJECTS, Memory.NAME)
}

/** Beobachtbare Liste, die bei jeder Änderung sofort gespeichert wird. */
class Coll<T>(
    private val name: String,
    private val enc: (T) -> JSONObject,
    private val dec: (JSONObject) -> T
) {
    val items = mutableStateListOf<T>()

    fun load() {
        items.clear()
        val a = Store.read(name)
        for (i in 0 until a.length()) {
            try {
                items.add(dec(a.getJSONObject(i)))
            } catch (_: Exception) {
            }
        }
    }

    fun save() {
        val a = JSONArray()
        items.forEach { a.put(enc(it)) }
        Store.write(name, a)
    }
}

data class Note(val id: Long, val text: String, val created: Long)
data class Todo(val id: Long, val text: String, val done: Boolean, val created: Long)
data class Ev(val id: Long, val title: String, val start: Long)
data class Reminder(val id: Long, val text: String, val at: Long, val fired: Boolean)

object MiniData {
    val NAMES = listOf("notes", "todos", "events", "reminders")

    val notes = Coll<Note>(
        "notes",
        { JSONObject().put("id", it.id).put("text", it.text).put("created", it.created) },
        { Note(it.getLong("id"), it.getString("text"), it.optLong("created")) }
    )
    val todos = Coll<Todo>(
        "todos",
        { JSONObject().put("id", it.id).put("text", it.text).put("done", it.done).put("created", it.created) },
        { Todo(it.getLong("id"), it.getString("text"), it.optBoolean("done"), it.optLong("created")) }
    )
    val events = Coll<Ev>(
        "events",
        { JSONObject().put("id", it.id).put("title", it.title).put("start", it.start) },
        { Ev(it.getLong("id"), it.getString("title"), it.getLong("start")) }
    )
    val reminders = Coll<Reminder>(
        "reminders",
        { JSONObject().put("id", it.id).put("text", it.text).put("at", it.at).put("fired", it.fired) },
        { Reminder(it.getLong("id"), it.getString("text"), it.getLong("at"), it.optBoolean("fired")) }
    )

    private var loaded = false
    private var seq = 0L
    private fun newId(): Long = System.currentTimeMillis() * 100 + (seq++ % 100)

    fun init() {
        if (loaded) return
        loaded = true
        reload()
    }

    fun reload() {
        notes.load(); todos.load(); events.load(); reminders.load()
    }

    /** Kurzfassung aller Dashboard-Daten, damit die KI Fragen dazu beantworten kann („Was steht morgen an?“). */
    fun summary(): String {
        val f = java.text.SimpleDateFormat("EEE d.M. HH:mm", java.util.Locale.GERMANY)
        val sb = StringBuilder()
        val ev = events.items.filter { it.start >= System.currentTimeMillis() - 3_600_000L }.sortedBy { it.start }.take(12)
        sb.append("Termine: ").append(if (ev.isEmpty()) "keine" else ev.joinToString("; ") { "${it.title} (${f.format(java.util.Date(it.start))})" }).append(". ")
        val td = todos.items.filter { !it.done }.take(12)
        sb.append("Offene Aufgaben: ").append(if (td.isEmpty()) "keine" else td.joinToString("; ") { it.text }).append(". ")
        val rm = reminders.items.filter { !it.fired }.sortedBy { it.at }.take(8)
        sb.append("Erinnerungen: ").append(if (rm.isEmpty()) "keine" else rm.joinToString("; ") { "${it.text} (${f.format(java.util.Date(it.at))})" }).append(". ")
        val nt = notes.items.takeLast(6)
        sb.append("Letzte Notizen: ").append(if (nt.isEmpty()) "keine" else nt.joinToString("; ") { it.text.take(80) }).append(".")
        return sb.toString()
    }

    // ---------- Notizen ----------
    fun addNote(text: String): Note {
        val n = Note(newId(), text.trim(), System.currentTimeMillis())
        notes.items.add(n); notes.save(); return n
    }

    fun editNote(id: Long, text: String) {
        val i = notes.items.indexOfFirst { it.id == id }
        if (i >= 0) {
            notes.items[i] = notes.items[i].copy(text = text.trim()); notes.save()
        }
    }

    fun delNote(id: Long) {
        notes.items.removeAll { it.id == id }; notes.save()
    }

    // ---------- Aufgaben ----------
    fun addTodo(text: String): Todo {
        val t = Todo(newId(), text.trim(), false, System.currentTimeMillis())
        todos.items.add(t); todos.save(); return t
    }

    fun setTodoDone(id: Long, done: Boolean) {
        val i = todos.items.indexOfFirst { it.id == id }
        if (i >= 0) {
            todos.items[i] = todos.items[i].copy(done = done); todos.save()
        }
    }

    fun editTodo(id: Long, text: String) {
        val i = todos.items.indexOfFirst { it.id == id }
        if (i >= 0) {
            todos.items[i] = todos.items[i].copy(text = text.trim()); todos.save()
        }
    }

    fun delTodo(id: Long) {
        todos.items.removeAll { it.id == id }; todos.save()
    }

    fun clearDoneTodos(): Int {
        val n = todos.items.count { it.done }
        todos.items.removeAll { it.done }; todos.save(); return n
    }

    // ---------- Termine ----------
    fun addEvent(title: String, start: Long): Ev {
        val e = Ev(newId(), title.trim(), start)
        events.items.add(e); events.save(); return e
    }

    fun editEvent(id: Long, title: String, start: Long) {
        val i = events.items.indexOfFirst { it.id == id }
        if (i >= 0) {
            events.items[i] = events.items[i].copy(title = title.trim(), start = start); events.save()
        }
    }

    fun delEvent(id: Long) {
        events.items.removeAll { it.id == id }; events.save()
    }

    fun upcomingEvents(limit: Int = 5): List<Ev> {
        val from = System.currentTimeMillis() - 60 * 60 * 1000L
        return events.items.filter { it.start >= from }.sortedBy { it.start }.take(limit)
    }

    // ---------- Erinnerungen ----------
    fun addReminder(text: String, at: Long): Reminder {
        val r = Reminder(newId(), text.trim(), at, false)
        reminders.items.add(r); reminders.save()
        ReminderAlarms.schedule(r)
        return r
    }

    fun delReminder(id: Long) {
        reminders.items.firstOrNull { it.id == id }?.let { ReminderAlarms.cancel(it) }
        reminders.items.removeAll { it.id == id }; reminders.save()
    }

    fun fire(id: Long) {
        val i = reminders.items.indexOfFirst { it.id == id }
        if (i < 0) return
        val r = reminders.items[i]
        if (r.fired) return
        reminders.items[i] = r.copy(fired = true); reminders.save()
        notifyReminder(r)
    }

    /** Nach Neustart, App-Update oder App-Start: offene Erinnerungen neu einplanen, verpasste sofort melden. */
    fun rescheduleAll() {
        val now = System.currentTimeMillis()
        for (r in reminders.items.toList()) {
            if (r.fired) continue
            if (r.at <= now) fire(r.id) else ReminderAlarms.schedule(r)
        }
    }

    private fun notifyReminder(r: Reminder) {
        val app = JarvisApp.instance
        try {
            val pi = PendingIntent.getActivity(
                app, 0, Intent(app, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            val n = NotificationCompat.Builder(app, JarvisApp.CH_ACTION)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle("JARVIS · Erinnerung")
                .setContentText(r.text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(r.text))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            NotificationManagerCompat.from(app).notify(1000 + (r.id % 100000L).toInt(), n)
        } catch (_: SecurityException) {
        }
    }
}

object ReminderAlarms {
    const val ACT = "de.jarvis.assistant.REMINDER"

    private fun pi(ctx: Context, r: Reminder): PendingIntent = PendingIntent.getBroadcast(
        ctx, (r.id % 1_000_000_007L).toInt(),
        Intent(ctx, ReminderReceiver::class.java).setAction(ACT).putExtra("id", r.id),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun schedule(r: Reminder) {
        val ctx = JarvisApp.instance
        try {
            ctx.getSystemService(AlarmManager::class.java)
                .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.at, pi(ctx, r))
        } catch (_: Exception) {
        }
    }

    fun cancel(r: Reminder) {
        val ctx = JarvisApp.instance
        try {
            ctx.getSystemService(AlarmManager::class.java).cancel(pi(ctx, r))
        } catch (_: Exception) {
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        MiniData.init()
        when (i.action) {
            ReminderAlarms.ACT -> MiniData.fire(i.getLongExtra("id", -1L))
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> MiniData.rescheduleAll()
        }
    }
}
