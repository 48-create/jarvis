package de.jarvis.assistant

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** projectId 0 = ohne Projekt. */
data class Chat(
    val id: Long,
    val title: String,
    val projectId: Long,
    val created: Long,
    val updated: Long,
    val msgs: List<ChatMsg>
)

data class Project(val id: Long, val name: String, val instructions: String, val created: Long)

/** Verlauf: jeder Chat und jedes Projekt wird sofort dauerhaft gespeichert (Store „chats“ und „projects“). */
object Chats {
    const val CHATS = "chats"
    const val PROJECTS = "projects"

    val chats = mutableStateListOf<Chat>()
    val projects = mutableStateListOf<Project>()

    /** Der gerade angezeigte Chat. 0 = neuer Chat, der erst mit deiner ersten Nachricht gespeichert wird. */
    var currentId by mutableLongStateOf(0L)
        private set

    /** Projekt, in dem neue Chats starten. */
    var activeProject by mutableLongStateOf(0L)
        private set

    private var loaded = false
    private var seq = 0L
    private fun newId(): Long = System.currentTimeMillis() * 100 + (seq++ % 100)

    fun init() {
        if (loaded) return
        loaded = true
        load()
    }

    fun load() {
        chats.clear(); projects.clear()
        val p = Store.read(PROJECTS)
        for (i in 0 until p.length()) {
            try {
                val o = p.getJSONObject(i)
                projects.add(Project(o.getLong("id"), o.getString("name"), o.optString("instr"), o.optLong("created")))
            } catch (_: Exception) {
            }
        }
        val c = Store.read(CHATS)
        val loadedChats = ArrayList<Chat>()
        for (i in 0 until c.length()) {
            try {
                val o = c.getJSONObject(i)
                val arr = o.optJSONArray("msgs") ?: JSONArray()
                val list = ArrayList<ChatMsg>()
                for (k in 0 until arr.length()) {
                    val m = arr.getJSONObject(k)
                    list.add(ChatMsg(m.getBoolean("u"), m.getString("t")))
                }
                loadedChats.add(Chat(o.getLong("id"), o.optString("title"), o.optLong("project"), o.optLong("created"), o.optLong("updated"), list))
            } catch (_: Exception) {
            }
        }
        chats.addAll(loadedChats.sortedByDescending { it.updated })
    }

    private fun saveChats() {
        val a = JSONArray()
        for (c in chats) {
            val m = JSONArray()
            c.msgs.forEach { m.put(JSONObject().put("u", it.fromUser).put("t", it.text)) }
            a.put(
                JSONObject().put("id", c.id).put("title", c.title).put("project", c.projectId)
                    .put("created", c.created).put("updated", c.updated).put("msgs", m)
            )
        }
        Store.write(CHATS, a)
    }

    private fun saveProjects() {
        val a = JSONArray()
        projects.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("instr", it.instructions).put("created", it.created)) }
        Store.write(PROJECTS, a)
    }

    /** Wird von der Engine für jede Nachricht aufgerufen. Der Chat entsteht mit der ersten Nutzer-Nachricht. */
    fun record(m: ChatMsg) {
        var i = chats.indexOfFirst { it.id == currentId }
        if (i < 0) {
            if (!m.fromUser) return
            val now = System.currentTimeMillis()
            val c = Chat(newId(), m.text.replace("\n", " ").take(40), activeProject, now, now, emptyList())
            chats.add(0, c)
            currentId = c.id
            i = 0
        }
        val c = chats[i]
        val updated = c.copy(msgs = c.msgs + m, updated = System.currentTimeMillis())
        chats.removeAt(i)
        chats.add(0, updated)
        saveChats()
    }

    fun startNew(projectId: Long = activeProject) {
        activeProject = if (projects.any { it.id == projectId }) projectId else 0L
        currentId = 0L
        JarvisEngine.showChat(emptyList())
    }

    fun open(id: Long) {
        val c = chats.firstOrNull { it.id == id } ?: return
        currentId = id
        activeProject = if (projects.any { it.id == c.projectId }) c.projectId else 0L
        JarvisEngine.showChat(c.msgs)
    }

    fun rename(id: Long, title: String) {
        val i = chats.indexOfFirst { it.id == id }
        if (i >= 0) {
            chats[i] = chats[i].copy(title = title.trim()); saveChats()
        }
    }

    fun moveTo(id: Long, projectId: Long) {
        val i = chats.indexOfFirst { it.id == id }
        if (i >= 0) {
            chats[i] = chats[i].copy(projectId = projectId); saveChats()
            if (currentId == id) activeProject = projectId
        }
    }

    fun delete(id: Long) {
        chats.removeAll { it.id == id }
        saveChats()
        if (currentId == id) startNew(activeProject)
    }

    fun deleteAll() {
        chats.clear()
        saveChats()
        startNew(0L)
    }

    fun addProject(name: String, instructions: String): Project {
        val p = Project(newId(), name.trim(), instructions.trim(), System.currentTimeMillis())
        projects.add(p); saveProjects(); return p
    }

    fun editProject(id: Long, name: String, instructions: String) {
        val i = projects.indexOfFirst { it.id == id }
        if (i >= 0) {
            projects[i] = projects[i].copy(name = name.trim(), instructions = instructions.trim()); saveProjects()
        }
    }

    fun deleteProject(id: Long, withChats: Boolean) {
        val inside = chats.filter { it.projectId == id }.map { it.id }
        if (withChats) {
            chats.removeAll { it.projectId == id }
        } else {
            for (cid in inside) moveTo(cid, 0L)
        }
        projects.removeAll { it.id == id }
        saveProjects(); saveChats()
        if (activeProject == id) activeProject = 0L
        if (currentId != 0L && chats.none { it.id == currentId }) startNew(0L)
    }

    /** Titel der letzten Chats, damit JARVIS weiß, worüber ihr schon gesprochen habt. */
    fun recentContext(): String {
        val l = chats.filter { it.id != currentId }.take(6)
        if (l.isEmpty()) return ""
        val f = SimpleDateFormat("d.M.", Locale.GERMANY)
        return "Frühere Chats mit dem Nutzer (Datum und Titel): " +
            l.joinToString("; ") { "${f.format(Date(it.updated))} ${it.title}" } + ". "
    }

    fun activeProjectName(): String = projects.firstOrNull { it.id == activeProject }?.name ?: ""

    /** Kontext für die KI: Name und Anweisungen des aktuellen Projekts. */
    fun projectContext(): String {
        val p = projects.firstOrNull { it.id == activeProject } ?: return ""
        return "Aktuelles Projekt des Nutzers: ${p.name}." +
            (if (p.instructions.isNotBlank()) " Anweisungen des Nutzers für dieses Projekt: ${p.instructions}." else "") + " "
    }
}

// ---------------------------------------------------------------- Oberfläche

@Composable
private fun chatFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Cyan, unfocusedBorderColor = Cyan.copy(alpha = 0.35f), cursorColor = Cyan,
    focusedTextColor = TextC, unfocusedTextColor = TextC
)

@Composable
private fun Confirm(title: String, text: String, ok: String, onOk: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF07101C),
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = { onOk(); onDismiss() }) { Text(ok, color = Gold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } }
    )
}

@Composable
private fun ProjectDialog(p: Project?, onSave: (String, String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(p?.name ?: "") }
    var instr by remember { mutableStateOf(p?.instructions ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF07101C),
        title = { Text(if (p == null) "Neues Projekt" else "Projekt bearbeiten") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, singleLine = true,
                    label = { Text("Name") }, colors = chatFieldColors()
                )
                OutlinedTextField(
                    value = instr, onValueChange = { instr = it }, minLines = 2,
                    label = { Text("Anweisung für JARVIS (optional)") }, colors = chatFieldColors()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isNotBlank()) onSave(name, instr)
                onDismiss()
            }) { Text("Speichern") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } }
    )
}

private val fmtChat = SimpleDateFormat("d.M.yy HH:mm", Locale.GERMANY)

@Composable
private fun ChatRow(c: Chat, onOpen: () -> Unit, onRename: () -> Unit, onMove: () -> Unit, onDelete: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).clickable { onOpen() }.padding(vertical = 4.dp)) {
            Text(
                c.title.ifBlank { "Chat" }, color = if (c.id == Chats.currentId) Cyan else TextC,
                fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text("${fmtChat.format(Date(c.updated))} · ${c.msgs.size} Nachrichten", color = TextC.copy(alpha = 0.5f), fontSize = 11.sp)
        }
        TextButton(onClick = onRename) { Text("✎", color = Gold) }
        TextButton(onClick = onMove) { Text("📁", color = Gold) }
        TextButton(onClick = onDelete) { Text("✕", color = Gold) }
    }
}

@Composable
fun HistoryScreen(onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    var renameChat by remember { mutableStateOf<Chat?>(null) }
    var moveChat by remember { mutableStateOf<Chat?>(null) }
    var deleteChat by remember { mutableStateOf<Chat?>(null) }
    var projDialog by remember { mutableStateOf<Project?>(null) }
    var newProject by remember { mutableStateOf(false) }
    var deleteProject by remember { mutableStateOf<Project?>(null) }
    var confirmAll by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(Dark)) {
        HudBackground()
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("VERLAUF", color = Cyan, fontSize = 18.sp, letterSpacing = 5.sp, modifier = Modifier.weight(1f))
                HudButton("✕") { onClose() }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HudButton("＋ NEUER CHAT", filled = true) { Chats.startNew(0L); onClose() }
                HudButton("＋ PROJEKT", accent = Gold) { newProject = true }
            }
            Spacer(Modifier.height(10.dp))
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                if (Chats.chats.isEmpty() && Chats.projects.isEmpty()) {
                    Text("Noch keine Chats. Sobald du etwas sagst oder schreibst, wird der Chat hier gespeichert.", color = TextC.copy(alpha = 0.55f), fontSize = 13.sp)
                }
                Chats.projects.forEach { p ->
                    key(p.id) {
                        val inside = Chats.chats.filter { it.projectId == p.id }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "📁 ${p.name} (${inside.size})", color = Gold, fontSize = 13.sp, fontFamily = FontFamily.Monospace,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = { Chats.startNew(p.id); onClose() }) { Text("＋ Chat", color = Cyan) }
                            TextButton(onClick = { projDialog = p }) { Text("✎", color = Gold) }
                            TextButton(onClick = { deleteProject = p }) { Text("✕", color = Gold) }
                        }
                        if (p.instructions.isNotBlank()) {
                            Text(p.instructions, color = TextC.copy(alpha = 0.5f), fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        inside.forEach { c ->
                            key(c.id) {
                                Box(Modifier.padding(start = 12.dp)) {
                                    ChatRow(c, { Chats.open(c.id); onClose() }, { renameChat = c }, { moveChat = c }, { deleteChat = c })
                                }
                            }
                        }
                    }
                }
                val free = Chats.chats.filter { c -> Chats.projects.none { it.id == c.projectId } }
                if (free.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Text("OHNE PROJEKT", color = Gold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    free.forEach { c ->
                        key(c.id) {
                            ChatRow(c, { Chats.open(c.id); onClose() }, { renameChat = c }, { moveChat = c }, { deleteChat = c })
                        }
                    }
                }
                if (Chats.chats.isNotEmpty()) {
                    Spacer(Modifier.height(16.dp))
                    HudButton("ALLE CHATS LÖSCHEN", accent = Gold) { confirmAll = true }
                }
            }
        }
    }

    renameChat?.let { c -> EditDialog("Chat umbenennen", c.title, { Chats.rename(c.id, it) }) { renameChat = null } }
    deleteChat?.let { c ->
        Confirm("Chat löschen?", "„${c.title.ifBlank { "Chat" }}“ wird endgültig gelöscht.", "Löschen", { Chats.delete(c.id) }) { deleteChat = null }
    }
    if (confirmAll) {
        Confirm("Alle Chats löschen?", "Alle ${Chats.chats.size} Chats werden endgültig gelöscht. Projekte bleiben bestehen.", "Alle löschen", { Chats.deleteAll() }) { confirmAll = false }
    }
    if (newProject) {
        ProjectDialog(null, { n, i -> Chats.addProject(n, i) }) { newProject = false }
    }
    projDialog?.let { p -> ProjectDialog(p, { n, i -> Chats.editProject(p.id, n, i) }) { projDialog = null } }
    deleteProject?.let { p ->
        AlertDialog(
            onDismissRequest = { deleteProject = null },
            containerColor = Color(0xFF07101C),
            title = { Text("Projekt „${p.name}“ löschen?") },
            text = { Text("Was soll mit den Chats in diesem Projekt passieren?") },
            confirmButton = {
                TextButton(onClick = { Chats.deleteProject(p.id, false); deleteProject = null }) { Text("Chats behalten") }
            },
            dismissButton = {
                TextButton(onClick = { Chats.deleteProject(p.id, true); deleteProject = null }) { Text("Mit löschen", color = Gold) }
            }
        )
    }
    moveChat?.let { c ->
        AlertDialog(
            onDismissRequest = { moveChat = null },
            containerColor = Color(0xFF07101C),
            title = { Text("In Projekt verschieben") },
            text = {
                Column {
                    TextButton(onClick = { Chats.moveTo(c.id, 0L); moveChat = null }) { Text("Ohne Projekt") }
                    Chats.projects.forEach { p ->
                        TextButton(onClick = { Chats.moveTo(c.id, p.id); moveChat = null }) { Text("📁 ${p.name}") }
                    }
                    if (Chats.projects.isEmpty()) Text("Lege zuerst ein Projekt an.", fontSize = 12.sp)
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { moveChat = null }) { Text("Abbrechen") } }
        )
    }
}
