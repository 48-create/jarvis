package de.jarvis.assistant

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.provider.AlarmClock
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Dash {
    val ALL = listOf("clock", "weather", "events", "todos", "notes", "reminders", "news", "timer", "calc")

    fun title(id: String) = when (id) {
        "clock" -> "UHR · WECKER"
        "weather" -> "WETTER"
        "events" -> "KALENDER"
        "todos" -> "AUFGABEN"
        "notes" -> "NOTIZEN"
        "reminders" -> "ERINNERUNGEN"
        "news" -> "NEWS"
        "timer" -> "STOPPUHR · TIMER"
        else -> "RECHNER"
    }
}

// ---------------------------------------------------------------- Wurzel mit Umschalter

@Composable
fun RootScreen() {
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().background(Dark)) {
        Box(Modifier.weight(1f)) {
            if (tab == 0) JarvisScreen() else DashboardScreen()
        }
        Row(
            Modifier.fillMaxWidth().background(Color(0xFF07101C)).padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            HudButton("JARVIS", Modifier.weight(1f), filled = tab == 0) { tab = 0 }
            HudButton("DASHBOARD", Modifier.weight(1f), filled = tab == 1) { tab = 1 }
        }
    }
}

// ---------------------------------------------------------------- Helfer

@Composable
fun <T> rememberLoad(key: Any?, f: suspend () -> T): Pair<T?, String?> {
    var v by remember(key) { mutableStateOf<T?>(null) }
    var e by remember(key) { mutableStateOf<String?>(null) }
    LaunchedEffect(key) {
        try {
            v = f(); e = null
        } catch (x: CancellationException) {
            throw x
        } catch (x: Exception) {
            e = x.message ?: "Fehler"
        }
    }
    return v to e
}

@Composable
fun rememberNow(intervalMs: Long = 1000L): State<Long> = produceState(System.currentTimeMillis()) {
    while (true) {
        value = System.currentTimeMillis()
        delay(intervalMs)
    }
}

@Composable
fun HudCard(title: String, modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(6.dp)
    var m = modifier.fillMaxWidth().background(Color(0x990D1B2A), shape).border(1.dp, Cyan.copy(alpha = 0.35f), shape)
    if (onClick != null) m = m.clickable { onClick() }
    Column(m.padding(14.dp)) {
        Text(title, color = Gold, fontSize = 11.sp, fontFamily = FontFamily.Monospace, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(6.dp))
        content()
    }
}

@Composable
fun Body(t: String, dim: Boolean = false, strike: Boolean = false, modifier: Modifier = Modifier) {
    Text(
        t, modifier = modifier, color = if (dim) TextC.copy(alpha = 0.55f) else TextC, fontSize = 14.sp,
        textDecoration = if (strike) TextDecoration.LineThrough else null
    )
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Cyan, unfocusedBorderColor = Cyan.copy(alpha = 0.35f), cursorColor = Cyan,
    focusedTextColor = TextC, unfocusedTextColor = TextC
)

@Composable
fun AddRow(hint: String, onAdd: (String) -> Unit) {
    var t by remember { mutableStateOf("") }
    Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = t, onValueChange = { t = it }, modifier = Modifier.weight(1f),
            placeholder = { Text(hint, color = Cyan.copy(alpha = 0.4f)) }, singleLine = true, colors = fieldColors()
        )
        Spacer(Modifier.width(8.dp))
        HudButton("＋", filled = true) {
            if (t.isNotBlank()) {
                onAdd(t); t = ""
            }
        }
    }
}

@Composable
fun EditDialog(title: String, initial: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var t by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF07101C),
        title = { Text(title) },
        text = { OutlinedTextField(value = t, onValueChange = { t = it }, colors = fieldColors()) },
        confirmButton = {
            TextButton(onClick = {
                if (t.isNotBlank()) onSave(t)
                onDismiss()
            }) { Text("Speichern") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } }
    )
}

fun pickDateTime(ctx: Context, initial: Long, onPicked: (Long) -> Unit) {
    val c = Calendar.getInstance().apply { timeInMillis = initial }
    DatePickerDialog(ctx, { _, y, m, d ->
        TimePickerDialog(ctx, { _, h, mi ->
            val r = Calendar.getInstance().apply {
                set(y, m, d, h, mi, 0); set(Calendar.MILLISECOND, 0)
            }
            onPicked(r.timeInMillis)
        }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
    }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
}

private val fmtShort = SimpleDateFormat("EE d.M. HH:mm", Locale.GERMANY)
private fun nextFullHour(): Long = Calendar.getInstance().apply {
    add(Calendar.HOUR_OF_DAY, 1); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

// ---------------------------------------------------------------- Dashboard

@Composable
fun DashboardScreen() {
    var open by remember { mutableStateOf<String?>(null) }
    var edit by remember { mutableStateOf(false) }
    var order by remember { mutableStateOf(Prefs.dashOrder) }

    val o = open
    if (o != null) {
        MiniScreen(o) { open = null }
        return
    }

    fun move(i: Int, d: Int) {
        val j = i + d
        if (j !in order.indices) return
        val l = order.toMutableList()
        val x = l[i]; l[i] = l[j]; l[j] = x
        order = l
        Prefs.dashOrder = l
    }

    Box(Modifier.fillMaxSize()) {
        HudBackground()
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("DASHBOARD", color = Cyan, fontSize = 20.sp, fontWeight = FontWeight.Light, letterSpacing = 5.sp, modifier = Modifier.weight(1f))
                HudButton(if (edit) "FERTIG" else "ANORDNEN", accent = Gold, filled = edit) { edit = !edit }
            }
            Spacer(Modifier.height(12.dp))
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                order.forEachIndexed { i, id ->
                    key(id) {
                        HudCard(Dash.title(id), onClick = if (edit) null else ({ open = id })) {
                            TilePreview(id)
                            if (edit) {
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    HudButton("▲", accent = Gold) { move(i, -1) }
                                    HudButton("▼", accent = Gold) { move(i, 1) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TilePreview(id: String) {
    when (id) {
        "clock" -> {
            val now by rememberNow()
            Text(
                SimpleDateFormat("HH:mm:ss", Locale.GERMANY).format(Date(now)),
                color = Cyan, fontSize = 34.sp, fontWeight = FontWeight.Light
            )
            Body(SimpleDateFormat("EEEE, d. MMMM yyyy", Locale.GERMANY).format(Date(now)), dim = true)
        }
        "weather" -> {
            val (wx, err) = rememberLoad(Prefs.city) { Weather.fetch(Prefs.city) }
            when {
                wx != null -> {
                    Body("${wx.city}: ${wx.temp}° · ${Weather.describe(wx.code)}")
                    Body("Heute ${wx.days[0].min}–${wx.days[0].max}° · Regen ${wx.days[0].rain} %", dim = true)
                }
                err != null -> Body(err, dim = true)
                else -> Body("Lade …", dim = true)
            }
        }
        "events" -> {
            val up = MiniData.upcomingEvents(3)
            if (up.isEmpty()) Body("Keine Termine", dim = true)
            up.forEach { Body("• ${it.title} · ${fmtShort.format(Date(it.start))}") }
        }
        "todos" -> {
            val open = MiniData.todos.items.filter { !it.done }
            Body(if (open.isEmpty()) "Alles erledigt" else "${open.size} offen", dim = open.isEmpty())
            open.take(3).forEach { Body("☐ ${it.text}") }
        }
        "notes" -> {
            val n = MiniData.notes.items
            Body(if (n.isEmpty()) "Keine Notizen" else "${n.size} Notizen", dim = n.isEmpty())
            n.takeLast(2).reversed().forEach { Body("• ${it.text.take(60)}", dim = true) }
        }
        "reminders" -> {
            val r = MiniData.reminders.items.filter { !it.fired }.sortedBy { it.at }
            if (r.isEmpty()) Body("Keine offenen Erinnerungen", dim = true)
            r.take(2).forEach { Body("⏰ ${it.text} · ${fmtShort.format(Date(it.at))}") }
        }
        "news" -> {
            val (items, err) = rememberLoad("Top") { News.fetch("Top", 3) }
            when {
                items != null -> items.forEach { Body("• ${it.title}", modifier = Modifier.padding(bottom = 2.dp)) }
                err != null -> Body(err, dim = true)
                else -> Body("Lade …", dim = true)
            }
        }
        else -> Body("Antippen zum Öffnen", dim = true)
    }
}

@Composable
fun MiniScreen(id: String, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    Box(Modifier.fillMaxSize()) {
        HudBackground()
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                HudButton("◀") { onBack() }
                Spacer(Modifier.width(12.dp))
                Text(Dash.title(id), color = Gold, fontSize = 14.sp, fontFamily = FontFamily.Monospace, letterSpacing = 2.sp)
            }
            Spacer(Modifier.height(12.dp))
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                when (id) {
                    "notes" -> NotesApp()
                    "todos" -> TodosApp()
                    "events" -> EventsApp()
                    "reminders" -> RemindersApp()
                    "weather" -> WeatherApp()
                    "news" -> NewsApp()
                    "timer" -> TimerApp()
                    "calc" -> CalcApp()
                    else -> ClockApp()
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Notizen

@Composable
fun NotesApp() {
    var edit by remember { mutableStateOf<Note?>(null) }
    AddRow("Neue Notiz …") { MiniData.addNote(it) }
    if (MiniData.notes.items.isEmpty()) Body("Noch keine Notizen. Sage: „Notiere Milch kaufen“.", dim = true)
    MiniData.notes.items.asReversed().forEach { n ->
        key(n.id) {
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Body(n.text, modifier = Modifier.weight(1f).clickable { edit = n })
                TextButton(onClick = { MiniData.delNote(n.id) }) { Text("✕", color = Gold) }
            }
        }
    }
    edit?.let { n -> EditDialog("Notiz bearbeiten", n.text, { MiniData.editNote(n.id, it) }) { edit = null } }
}

// ---------------------------------------------------------------- Aufgaben

@Composable
fun TodosApp() {
    var edit by remember { mutableStateOf<Todo?>(null) }
    AddRow("Neue Aufgabe …") { MiniData.addTodo(it) }
    if (MiniData.todos.items.isEmpty()) Body("Keine Aufgaben. Sage: „Setze Brot auf die Einkaufsliste“.", dim = true)
    MiniData.todos.items.sortedBy { it.done }.forEach { t ->
        key(t.id) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = t.done, onCheckedChange = { MiniData.setTodoDone(t.id, it) },
                    colors = CheckboxDefaults.colors(checkedColor = Cyan, uncheckedColor = Cyan.copy(alpha = 0.6f), checkmarkColor = Dark)
                )
                Body(t.text, dim = t.done, strike = t.done, modifier = Modifier.weight(1f).clickable { edit = t })
                TextButton(onClick = { MiniData.delTodo(t.id) }) { Text("✕", color = Gold) }
            }
        }
    }
    if (MiniData.todos.items.any { it.done }) {
        Spacer(Modifier.height(8.dp))
        HudButton("ERLEDIGTE LÖSCHEN", accent = Gold) { MiniData.clearDoneTodos() }
    }
    edit?.let { t -> EditDialog("Aufgabe bearbeiten", t.text, { MiniData.editTodo(t.id, it) }) { edit = null } }
}

// ---------------------------------------------------------------- Kalender

@Composable
fun EventsApp() {
    val ctx = LocalContext.current
    var title by remember { mutableStateOf("") }
    var whenMs by remember { mutableLongStateOf(nextFullHour()) }
    var edit by remember { mutableStateOf<Ev?>(null) }

    OutlinedTextField(
        value = title, onValueChange = { title = it }, modifier = Modifier.fillMaxWidth(),
        placeholder = { Text("Neuer Termin …", color = Cyan.copy(alpha = 0.4f)) }, singleLine = true, colors = fieldColors()
    )
    Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        HudButton(fmtShort.format(Date(whenMs)), accent = Gold) { pickDateTime(ctx, whenMs) { whenMs = it } }
        HudButton("＋ EINTRAGEN", filled = true) {
            if (title.isNotBlank()) {
                MiniData.addEvent(title, whenMs); title = ""
            }
        }
    }
    Spacer(Modifier.height(6.dp))
    val now = System.currentTimeMillis()
    val all = MiniData.events.items.sortedBy { it.start }
    if (all.isEmpty()) Body("Kalender leer. Sage: „Trage Zahnarzt morgen um 15 Uhr in den Kalender ein“.", dim = true)
    all.forEach { e ->
        key(e.id) {
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).clickable { edit = e }) {
                    Body(e.title, dim = e.start < now)
                    Body(fmtShort.format(Date(e.start)), dim = true)
                }
                TextButton(onClick = { MiniData.delEvent(e.id) }) { Text("✕", color = Gold) }
            }
        }
    }
    edit?.let { e -> EditDialog("Termin umbenennen", e.title, { MiniData.editEvent(e.id, it, e.start) }) { edit = null } }
}

// ---------------------------------------------------------------- Erinnerungen

@Composable
fun RemindersApp() {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("") }
    var whenMs by remember { mutableLongStateOf(nextFullHour()) }
    OutlinedTextField(
        value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth(),
        placeholder = { Text("Woran soll ich erinnern? …", color = Cyan.copy(alpha = 0.4f)) }, singleLine = true, colors = fieldColors()
    )
    Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        HudButton(fmtShort.format(Date(whenMs)), accent = Gold) { pickDateTime(ctx, whenMs) { whenMs = it } }
        HudButton("＋ ERINNERN", filled = true) {
            if (text.isNotBlank() && whenMs > System.currentTimeMillis()) {
                MiniData.addReminder(text, whenMs); text = ""
            } else {
                Toast.makeText(ctx, "Text und einen Zeitpunkt in der Zukunft angeben.", Toast.LENGTH_SHORT).show()
            }
        }
    }
    val all = MiniData.reminders.items.sortedBy { it.at }
    if (all.isEmpty()) Body("Keine Erinnerungen. Sage: „Erinnere mich in 20 Minuten an die Wäsche“.", dim = true)
    all.forEach { r ->
        key(r.id) {
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Body(r.text, dim = r.fired, strike = r.fired)
                    Body(fmtShort.format(Date(r.at)) + if (r.fired) " · gemeldet" else "", dim = true)
                }
                TextButton(onClick = { MiniData.delReminder(r.id) }) { Text("✕", color = Gold) }
            }
        }
    }
}

// ---------------------------------------------------------------- Wetter

@Composable
fun WeatherApp() {
    var city by remember { mutableStateOf(Prefs.city) }
    var input by remember { mutableStateOf(Prefs.city) }
    Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
            placeholder = { Text("Ort, z. B. Hamburg", color = Cyan.copy(alpha = 0.4f)) }, singleLine = true, colors = fieldColors()
        )
        Spacer(Modifier.width(8.dp))
        HudButton("OK", filled = true) {
            Prefs.city = input; city = input.trim()
        }
    }
    val (wx, err) = rememberLoad(city) { Weather.fetch(city) }
    when {
        wx != null -> {
            Text("${wx.temp}°", color = Cyan, fontSize = 48.sp, fontWeight = FontWeight.Light)
            Body("${wx.city} · ${Weather.describe(wx.code)} · Wind ${wx.wind} km/h")
            Spacer(Modifier.height(10.dp))
            wx.days.forEach { d ->
                Body("${d.label}: ${d.min}–${d.max}° · ${Weather.describe(d.code)} · Regen ${d.rain} %", modifier = Modifier.padding(vertical = 3.dp))
            }
        }
        err != null -> Body(err, dim = true)
        else -> Body("Lade …", dim = true)
    }
}

// ---------------------------------------------------------------- News

@Composable
fun NewsApp() {
    val ctx = LocalContext.current
    var cat by remember { mutableStateOf("Top") }
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        News.categories.keys.forEach { c -> HudButton(c.uppercase(Locale.GERMAN), filled = c == cat) { cat = c } }
    }
    val (items, err) = rememberLoad(cat) { News.fetch(cat, 12) }
    when {
        items != null -> items.forEach { n ->
            Column(
                Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable {
                    try {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(n.link)))
                    } catch (_: Exception) {
                    }
                }
            ) {
                Body(n.title)
                Text("Quelle: ${n.source}", color = Gold.copy(alpha = 0.8f), fontSize = 11.sp)
            }
        }
        err != null -> Body(err, dim = true)
        else -> Body("Lade …", dim = true)
    }
}

// ---------------------------------------------------------------- Uhr & Wecker

@Composable
fun ClockApp() {
    val ctx = LocalContext.current
    val now by rememberNow()
    Text(SimpleDateFormat("HH:mm:ss", Locale.GERMANY).format(Date(now)), color = Cyan, fontSize = 56.sp, fontWeight = FontWeight.Light)
    Body(SimpleDateFormat("EEEE, d. MMMM yyyy", Locale.GERMANY).format(Date(now)))
    Spacer(Modifier.height(16.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        HudButton("WECKER STELLEN", filled = true) {
            val c = Calendar.getInstance()
            TimePickerDialog(ctx, { _, h, m ->
                try {
                    ctx.startActivity(
                        Intent(AlarmClock.ACTION_SET_ALARM)
                            .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
                            .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS").putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    )
                    Toast.makeText(ctx, "Wecker auf %02d:%02d gestellt.".format(h, m), Toast.LENGTH_SHORT).show()
                } catch (_: Exception) {
                    Toast.makeText(ctx, "Keine Wecker-App gefunden.", Toast.LENGTH_SHORT).show()
                }
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
        }
        HudButton("LISTE") {
            try {
                ctx.startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS))
            } catch (_: Exception) {
            }
        }
    }
    Spacer(Modifier.height(8.dp))
    Body("Per Sprache: „Stelle einen Wecker auf 6 Uhr 30“. Gestellt wird er in der Wecker-App deines Handys.", dim = true)
}

// ---------------------------------------------------------------- Stoppuhr & Timer

private fun fmtMs(ms: Long): String {
    val t = ms / 100
    return "%02d:%02d.%d".format(t / 600, (t / 10) % 60, t % 10)
}

@Composable
fun TimerApp() {
    val ctx = LocalContext.current
    var running by remember { mutableStateOf(false) }
    var base by remember { mutableLongStateOf(0L) }
    var startAt by remember { mutableLongStateOf(0L) }
    var shown by remember { mutableLongStateOf(0L) }
    LaunchedEffect(running) {
        while (running) {
            shown = base + (System.currentTimeMillis() - startAt)
            delay(50)
        }
    }
    Text(fmtMs(shown), color = Cyan, fontSize = 44.sp, fontWeight = FontWeight.Light, fontFamily = FontFamily.Monospace)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
        HudButton(if (running) "STOPP" else "START", filled = true) {
            if (running) {
                base += System.currentTimeMillis() - startAt; shown = base; running = false
            } else {
                startAt = System.currentTimeMillis(); running = true
            }
        }
        HudButton("RESET", accent = Gold) {
            running = false; base = 0; shown = 0
        }
    }

    Spacer(Modifier.height(18.dp))
    var mins by remember { mutableStateOf("5") }
    var cdRun by remember { mutableStateOf(false) }
    var endAt by remember { mutableLongStateOf(0L) }
    var remain by remember { mutableLongStateOf(0L) }
    LaunchedEffect(cdRun) {
        while (cdRun) {
            remain = endAt - System.currentTimeMillis()
            if (remain <= 0) {
                cdRun = false; remain = 0
                try {
                    RingtoneManager.getRingtone(ctx, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))?.play()
                } catch (_: Exception) {
                }
                Toast.makeText(ctx, "Timer abgelaufen.", Toast.LENGTH_LONG).show()
            }
            delay(200)
        }
    }
    Text("Countdown", color = Gold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
    Text(fmtMs(if (cdRun) remain else (mins.toLongOrNull() ?: 0L) * 60_000L), color = Cyan, fontSize = 36.sp, fontWeight = FontWeight.Light, fontFamily = FontFamily.Monospace)
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = mins, onValueChange = { mins = it.filter { c -> c.isDigit() }.take(4) },
            modifier = Modifier.width(110.dp), singleLine = true, label = { Text("Minuten") }, colors = fieldColors()
        )
        HudButton(if (cdRun) "ABBRECHEN" else "START", filled = true) {
            if (cdRun) {
                cdRun = false
            } else {
                val m = mins.toLongOrNull() ?: 0L
                if (m > 0) {
                    endAt = System.currentTimeMillis() + m * 60_000L; remain = m * 60_000L; cdRun = true
                }
            }
        }
    }
    Spacer(Modifier.height(6.dp))
    Body("Läuft nur bei geöffneter App. Für Hintergrund sage: „Stelle einen Timer auf 10 Minuten“.", dim = true)
}

// ---------------------------------------------------------------- Rechner

object Calc {
    fun eval(src: String): Double {
        val s = src.replace(" ", "").replace('×', '*').replace('÷', '/').replace(',', '.')
        var pos = 0
        fun peek(): Char? = if (pos < s.length) s[pos] else null
        fun number(): Double {
            val st = pos
            if (peek() == '-') pos++
            while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
            return s.substring(st, pos).toDouble()
        }
        fun term(): Double {
            var v = number()
            while (true) {
                when (peek()) {
                    '*' -> { pos++; v *= number() }
                    '/' -> { pos++; v /= number() }
                    else -> return v
                }
            }
        }
        fun expr(): Double {
            var v = term()
            while (true) {
                when (peek()) {
                    '+' -> { pos++; v += term() }
                    '-' -> { pos++; v -= term() }
                    else -> return v
                }
            }
        }
        val r = expr()
        if (pos != s.length) throw IllegalArgumentException("Ausdruck")
        return r
    }

    fun show(d: Double): String {
        if (d.isNaN() || d.isInfinite()) return "Fehler"
        if (d == Math.floor(d) && Math.abs(d) < 1e12) return d.toLong().toString()
        return "%.8f".format(Locale.GERMANY, d).trimEnd('0').trimEnd(',')
    }
}

@Composable
private fun RowScope.Key(label: String, accent: Color = Cyan, onClick: () -> Unit) {
    HudButton(label, Modifier.weight(1f), accent = accent, onClick = onClick)
}

@Composable
fun CalcApp() {
    var expr by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    Text(expr.ifEmpty { "0" }, color = TextC, fontSize = 30.sp, fontWeight = FontWeight.Light, modifier = Modifier.fillMaxWidth())
    Text(result, color = Cyan, fontSize = 22.sp, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp))
    fun press(k: String) {
        when (k) {
            "C" -> { expr = ""; result = "" }
            "⌫" -> expr = expr.dropLast(1)
            "=" -> result = try {
                Calc.show(Calc.eval(expr))
            } catch (_: Exception) {
                "Fehler"
            }
            else -> expr += k
        }
    }
    val rows = listOf(
        listOf("7", "8", "9", "÷"), listOf("4", "5", "6", "×"), listOf("1", "2", "3", "-"),
        listOf("0", ",", "=", "+"), listOf("C", "⌫")
    )
    rows.forEach { r ->
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            r.forEach { k ->
                Key(k, accent = if (k in listOf("÷", "×", "-", "+", "=", "C", "⌫")) Gold else Cyan) { press(k) }
            }
        }
    }
}
