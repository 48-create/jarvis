package de.jarvis.assistant

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.provider.AlarmClock
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Dash {
    val ALL = listOf("clock", "weather", "events", "todos", "notes", "reminders", "news", "timer", "calc", "memory")

    fun title(id: String) = when (id) {
        "clock" -> "UHR · WECKER"
        "weather" -> "WETTER"
        "events" -> "KALENDER"
        "todos" -> "AUFGABEN"
        "notes" -> "NOTIZEN"
        "reminders" -> "ERINNERUNGEN"
        "news" -> "NEWS"
        "timer" -> "STOPPUHR · TIMER"
        "memory" -> "GEDÄCHTNIS"
        else -> "RECHNER"
    }
}

// ---------------------------------------------------------------- Wurzel mit Umschalter

@Composable
fun RootScreen() {
    var tab by remember { mutableIntStateOf(0) }
    BoxWithConstraints(Modifier.fillMaxSize().background(Dark)) {
        // Ist die Tastatur offen, bleibt wenig Höhe: dann verschwindet die Leiste, damit das Eingabefeld Platz hat.
        val compact = maxHeight < 540.dp
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                if (tab == 0) JarvisScreen() else DashboardScreen()
            }
            if (!compact) {
                Box(Modifier.fillMaxWidth().height(1.dp).background(Cyan.copy(alpha = 0.12f)))
                Row(Modifier.fillMaxWidth().background(Color(0xFF050A12))) {
                    TabItem("JARVIS", tab == 0, Modifier.weight(1f)) { tab = 0 }
                    TabItem("DASHBOARD", tab == 1, Modifier.weight(1f)) { tab = 1 }
                }
            }
        }
    }
}

@Composable
private fun TabItem(label: String, active: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clickable { onClick() }.padding(top = 10.dp, bottom = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            label,
            color = if (active) Cyan else TextC.copy(alpha = 0.45f),
            fontSize = 11.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Medium
        )
        Spacer(Modifier.height(6.dp))
        Box(Modifier.width(22.dp).height(2.dp).background(if (active) Cyan else Color.Transparent))
    }
}

private val DimC = TextC.copy(alpha = 0.55f)

// ---------------------------------------------------------------- Helfer

@Composable
fun <T> rememberLoad(key: Any?, f: suspend () -> T): Pair<T?, String?> {
    var v by remember(key) { mutableStateOf<T?>(null) }
    var e by remember(key) { mutableStateOf<String?>(null) }
    LaunchedEffect(key) {
        try {
            v = f(); e = null
        } catch (x: CancellationException) {
            throw x
        } catch (x: Exception) {
            e = x.message ?: "Fehler"
        }
    }
    return v to e
}

@Composable
fun rememberNow(intervalMs: Long = 1000L): State<Long> = produceState(System.currentTimeMillis()) {
    while (true) {
        value = System.currentTimeMillis()
        delay(intervalMs)
    }
}

@Composable
fun HudCard(title: String, modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    var m = modifier.fillMaxWidth().clip(shape).background(Color(0x660D1B2A)).border(1.dp, Cyan.copy(alpha = 0.2f), shape)
    if (onClick != null) m = m.clickable { onClick() }
    Column(m.padding(14.dp)) {
        Text(title, color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        content()
    }
}

@Composable
fun Body(t: String, dim: Boolean = false, strike: Boolean = false, modifier: Modifier = Modifier) {
    Text(
        t, modifier = modifier, color = if (dim) DimC else TextC, fontSize = 15.sp, fontWeight = FontWeight.Light,
        textDecoration = if (strike) TextDecoration.LineThrough else null
    )
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Cyan.copy(alpha = 0.8f), unfocusedBorderColor = Cyan.copy(alpha = 0.25f), cursorColor = Cyan,
    focusedTextColor = TextC, unfocusedTextColor = TextC
)

@Composable
internal fun ItemRow(content: @Composable RowScope.() -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(RoundedCornerShape(14.dp)).background(Color(0x400D1B2A))
            .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

@Composable
internal fun DeleteX(onClick: () -> Unit) {
    Text("✕", color = Gold.copy(alpha = 0.8f), fontSize = 15.sp, modifier = Modifier.clickable { onClick() }.padding(10.dp))
}

@Composable
fun AddRow(hint: String, onAdd: (String) -> Unit) {
    var t by remember { mutableStateOf("") }
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = t, onValueChange = { t = it }, modifier = Modifier.weight(1f),
            placeholder = { Text(hint, color = TextC.copy(alpha = 0.35f)) }, singleLine = true,
            shape = RoundedCornerShape(26.dp), colors = fieldColors()
        )
        Spacer(Modifier.width(8.dp))
        HudButton("＋", filled = true) {
            if (t.isNotBlank()) {
                onAdd(t); t = ""
            }
        }
    }
}

@Composable
fun EditDialog(title: String, initial: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var t by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF07101C),
        title = { Text(title) },
        text = { OutlinedTextField(value = t, onValueChange = { t = it }, colors = fieldColors()) },
        confirmButton = {
            TextButton(onClick = {
                if (t.isNotBlank()) onSave(t)
                onDismiss()
            }) { Text("Speichern") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } }
    )
}

fun pickDateTime(ctx: Context, initial: Long, onPicked: (Long) -> Unit) {
    val c = Calendar.getInstance().apply { timeInMillis = initial }
    DatePickerDialog(ctx, { _, y, m, d ->
        TimePickerDialog(ctx, { _, h, mi ->
            val r = Calendar.getInstance().apply {
                set(y, m, d, h, mi, 0); set(Calendar.MILLISECOND, 0)
            }
            onPicked(r.timeInMillis)
        }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
    }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
}

private val fmtShort = SimpleDateFormat("EE d.M. HH:mm", Locale.GERMANY)
private fun nextFullHour(): Long = Calendar.getInstance().apply {
    add(Calendar.HOUR_OF_DAY, 1); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

// ---------------------------------------------------------------- Dashboard

private fun tileAccent(id: String): Color = when (id) {
    "weather" -> Color(0xFF7CC4FF)
    "events" -> Cyan
    "todos" -> Color(0xFF7CF5B0)
    "notes" -> Gold
    "reminders" -> Color(0xFFFF8F7A)
    "news" -> Color(0xFFB48CFF)
    "memory" -> Color(0xFFFF7CC8)
    else -> TextC.copy(alpha = 0.85f)
}

@Composable
fun DashboardScreen() {
    var open by remember { mutableStateOf<String?>(null) }
    var edit by remember { mutableStateOf(false) }
    var order by remember { mutableStateOf(Prefs.dashOrder) }

    val o = open
    if (o != null) {
        MiniScreen(o) { open = null }
        return
    }

    // Die Uhr steht groß oben; die übrigen Kacheln lassen sich verschieben (gleiche Reihenfolge-Speicherung wie vorher).
    fun move(id: String, d: Int) {
        val shown = order.filter { it != "clock" }
        val i = shown.indexOf(id)
        val j = i + d
        if (i < 0 || j !in shown.indices) return
        val l = order.toMutableList()
        val a = l.indexOf(shown[i])
        val b = l.indexOf(shown[j])
        val x = l[a]; l[a] = l[b]; l[b] = x
        order = l
        Prefs.dashOrder = l
    }

    val now by rememberNow(5000L)

    Box(Modifier.fillMaxSize()) {
        HudBackground()
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 18.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f).clickable { open = "clock" }) {
                    Text(
                        SimpleDateFormat("HH:mm", Locale.GERMANY).format(Date(now)),
                        color = TextC, fontSize = 68.sp, fontWeight = FontWeight.ExtraLight, letterSpacing = 2.sp
                    )
                    Text(
                        SimpleDateFormat("EEEE, d. MMMM", Locale.GERMANY).format(Date(now)),
                        color = DimC, fontSize = 15.sp
                    )
                }
                HudButton(if (edit) "FERTIG" else "ANORDNEN", accent = Gold, filled = edit) { edit = !edit }
            }
            Spacer(Modifier.height(22.dp))
            order.filter { it != "clock" }.chunked(2).forEach { pair ->
                Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    pair.forEach { id ->
                        Tile(id, edit, Modifier.weight(1f), { open = id }, { d -> move(id, d) })
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun Tile(id: String, edit: Boolean, modifier: Modifier, onOpen: () -> Unit, onMove: (Int) -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    val acc = tileAccent(id)
    Column(
        modifier
            .height(136.dp)
            .clip(shape)
            .background(Brush.linearGradient(listOf(acc.copy(alpha = 0.16f), Color(0x660D1B2A))))
            .border(1.dp, acc.copy(alpha = 0.25f), shape)
            .clickable(enabled = !edit) { onOpen() }
            .padding(14.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(Dash.title(id), color = acc, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        if (edit) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HudButton("‹", accent = Gold) { onMove(-1) }
                HudButton("›", accent = Gold) { onMove(1) }
            }
        } else {
            Column { TilePreview(id) }
        }
    }
}

@Composable
fun TilePreview(id: String) {
    when (id) {
        "weather" -> {
            val (wx, err) = rememberLoad(Prefs.city) { Weather.fetch(Prefs.city) }
            when {
                wx != null -> {
                    Text("${wx.temp}°", color = TextC, fontSize = 34.sp, fontWeight = FontWeight.ExtraLight)
                    Text("${wx.city} · ${Weather.describe(wx.code)}", color = DimC, fontSize = 12.sp, maxLines = 1)
                }
                err != null -> Text(err, color = DimC, fontSize = 12.sp, maxLines = 3)
                else -> Text("Lade …", color = DimC, fontSize = 13.sp)
            }
        }
        "events" -> {
            val up = MiniData.upcomingEvents(3)
            if (up.isEmpty()) {
                Text("Keine Termine", color = DimC, fontSize = 14.sp)
            } else {
                Text(up[0].title, color = TextC, fontSize = 15.sp, maxLines = 2)
                Text(fmtShort.format(Date(up[0].start)), color = Cyan, fontSize = 12.sp)
                if (up.size > 1) Text("+${up.size - 1} weitere", color = DimC, fontSize = 11.sp)
            }
        }
        "todos" -> {
            val open = MiniData.todos.items.filter { !it.done }
            Text(if (open.isEmpty()) "✓" else "${open.size}", color = TextC, fontSize = 34.sp, fontWeight = FontWeight.ExtraLight)
            Text(if (open.isEmpty()) "Alles erledigt" else open.first().text, color = DimC, fontSize = 12.sp, maxLines = 1)
        }
        "notes" -> {
            val n = MiniData.notes.items
            Text("${n.size}", color = TextC, fontSize = 34.sp, fontWeight = FontWeight.ExtraLight)
            Text(n.lastOrNull()?.text ?: "Keine Notizen", color = DimC, fontSize = 12.sp, maxLines = 1)
        }
        "reminders" -> {
            val r = MiniData.reminders.items.filter { !it.fired }.sortedBy { it.at }
            if (r.isEmpty()) {
                Text("Keine offenen Erinnerungen", color = DimC, fontSize = 14.sp)
            } else {
                Text(r[0].text, color = TextC, fontSize = 15.sp, maxLines = 2)
                Text(fmtShort.format(Date(r[0].at)), color = Cyan, fontSize = 12.sp)
            }
        }
        "news" -> {
            val (items, err) = rememberLoad("Top") { News.fetch("Top", 3) }
            when {
                items != null -> Text(items.firstOrNull()?.title ?: "Keine Meldungen", color = TextC, fontSize = 13.sp, maxLines = 4)
                err != null -> Text(err, color = DimC, fontSize = 12.sp, maxLines = 3)
                else -> Text("Lade …", color = DimC, fontSize = 13.sp)
            }
        }
        "memory" -> {
            Text("${Brain.facts.size}", color = TextC, fontSize = 34.sp, fontWeight = FontWeight.ExtraLight)
            Text(Brain.facts.firstOrNull()?.text ?: "Noch leer", color = DimC, fontSize = 12.sp, maxLines = 1)
        }
        "timer" -> {
            Text("00:00", color = TextC, fontSize = 34.sp, fontWeight = FontWeight.ExtraLight)
            Text("Stoppuhr · Timer", color = DimC, fontSize = 12.sp)
        }
        else -> {
            Text("÷ ×", color = TextC, fontSize = 34.sp, fontWeight = FontWeight.ExtraLight)
            Text("Rechner", color = DimC, fontSize = 12.sp)
        }
    }
}

@Composable
fun MiniScreen(id: String, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    Box(Modifier.fillMaxSize()) {
        HudBackground()
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("‹", color = Cyan, fontSize = 34.sp, fontWeight = FontWeight.Light, modifier = Modifier.clickable { onBack() }.padding(end = 16.dp, bottom = 4.dp))
                Text(Dash.title(id), color = TextC, fontSize = 15.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Light)
            }
            Spacer(Modifier.height(14.dp))
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                when (id) {
                    "notes" -> NotesApp()
                    "todos" -> TodosApp()
                    "events" -> EventsApp()
                    "reminders" -> RemindersApp()
                    "weather" -> WeatherApp()
                    "news" -> NewsApp()
                    "timer" -> TimerApp()
                    "calc" -> CalcApp()
                    "memory" -> MemoryApp()
                    else -> ClockApp()
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Notizen

@Composable
fun NotesApp() {
    var edit by remember { mutableStateOf<Note?>(null) }
    AddRow("Neue Notiz …") { MiniData.addNote(it) }
    if (MiniData.notes.items.isEmpty()) Body("Noch keine Notizen. Sage: „Notiere Milch kaufen“.", dim = true)
    MiniData.notes.items.asReversed().forEach { n ->
        key(n.id) {
            ItemRow {
                Body(n.text, modifier = Modifier.weight(1f).clickable { edit = n }.padding(vertical = 8.dp))
                DeleteX { MiniData.delNote(n.id) }
            }
        }
    }
    edit?.let { n -> EditDialog("Notiz bearbeiten", n.text, { MiniData.editNote(n.id, it) }) { edit = null } }
}

// ---------------------------------------------------------------- Aufgaben

@Composable
fun TodosApp() {
    var edit by remember { mutableStateOf<Todo?>(null) }
    AddRow("Neue Aufgabe …") { MiniData.addTodo(it) }
    if (MiniData.todos.items.isEmpty()) Body("Keine Aufgaben. Sage: „Setze Brot auf die Einkaufsliste“.", dim = true)
    MiniData.todos.items.sortedBy { it.done }.forEach { t ->
        key(t.id) {
            ItemRow {
                Checkbox(
                    checked = t.done, onCheckedChange = { MiniData.setTodoDone(t.id, it) },
                    colors = CheckboxDefaults.colors(checkedColor = Cyan, uncheckedColor = Cyan.copy(alpha = 0.6f), checkmarkColor = Dark)
                )
                Body(t.text, dim = t.done, strike = t.done, modifier = Modifier.weight(1f).clickable { edit = t }.padding(vertical = 8.dp))
                DeleteX { MiniData.delTodo(t.id) }
            }
        }
    }
    if (MiniData.todos.items.any { it.done }) {
        Spacer(Modifier.height(8.dp))
        HudButton("ERLEDIGTE LÖSCHEN", accent = Gold) { MiniData.clearDoneTodos() }
    }
    edit?.let { t -> EditDialog("Aufgabe bearbeiten", t.text, { MiniData.editTodo(t.id, it) }) { edit = null } }
}

// ---------------------------------------------------------------- Kalender (Monatsansicht)

@Composable
fun EventsApp() {
    val ctx = LocalContext.current
    val zone = remember { ZoneId.systemDefault() }
    val today = LocalDate.now()
    var month by remember { mutableStateOf(YearMonth.from(today)) }
    var sel by remember { mutableStateOf(today) }
    var title by remember { mutableStateOf("") }
    var hour by remember { mutableIntStateOf(9) }
    var minute by remember { mutableIntStateOf(0) }
    var edit by remember { mutableStateOf<Ev?>(null) }

    val evs = MiniData.events.items
    val byDay = evs.groupBy { Instant.ofEpochMilli(it.start).atZone(zone).toLocalDate() }

    // Kopf: Monat, Jahr, Blättern
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(
                month.month.getDisplayName(java.time.format.TextStyle.FULL, Locale.GERMAN),
                color = TextC, fontSize = 32.sp, fontWeight = FontWeight.Light
            )
            Text(month.year.toString(), color = Cyan, fontSize = 13.sp, letterSpacing = 4.sp)
        }
        HudButton("HEUTE") { month = YearMonth.from(today); sel = today }
        Text("‹", color = Cyan, fontSize = 30.sp, modifier = Modifier.clickable { month = month.minusMonths(1) }.padding(horizontal = 12.dp))
        Text("›", color = Cyan, fontSize = 30.sp, modifier = Modifier.clickable { month = month.plusMonths(1) }.padding(start = 4.dp))
    }
    Spacer(Modifier.height(14.dp))

    // Wochentage
    Row(Modifier.fillMaxWidth()) {
        listOf("Mo", "Di", "Mi", "Do", "Fr", "Sa", "So").forEachIndexed { i, d ->
            Text(
                d, modifier = Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 11.sp, letterSpacing = 1.sp,
                color = if (i >= 5) Gold.copy(alpha = 0.7f) else DimC
            )
        }
    }
    Spacer(Modifier.height(6.dp))

    // Tage
    val offset = month.atDay(1).dayOfWeek.value - 1
    val days = month.lengthOfMonth()
    val rows = (offset + days + 6) / 7
    for (r in 0 until rows) {
        Row(Modifier.fillMaxWidth()) {
            for (c in 0 until 7) {
                val d = r * 7 + c - offset + 1
                Box(Modifier.weight(1f).height(48.dp), contentAlignment = Alignment.Center) {
                    if (d in 1..days) {
                        val date = month.atDay(d)
                        val isSel = date == sel
                        val isToday = date == today
                        val has = byDay.containsKey(date)
                        Column(Modifier.clickable { sel = date }, horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(if (isSel) Cyan else Color.Transparent)
                                    .border(1.dp, if (isToday && !isSel) Cyan else Color.Transparent, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "$d", fontSize = 15.sp,
                                    fontWeight = if (isToday || isSel) FontWeight.Bold else FontWeight.Light,
                                    color = if (isSel) Dark else if (c >= 5) TextC.copy(alpha = 0.65f) else TextC
                                )
                            }
                            Spacer(Modifier.height(2.dp))
                            Box(Modifier.size(4.dp).clip(CircleShape).background(if (has) Gold else Color.Transparent))
                        }
                    }
                }
            }
        }
    }

    Spacer(Modifier.height(16.dp))
    Box(Modifier.fillMaxWidth().height(1.dp).background(Cyan.copy(alpha = 0.12f)))
    Spacer(Modifier.height(14.dp))

    // Termine des gewählten Tages
    Text(
        sel.format(DateTimeFormatter.ofPattern("EEEE, d. MMMM", Locale.GERMAN)),
        color = Cyan, fontSize = 13.sp, letterSpacing = 1.sp, fontWeight = FontWeight.Medium
    )
    Spacer(Modifier.height(8.dp))
    val dayEvents = byDay[sel].orEmpty().sortedBy { it.start }
    if (dayEvents.isEmpty()) Body("Keine Termine an diesem Tag.", dim = true)
    dayEvents.forEach { e ->
        key(e.id) {
            ItemRow {
                Text(
                    SimpleDateFormat("HH:mm", Locale.GERMANY).format(Date(e.start)),
                    color = Cyan, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.width(54.dp)
                )
                Body(e.title, modifier = Modifier.weight(1f).clickable { edit = e }.padding(vertical = 8.dp))
                DeleteX { MiniData.delEvent(e.id) }
            }
        }
    }

    // Neuer Termin für den gewählten Tag
    Spacer(Modifier.height(12.dp))
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = title, onValueChange = { title = it }, modifier = Modifier.weight(1f),
            placeholder = { Text("Neuer Termin …", color = TextC.copy(alpha = 0.35f)) }, singleLine = true,
            shape = RoundedCornerShape(26.dp), colors = fieldColors()
        )
        Spacer(Modifier.width(8.dp))
        HudButton("%02d:%02d".format(hour, minute), accent = Gold) {
            TimePickerDialog(ctx, { _, h, m -> hour = h; minute = m }, hour, minute, true).show()
        }
        Spacer(Modifier.width(8.dp))
        HudButton("＋", filled = true) {
            if (title.isNotBlank()) {
                val ms = sel.atTime(hour, minute).atZone(zone).toInstant().toEpochMilli()
                MiniData.addEvent(title, ms)
                title = ""
            }
        }
    }
    Spacer(Modifier.height(20.dp))
    edit?.let { e -> EditDialog("Termin umbenennen", e.title, { MiniData.editEvent(e.id, it, e.start) }) { edit = null } }
}

// ---------------------------------------------------------------- Erinnerungen

@Composable
fun RemindersApp() {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("") }
    var whenMs by remember { mutableLongStateOf(nextFullHour()) }
    OutlinedTextField(
        value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth(),
        placeholder = { Text("Woran soll ich erinnern? …", color = TextC.copy(alpha = 0.35f)) }, singleLine = true,
        shape = RoundedCornerShape(26.dp), colors = fieldColors()
    )
    Row(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        HudButton(fmtShort.format(Date(whenMs)), accent = Gold) { pickDateTime(ctx, whenMs) { whenMs = it } }
        HudButton("＋ ERINNERN", filled = true) {
            if (text.isNotBlank() && whenMs > System.currentTimeMillis()) {
                MiniData.addReminder(text, whenMs); text = ""
            } else {
                Toast.makeText(ctx, "Text und einen Zeitpunkt in der Zukunft angeben.", Toast.LENGTH_SHORT).show()
            }
        }
    }
    val all = MiniData.reminders.items.sortedBy { it.at }
    if (all.isEmpty()) Body("Keine Erinnerungen. Sage: „Erinnere mich in 20 Minuten an die Wäsche“.", dim = true)
    all.forEach { r ->
        key(r.id) {
            ItemRow {
                Column(Modifier.weight(1f).padding(vertical = 6.dp)) {
                    Body(r.text, dim = r.fired, strike = r.fired)
                    Text(fmtShort.format(Date(r.at)) + if (r.fired) " · gemeldet" else "", color = Cyan.copy(alpha = 0.8f), fontSize = 12.sp)
                }
                DeleteX { MiniData.delReminder(r.id) }
            }
        }
    }
}

// ---------------------------------------------------------------- Wetter

@Composable
fun WeatherApp() {
    var city by remember { mutableStateOf(Prefs.city) }
    var input by remember { mutableStateOf(Prefs.city) }
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
            placeholder = { Text("Ort, z. B. Hamburg", color = TextC.copy(alpha = 0.35f)) }, singleLine = true,
            shape = RoundedCornerShape(26.dp), colors = fieldColors()
        )
        Spacer(Modifier.width(8.dp))
        HudButton("OK", filled = true) {
            Prefs.city = input; city = input.trim()
        }
    }
    val (wx, err) = rememberLoad(city) { Weather.fetch(city) }
    when {
        wx != null -> {
            Text("${wx.temp}°", color = TextC, fontSize = 84.sp, fontWeight = FontWeight.ExtraLight)
            Text("${wx.city} · ${Weather.describe(wx.code)}", color = Cyan, fontSize = 16.sp)
            Body("Wind ${wx.wind} km/h", dim = true)
            Spacer(Modifier.height(20.dp))
            wx.days.forEach { d ->
                ItemRow {
                    Text(d.label, color = TextC, fontSize = 15.sp, modifier = Modifier.width(72.dp))
                    Text(Weather.describe(d.code), color = DimC, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Text("${d.min}° / ${d.max}°", color = TextC, fontSize = 14.sp)
                    Text("  ${d.rain} %", color = Cyan.copy(alpha = 0.8f), fontSize = 12.sp)
                }
            }
        }
        err != null -> Body(err, dim = true)
        else -> Body("Lade …", dim = true)
    }
}

// ---------------------------------------------------------------- News

@Composable
fun NewsApp() {
    val ctx = LocalContext.current
    var cat by remember { mutableStateOf("Top") }
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        News.categories.keys.forEach { c -> HudButton(c.uppercase(Locale.GERMAN), filled = c == cat) { cat = c } }
    }
    val (items, err) = rememberLoad(cat) { News.fetch(cat, 12) }
    when {
        items != null -> items.forEach { n ->
            Column(
                Modifier.fillMaxWidth().clickable {
                    try {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(n.link)))
                    } catch (_: Exception) {
                    }
                }.padding(vertical = 10.dp)
            ) {
                Text(n.title, color = TextC, fontSize = 16.sp, fontWeight = FontWeight.Light, lineHeight = 22.sp)
                Spacer(Modifier.height(3.dp))
                Text(n.source, color = Gold.copy(alpha = 0.8f), fontSize = 11.sp, letterSpacing = 1.sp)
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(Cyan.copy(alpha = 0.10f)))
        }
        err != null -> Body(err, dim = true)
        else -> Body("Lade …", dim = true)
    }
}

// ---------------------------------------------------------------- Uhr & Wecker

@Composable
fun ClockApp() {
    val ctx = LocalContext.current
    val now by rememberNow()
    Spacer(Modifier.height(24.dp))
    Text(
        SimpleDateFormat("HH:mm:ss", Locale.GERMANY).format(Date(now)),
        color = TextC, fontSize = 64.sp, fontWeight = FontWeight.ExtraLight, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
    )
    Text(
        SimpleDateFormat("EEEE, d. MMMM yyyy", Locale.GERMANY).format(Date(now)),
        color = DimC, fontSize = 15.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
    )
    Spacer(Modifier.height(28.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally)) {
        HudButton("WECKER STELLEN", filled = true) {
            val c = Calendar.getInstance()
            TimePickerDialog(ctx, { _, h, m ->
                try {
                    ctx.startActivity(
                        Intent(AlarmClock.ACTION_SET_ALARM)
                            .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
                            .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS").putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    )
                    Toast.makeText(ctx, "Wecker auf %02d:%02d gestellt.".format(h, m), Toast.LENGTH_SHORT).show()
                } catch (_: Exception) {
                    Toast.makeText(ctx, "Keine Wecker-App gefunden.", Toast.LENGTH_SHORT).show()
                }
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
        }
        HudButton("LISTE") {
            try {
                ctx.startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS))
            } catch (_: Exception) {
            }
        }
    }
    Spacer(Modifier.height(14.dp))
    Text(
        "Per Sprache: „Stelle einen Wecker auf 6 Uhr 30“. Gestellt wird er in der Wecker-App deines Handys.",
        color = DimC, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
    )
}

// ---------------------------------------------------------------- Stoppuhr & Timer

private fun fmtMs(ms: Long): String {
    val t = ms / 100
    return "%02d:%02d.%d".format(t / 600, (t / 10) % 60, t % 10)
}

@Composable
fun TimerApp() {
    val ctx = LocalContext.current
    var running by remember { mutableStateOf(false) }
    var base by remember { mutableLongStateOf(0L) }
    var startAt by remember { mutableLongStateOf(0L) }
    var shown by remember { mutableLongStateOf(0L) }
    LaunchedEffect(running) {
        while (running) {
            shown = base + (System.currentTimeMillis() - startAt)
            delay(50)
        }
    }
    Text("STOPPUHR", color = Cyan, fontSize = 11.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Medium)
    Text(fmtMs(shown), color = TextC, fontSize = 52.sp, fontWeight = FontWeight.ExtraLight, fontFamily = FontFamily.Monospace)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
        HudButton(if (running) "STOPP" else "START", filled = true) {
            if (running) {
                base += System.currentTimeMillis() - startAt; shown = base; running = false
            } else {
                startAt = System.currentTimeMillis(); running = true
            }
        }
        HudButton("RESET", accent = Gold) {
            running = false; base = 0; shown = 0
        }
    }

    Spacer(Modifier.height(24.dp))
    var mins by remember { mutableStateOf("5") }
    var cdRun by remember { mutableStateOf(false) }
    var endAt by remember { mutableLongStateOf(0L) }
    var remain by remember { mutableLongStateOf(0L) }
    LaunchedEffect(cdRun) {
        while (cdRun) {
            remain = endAt - System.currentTimeMillis()
            if (remain <= 0) {
                cdRun = false; remain = 0
                try {
                    RingtoneManager.getRingtone(ctx, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))?.play()
                } catch (_: Exception) {
                }
                Toast.makeText(ctx, "Timer abgelaufen.", Toast.LENGTH_LONG).show()
            }
            delay(200)
        }
    }
    Text("TIMER", color = Gold, fontSize = 11.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Medium)
    Text(fmtMs(if (cdRun) remain else (mins.toLongOrNull() ?: 0L) * 60_000L), color = TextC, fontSize = 40.sp, fontWeight = FontWeight.ExtraLight, fontFamily = FontFamily.Monospace)
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = mins, onValueChange = { mins = it.filter { c -> c.isDigit() }.take(4) },
            modifier = Modifier.width(120.dp), singleLine = true, label = { Text("Minuten") },
            shape = RoundedCornerShape(26.dp), colors = fieldColors()
        )
        HudButton(if (cdRun) "ABBRECHEN" else "START", filled = true) {
            if (cdRun) {
                cdRun = false
            } else {
                val m = mins.toLongOrNull() ?: 0L
                if (m > 0) {
                    endAt = System.currentTimeMillis() + m * 60_000L; remain = m * 60_000L; cdRun = true
                }
            }
        }
    }
    Spacer(Modifier.height(10.dp))
    Text("Läuft nur bei geöffneter App. Für Hintergrund sage: „Stelle einen Timer auf 10 Minuten“.", color = DimC, fontSize = 12.sp)
}

// ---------------------------------------------------------------- Rechner

object Calc {
    fun eval(src: String): Double {
        val s = src.replace(" ", "").replace('×', '*').replace('÷', '/').replace(',', '.')
        var pos = 0
        fun peek(): Char? = if (pos < s.length) s[pos] else null
        fun number(): Double {
            val st = pos
            if (peek() == '-') pos++
            while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
            return s.substring(st, pos).toDouble()
        }
        fun term(): Double {
            var v = number()
            while (true) {
                when (peek()) {
                    '*' -> { pos++; v *= number() }
                    '/' -> { pos++; v /= number() }
                    else -> return v
                }
            }
        }
        fun expr(): Double {
            var v = term()
            while (true) {
                when (peek()) {
                    '+' -> { pos++; v += term() }
                    '-' -> { pos++; v -= term() }
                    else -> return v
                }
            }
        }
        val r = expr()
        if (pos != s.length) throw IllegalArgumentException("Ausdruck")
        return r
    }

    fun show(d: Double): String {
        if (d.isNaN() || d.isInfinite()) return "Fehler"
        if (d == Math.floor(d) && Math.abs(d) < 1e12) return d.toLong().toString()
        return "%.8f".format(Locale.GERMANY, d).trimEnd('0').trimEnd(',')
    }
}

@Composable
private fun RowScope.Key(label: String, accent: Color = TextC, onClick: () -> Unit) {
    Box(
        Modifier
            .weight(1f)
            .height(62.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(accent.copy(alpha = 0.09f))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = accent, fontSize = 24.sp, fontWeight = FontWeight.Light)
    }
}

@Composable
fun CalcApp() {
    var expr by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    Spacer(Modifier.height(10.dp))
    Text(expr.ifEmpty { "0" }, color = TextC, fontSize = 40.sp, fontWeight = FontWeight.ExtraLight, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
    Text(result, color = Cyan, fontSize = 26.sp, fontWeight = FontWeight.Light, modifier = Modifier.fillMaxWidth().padding(bottom = 18.dp), textAlign = TextAlign.End)
    fun press(k: String) {
        when (k) {
            "C" -> { expr = ""; result = "" }
            "⌫" -> expr = expr.dropLast(1)
            "=" -> result = try {
                Calc.show(Calc.eval(expr))
            } catch (_: Exception) {
                "Fehler"
            }
            else -> expr += k
        }
    }
    val rows = listOf(
        listOf("7", "8", "9", "÷"), listOf("4", "5", "6", "×"), listOf("1", "2", "3", "-"),
        listOf("0", ",", "=", "+"), listOf("C", "⌫")
    )
    rows.forEach { r ->
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            r.forEach { k ->
                Key(k, accent = if (k in listOf("÷", "×", "-", "+", "=", "C", "⌫")) Gold else TextC) { press(k) }
            }
        }
    }
}
