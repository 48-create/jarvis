package de.jarvis.assistant

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager

class JarvisApp : Application() {
    companion object {
        lateinit var instance: JarvisApp
        const val CH_LISTEN = "jarvis_listen"
        const val CH_ACTION = "jarvis_action"
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_LISTEN, "Aktivierungswort", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ACTION, "Aktionen", NotificationManager.IMPORTANCE_HIGH)
        )
        JarvisEngine.init(this)
    }
}
