package de.jarvis.assistant

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager

class JarvisApp : Application() {
    companion object {
        lateinit var instance: JarvisApp
        const val CH_LISTEN = "jarvis_listen"
        const val CH_ACTION = "jarvis_action"
        const val CH_FALLBACK = "jarvis_fallback"
        const val CH_POPUP = "jarvis_popup"
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_LISTEN, "Aktivierungswort", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ACTION, "Aktionen", NotificationManager.IMPORTANCE_HIGH)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_FALLBACK, "Reserve beim Öffnen", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_POPUP, "Jarvis-Popup", NotificationManager.IMPORTANCE_HIGH)
        )
        MiniData.init()
        MiniData.rescheduleAll()
        JarvisEngine.init(this)
    }
}
