package de.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Drückt in WhatsApp den Senden-Knopf, aber nur in einem kurzen Zeitfenster,
 * nachdem der Nutzer eine Nachricht per Sprache oder Knopf bestätigt hat.
 */
class SendAssistService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (System.currentTimeMillis() > JarvisEngine.autoSendUntil) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString()?.startsWith("com.whatsapp") != true) return
        val send = findSend(root) ?: return
        var target: AccessibilityNodeInfo? = send
        while (target != null && !target.isClickable) target = target.parent
        if (target != null && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            JarvisEngine.autoSendUntil = 0L
            JarvisEngine.onAutoSent()
        }
    }

    override fun onInterrupt() {}

    private fun findSend(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val d = n.contentDescription?.toString()?.trim()?.lowercase()
        if (d == "senden" || d == "send") return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            findSend(c)?.let { return it }
        }
        return null
    }
}
