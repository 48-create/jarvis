package de.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.content.ContextCompat

/**
 * Bedienungshilfe: (1) drückt in WhatsApp nach deiner Bestätigung auf Senden,
 * (2) liest den Bildschirm, tippt und scrollt auf Befehl (nur wenn "Bildschirmsteuerung" eingeschaltet ist).
 */
class SendAssistService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: SendAssistService? = null
    }

    class Snap(val pkg: String, val text: String, val nodes: List<AccessibilityNodeInfo>) {
        val count: Int get() = nodes.size
        fun label(id: Int): String {
            val n = nodes.getOrNull(id) ?: return ""
            if (n.isPassword) return ""
            return n.text?.toString() ?: n.contentDescription?.toString() ?: ""
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (System.currentTimeMillis() > JarvisEngine.autoSendUntil) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString()?.startsWith("com.whatsapp") != true) return
        val send = findSend(root) ?: return
        var target: AccessibilityNodeInfo? = send
        while (target != null && !target.isClickable) target = target.parent
        if (target != null && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            JarvisEngine.autoSendUntil = 0L
            JarvisEngine.onAutoSent()
        }
    }

    private fun findSend(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val d = n.contentDescription?.toString()?.trim()?.lowercase()
        if (d == "senden" || d == "send") return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            findSend(c)?.let { return it }
        }
        return null
    }

    // ---------- Bildschirmsteuerung ----------

    /** Liest die sichtbaren Elemente des aktiven Fensters. Passwortfelder werden nie ausgelesen. */
    fun snapshot(): Snap? {
        val root = rootInActiveWindow ?: return null
        val nodes = ArrayList<AccessibilityNodeInfo>()
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo) {
            if (nodes.size >= 150) return
            val text = if (n.isPassword) "" else (n.text?.toString()?.take(80) ?: "")
            val desc = n.contentDescription?.toString()?.take(80) ?: ""
            val interesting = text.isNotBlank() || desc.isNotBlank() || n.isClickable || n.isEditable || n.isScrollable
            if (n.isVisibleToUser && interesting) {
                val id = nodes.size
                nodes.add(n)
                val cls = n.className?.toString()?.substringAfterLast('.') ?: "View"
                sb.append("[").append(id).append("] ").append(cls)
                if (text.isNotBlank()) sb.append(" \"").append(text).append('"')
                if (desc.isNotBlank()) sb.append(" desc=\"").append(desc).append('"')
                if (n.isClickable) sb.append(" klickbar")
                if (n.isEditable) sb.append(" eingabe")
                if (n.isScrollable) sb.append(" scrollbar")
                if (n.isPassword) sb.append(" passwortfeld")
                if (n.isChecked) sb.append(" aktiviert")
                sb.append('\n')
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                walk(c)
            }
        }
        walk(root)
        return Snap(root.packageName?.toString() ?: "", sb.toString(), nodes)
    }

    fun tapAt(x: Float, y: Float): Boolean {
        val p = Path()
        p.moveTo(x, y)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60))
            .build()
        return dispatchGesture(g, null, null)
    }

    fun click(snap: Snap, id: Int): Boolean {
        val n = snap.nodes.getOrNull(id) ?: return false
        var t: AccessibilityNodeInfo? = n
        while (t != null && !t.isClickable) t = t.parent
        if (t != null && t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val r = Rect()
        n.getBoundsInScreen(r)
        return tapAt(r.exactCenterX(), r.exactCenterY())
    }

    fun tapLabel(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val found = root.findAccessibilityNodeInfosByText(label)
        val n = found.firstOrNull { it.isVisibleToUser } ?: return false
        var t: AccessibilityNodeInfo? = n
        while (t != null && !t.isClickable) t = t.parent
        if (t != null && t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val r = Rect()
        n.getBoundsInScreen(r)
        return tapAt(r.exactCenterX(), r.exactCenterY())
    }

    fun typeText(snap: Snap, id: Int, text: String): Boolean {
        val n = snap.nodes.getOrNull(id) ?: return false
        if (n.isPassword) return false
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findScrollable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            findScrollable(c)?.let { return it }
        }
        return null
    }

    fun scroll(down: Boolean): Boolean {
        val target = rootInActiveWindow?.let { findScrollable(it) }
        val action = if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        if (target != null && target.performAction(action)) return true
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val p = Path()
        if (down) {
            p.moveTo(w / 2f, h * 0.7f)
            p.lineTo(w / 2f, h * 0.3f)
        } else {
            p.moveTo(w / 2f, h * 0.3f)
            p.lineTo(w / 2f, h * 0.7f)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 350))
            .build()
        return dispatchGesture(g, null, null)
    }

    fun global(kind: String): Boolean = when (kind) {
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        else -> false
    }

    fun screenSize(): Pair<Float, Float> {
        val dm = resources.displayMetrics
        return dm.widthPixels.toFloat() to dm.heightPixels.toFloat()
    }

    fun screenshot(cb: (Bitmap?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) {
            cb(null)
            return
        }
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                ContextCompat.getMainExecutor(this),
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                        val hb = result.hardwareBuffer
                        val bmp = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                        hb.close()
                        cb(bmp)
                    }

                    override fun onFailure(errorCode: Int) {
                        cb(null)
                    }
                }
            )
        } catch (e: Exception) {
            cb(null)
        }
    }
}
