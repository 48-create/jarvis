package de.jarvis.assistant

import android.content.Intent
import android.provider.AlarmClock
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class MiniResult(
    val reply: String? = null,
    val intent: Intent? = null,
    val async: (suspend () -> String)? = null
)

/** Erkennt Befehle für die Mini-Apps und führt sie wirklich aus (erstellen, ändern, löschen, anzeigen). */
object MiniVoice {
    private val I = RegexOption.IGNORE_CASE
    private val wake = Regex("""^(?:hey |hallo |hi |ok )?jarvis[,.:!]?\s*""", I)

    // Notizen
    private val noteNew1 = Regex("""^(?:erstelle|mach|schreib|speicher|leg)\w*\s+(?:mir\s+)?(?:eine?\s+)?(?:neue\s+)?notiz(?:\s+an)?\s*[:,]?\s+(?:dass\s+|über\s+|zu\s+)?(.+)""", I)
    private val noteNew2 = Regex("""^notiere\s+(?:mir\s+)?(.+)""", I)
    private val noteDel = Regex("""^(?:lösch|entfern)\w*\s+(?:die\s+|meine\s+)?(letzte\s+|alle\s+)?notiz(?:en)?\s*(.*)""", I)
    private val noteAppend = Regex("""^(?:ergänze|erweitere)\s+(?:die\s+)?notiz\s+(.+?)\s+(?:um|mit)\s+(.+)""", I)
    private val noteReplace = Regex("""^(?:ändere|ersetze)\s+(?:die\s+)?notiz\s+(.+?)\s+(?:in|zu|auf)\s+(.+)""", I)

    // Aufgaben
    private val todoAdd1 = Regex("""^(?:füge|setz|pack|schreib|tu|trag)\w*\s+(.+?)\s+(?:auf|zu|in)\s+(?:die\s+|meine\s+|meiner\s+|der\s+|meinen\s+)?(?:to-?do|aufgaben|einkaufs)\w*(?:\s*liste)?(?:\s+hinzu)?""", I)
    private val todoAdd2 = Regex("""^(?:erstelle\w*\s+(?:mir\s+)?(?:eine?\s+)?)?neue\s+aufgabe\s*[:,]?\s*(.+)""", I)
    private val todoDone1 = Regex("""^(?:hake|markiere)\s+(.+?)\s+(?:ab|als\s+erledigt|als\s+fertig)""", I)
    private val todoDone2 = Regex("""^(.+?)\s+ist\s+erledigt""", I)
    private val todoDone3 = Regex("""^erledigt\s*[:,]\s*(.+)""", I)
    private val todoDel = Regex("""^(?:lösch|entfern)\w*\s+(?:die\s+)?aufgabe\s+(.+)""", I)

    // Termine
    private val evAdd1 = Regex("""^(?:trag|erstelle|leg|speicher|mach)\w*\s+(?:mir\s+)?(?:einen\s+)?(?:neuen\s+)?termin\s*(.*)""", I)
    private val evAdd2 = Regex("""^(?:trag|schreib)\w*\s+(.+?)\s+(?:in|im)\s+(?:den\s+|meinen\s+)?kalender(?:\s+ein)?""", I)
    private val evDel = Regex("""^(?:lösch|entfern|sag)\w*\s+(?:den\s+)?termin\s+(.+?)(?:\s+ab)?$""", I)

    // Erinnerungen
    private val remAdd1 = Regex("""^erinnere\s+mich\s+(.+)""", I)
    private val remAdd2 = Regex("""^(?:stell|erstell|setz|mach|leg)\w*\s+(?:mir\s+)?(?:eine?\s+)?erinnerung\s+(.+)""", I)
    private val remDel = Regex("""^(?:lösch|entfern)\w*\s+(?:die\s+)?erinnerung\s+(.+)""", I)

    // Wecker / Timer / Rechnen
    private val timerRe = Regex("""(\d+|[a-zäöüß]+)\s*(sekunden?|minuten?|stunden?)""", I)
    private val calcRe = Regex("""^(?:was ist|rechne|berechne|wie viel ist)\s+(-?[\d.,]+)\s*(plus|minus|mal|geteilt durch|durch|\+|-|\*|x|/)\s*(-?[\d.,]+)""", I)

    private val fmtWhen = SimpleDateFormat("EEEE, d. MMMM 'um' HH:mm 'Uhr'", Locale.GERMANY)
    private val fmtDay = SimpleDateFormat("EEEE, d. MMMM", Locale.GERMANY)
    private val fmtHm = SimpleDateFormat("HH:mm", Locale.GERMANY)

    private fun cap(s: String) = s.trim().replaceFirstChar { it.uppercase() }
    private fun whenText(ms: Long): String = fmtWhen.format(Date(ms))

    private fun relDay(ms: Long): String {
        val a = Calendar.getInstance()
        val b = Calendar.getInstance().apply { timeInMillis = ms }
        val d = (b.get(Calendar.YEAR) * 366 + b.get(Calendar.DAY_OF_YEAR)) - (a.get(Calendar.YEAR) * 366 + a.get(Calendar.DAY_OF_YEAR))
        val time = fmtHm.format(Date(ms))
        return when (d) {
            0 -> "heute um $time Uhr"
            1 -> "morgen um $time Uhr"
            else -> whenText(ms)
        }
    }

    private fun <T> pick(items: List<T>, query: String, text: (T) -> String): T? {
        val q = query.trim().lowercase(Locale.GERMAN)
        if (q.isEmpty()) return null
        return items.lastOrNull { text(it).lowercase(Locale.GERMAN).contains(q) }
    }

    fun tryHandle(raw: String): MiniResult? {
        val t = raw.trim().replace(wake, "").trim().trimEnd('.', '!', '?')
        val low = t.lowercase(Locale.GERMAN)
        if (t.isEmpty()) return null
        val a = Prefs.title.ifBlank { "Sir" }

        // ---------- Notizen ----------
        noteAppend.find(t)?.let { m ->
            val n = pick(MiniData.notes.items, m.groupValues[1]) { it.text } ?: return say("Diese Notiz habe ich nicht gefunden, $a.")
            MiniData.editNote(n.id, n.text + " " + m.groupValues[2].trim())
            return say("Die Notiz wurde ergänzt.")
        }
        noteReplace.find(t)?.let { m ->
            val n = pick(MiniData.notes.items, m.groupValues[1]) { it.text } ?: return say("Diese Notiz habe ich nicht gefunden, $a.")
            MiniData.editNote(n.id, cap(m.groupValues[2]))
            return say("Die Notiz wurde geändert.")
        }
        noteDel.find(t)?.let { m ->
            val mode = m.groupValues[1].trim().lowercase(Locale.GERMAN)
            val arg = m.groupValues[2].trim()
            val items = MiniData.notes.items
            if (mode == "alle") {
                val n = items.size
                items.toList().forEach { MiniData.delNote(it.id) }
                return say(if (n == 0) "Es gab keine Notizen." else "Alle $n Notizen sind gelöscht.")
            }
            val n = if (mode == "letzte" || arg.isEmpty()) items.lastOrNull() else pick(items, arg) { it.text }
            if (n == null) return say("Diese Notiz habe ich nicht gefunden, $a.")
            MiniData.delNote(n.id)
            return say("Die Notiz „${n.text.take(40)}“ ist gelöscht.")
        }
        (noteNew1.find(t) ?: noteNew2.find(t))?.let { m ->
            val text = cap(m.groupValues[1])
            MiniData.addNote(text)
            return say("Notiert, $a.")
        }
        if (low.contains("notiz") && Regex("zeig|les|lies|vorles|welche|was steht|was für|alle").containsMatchIn(low)) {
            val items = MiniData.notes.items
            if (items.isEmpty()) return say("Du hast keine Notizen, $a.")
            val last = items.takeLast(5).reversed()
            return say("Du hast ${items.size} Notizen. " + last.joinToString(" ") { "${it.text}." })
        }

        // ---------- Aufgaben ----------
        todoDel.find(t)?.let { m ->
            val x = pick(MiniData.todos.items, m.groupValues[1]) { it.text } ?: return say("Diese Aufgabe habe ich nicht gefunden.")
            MiniData.delTodo(x.id)
            return say("Die Aufgabe „${x.text}“ ist gelöscht.")
        }
        if (Regex("(lösch|entfern)\\w*\\s+(alle\\s+)?erledigte").containsMatchIn(low)) {
            val n = MiniData.clearDoneTodos()
            return say(if (n == 0) "Es gibt keine erledigten Aufgaben." else "$n erledigte Aufgaben entfernt.")
        }
        (todoDone1.find(t) ?: todoDone3.find(t) ?: todoDone2.find(t))?.let { m ->
            val x = pick(MiniData.todos.items.filter { !it.done }, m.groupValues[1]) { it.text }
            if (x != null) {
                MiniData.setTodoDone(x.id, true)
                return say("Erledigt: ${x.text}.")
            }
            if (!low.contains("aufgabe") && !low.startsWith("hake") && !low.startsWith("markiere") && !low.startsWith("erledigt")) {
                return null // „ist erledigt“ ohne passende Aufgabe: normales Gespräch
            }
            return say("Diese offene Aufgabe habe ich nicht gefunden, $a.")
        }
        (todoAdd1.find(t) ?: todoAdd2.find(t))?.let { m ->
            val text = cap(m.groupValues[1])
            MiniData.addTodo(text)
            return say("Ich habe „$text“ auf die Liste gesetzt.")
        }
        if ((low.contains("aufgaben") || low.contains("to-do") || low.contains("todo")) &&
            Regex("zeig|lies|les|welche|was steht|was muss|was habe|offen").containsMatchIn(low)
        ) {
            val open = MiniData.todos.items.filter { !it.done }
            if (open.isEmpty()) return say("Alles erledigt, $a. Es gibt keine offenen Aufgaben.")
            return say("Offen sind ${open.size} Aufgaben: " + open.take(6).joinToString(", ") { it.text } + ".")
        }

        // ---------- Erinnerungen ----------
        remDel.find(t)?.let { m ->
            val x = pick(MiniData.reminders.items, m.groupValues[1]) { it.text } ?: return say("Diese Erinnerung habe ich nicht gefunden.")
            MiniData.delReminder(x.id)
            return say("Die Erinnerung „${x.text}“ ist gelöscht.")
        }
        (remAdd1.find(t) ?: remAdd2.find(t))?.let { m ->
            val r = DateParse.parse(m.groupValues[1])
            if (r.time == null) return say("Wann soll ich dich erinnern? Sage zum Beispiel: Erinnere mich morgen um 8 Uhr an den Arzt.")
            if (r.time <= System.currentTimeMillis()) return say("Dieser Zeitpunkt liegt in der Vergangenheit, $a.")
            val text = cap(r.rest.ifBlank { "Erinnerung" })
            MiniData.addReminder(text, r.time)
            return say("Ich erinnere dich ${relDay(r.time)}: $text.")
        }
        if (low.contains("erinnerungen") && Regex("zeig|welche|was|lies").containsMatchIn(low)) {
            val open = MiniData.reminders.items.filter { !it.fired }.sortedBy { it.at }
            if (open.isEmpty()) return say("Es sind keine Erinnerungen offen, $a.")
            return say(open.take(5).joinToString(" ") { "${it.text}, ${relDay(it.at)}." })
        }

        // ---------- Termine ----------
        evDel.find(t)?.let { m ->
            val x = pick(MiniData.events.items, m.groupValues[1]) { it.title } ?: return say("Diesen Termin habe ich nicht gefunden.")
            MiniData.delEvent(x.id)
            return say("Der Termin „${x.title}“ ist gelöscht.")
        }
        (evAdd2.find(t) ?: evAdd1.find(t))?.let { m ->
            val body = m.groupValues[1].replace(Regex("(?:^|\\s)ein$", I), "")
                .replace(Regex("^(?:namens|mit dem titel|für)\\s+", I), "")
            val r = DateParse.parse(body)
            if (r.time == null) return say("Für wann soll der Termin sein? Sage zum Beispiel: Trage einen Termin Zahnarzt morgen um 15 Uhr ein.")
            val title = cap(r.rest.ifBlank { "Termin" })
            MiniData.addEvent(title, r.time)
            return say("Eingetragen, $a: $title, ${relDay(r.time)}.")
        }
        if (low.contains("termin") || low.contains("kalender") || low.contains("steht an")) {
            if (Regex("zeig|welche|habe ich|was steht|nächste|lies|gibt es").containsMatchIn(low)) {
                val up = MiniData.upcomingEvents(4)
                if (up.isEmpty()) return say("Dein Kalender ist leer, $a.")
                return say("Als Nächstes: " + up.joinToString(" ") { "${it.title}, ${relDay(it.start)}." })
            }
        }

        // ---------- Wecker, Timer, Rechnen ----------
        if (low.contains("wecker") || Regex("^weck\\w*\\s+mich").containsMatchIn(low)) {
            if (Regex("zeig|öffne|welche|lösch|entfern|ausschalt|deaktivier").containsMatchIn(low)) {
                return MiniResult(
                    reply = "Ich öffne die Weckerliste. Zum Löschen oder Ausschalten tippe dort auf den Wecker, $a.",
                    intent = Intent(AlarmClock.ACTION_SHOW_ALARMS)
                )
            }
            if (Regex("stell|mach|setz|erstell|weck").containsMatchIn(low)) {
                val r = DateParse.parse(t)
                if (r.hour == null) return say("Auf welche Uhrzeit soll ich den Wecker stellen?")
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, r.hour)
                    .putExtra(AlarmClock.EXTRA_MINUTES, r.minute ?: 0)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                return MiniResult(
                    reply = "Der Wecker ist auf ${"%02d:%02d".format(r.hour, r.minute ?: 0)} Uhr gestellt, $a.",
                    intent = i
                )
            }
        }
        if (low.contains("timer") && Regex("stell|setz|starte|mach|erstell").containsMatchIn(low)) {
            var secs = 0
            for (m in timerRe.findAll(low)) {
                val n = m.groupValues[1].toIntOrNull() ?: wordNum(m.groupValues[1]) ?: continue
                secs += when {
                    m.groupValues[2].startsWith("sekunde") -> n
                    m.groupValues[2].startsWith("minute") -> n * 60
                    else -> n * 3600
                }
            }
            if (secs <= 0) return say("Wie lange soll der Timer laufen?")
            val i = Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, secs)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            val txt = if (secs % 3600 == 0) "${secs / 3600} Stunden" else if (secs % 60 == 0) "${secs / 60} Minuten" else "$secs Sekunden"
            return MiniResult(reply = "Der Timer läuft: $txt, $a.", intent = i)
        }
        calcRe.find(t)?.let { m ->
            val x = m.groupValues[1].replace(".", "").replace(',', '.').toDoubleOrNull()
            val y = m.groupValues[3].replace(".", "").replace(',', '.').toDoubleOrNull()
            if (x != null && y != null) {
                val op = m.groupValues[2].lowercase(Locale.GERMAN)
                val res = when (op) {
                    "plus", "+" -> x + y
                    "minus", "-" -> x - y
                    "mal", "*", "x" -> x * y
                    else -> if (y == 0.0) return say("Durch null kann ich nicht teilen, $a.") else x / y
                }
                val txt = if (res == Math.floor(res) && Math.abs(res) < 1e12) res.toLong().toString()
                else "%.4f".format(Locale.GERMANY, res).trimEnd('0').trimEnd(',')
                return say("Das ergibt $txt.")
            }
        }

        // ---------- Wetter & Nachrichten ----------
        if (low.contains("wetter") && !low.startsWith("öffne") && !low.startsWith("starte")) {
            val city = Regex("""(?:wetter|vorhersage)\s+(?:in|für|von)\s+([\p{L}][\p{L} .-]*?)(?:\s+(?:heute|morgen|gerade|jetzt))?$""", I)
                .find(t)?.groupValues?.get(1)?.trim()?.ifEmpty { null } ?: Prefs.city
            return MiniResult(async = { Weather.speak(city) })
        }
        if (Regex("nachrichten|schlagzeilen|\\bnews\\b").containsMatchIn(low) &&
            !low.startsWith("öffne") && !low.startsWith("starte") && !low.contains("schick") && !low.contains("schreib") && !low.contains("whatsapp")
        ) {
            val cat = News.categoryIn(low)
            return MiniResult(async = { News.speak(cat) })
        }
        return null
    }

    private fun say(s: String) = MiniResult(reply = s)

    private fun wordNum(w: String): Int? = when (w.lowercase(Locale.GERMAN)) {
        "eine", "einer", "ein" -> 1
        "zwei" -> 2
        "drei" -> 3
        "vier" -> 4
        "fünf" -> 5
        "sechs" -> 6
        "sieben" -> 7
        "acht" -> 8
        "neun" -> 9
        "zehn" -> 10
        "fünfzehn" -> 15
        "zwanzig" -> 20
        "dreißig" -> 30
        "vierzig" -> 40
        "fünfundvierzig" -> 45
        "sechzig" -> 60
        else -> null
    }
}
