package de.jarvis.assistant

import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.IOException
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale

object Net {
    fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 12000
            c.readTimeout = 20000
            c.setRequestProperty("User-Agent", "JARVIS-Android/1.1")
            val code = c.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
}

object Weather {
    data class Day(val label: String, val min: Int, val max: Int, val rain: Int, val code: Int)
    data class Wx(val city: String, val temp: Int, val code: Int, val wind: Int, val days: List<Day>)

    fun describe(code: Int): String = when (code) {
        0 -> "klar"
        1, 2 -> "überwiegend sonnig"
        3 -> "bedeckt"
        45, 48 -> "neblig"
        in 51..57 -> "Nieselregen"
        in 61..67 -> "Regen"
        in 71..77 -> "Schnee"
        in 80..82 -> "Regenschauer"
        in 85..86 -> "Schneeschauer"
        in 95..99 -> "Gewitter"
        else -> "wechselhaft"
    }

    suspend fun fetch(cityIn: String): Wx = withContext(Dispatchers.IO) {
        val city = cityIn.trim()
        if (city.isEmpty()) throw Exception("Lege zuerst in den Einstellungen deinen Wetter-Ort fest.")
        try {
            val g = JSONObject(Net.get("https://geocoding-api.open-meteo.com/v1/search?name=${Net.enc(city)}&count=1&language=de"))
            val r = g.optJSONArray("results")?.optJSONObject(0) ?: throw Exception("Den Ort $city kenne ich nicht.")
            val name = r.optString("name", city)
            val url = "https://api.open-meteo.com/v1/forecast?latitude=${r.getDouble("latitude")}&longitude=${r.getDouble("longitude")}" +
                "&current=temperature_2m,weather_code,wind_speed_10m" +
                "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                "&timezone=auto&forecast_days=4"
            val j = JSONObject(Net.get(url))
            val cur = j.getJSONObject("current")
            val d = j.getJSONObject("daily")
            val times = d.getJSONArray("time")
            val fmtIn = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val fmtOut = SimpleDateFormat("EEEE", Locale.GERMANY)
            val days = (0 until times.length()).map { i ->
                val label = when (i) {
                    0 -> "Heute"
                    1 -> "Morgen"
                    else -> fmtIn.parse(times.getString(i))?.let { fmtOut.format(it) } ?: times.getString(i)
                }
                Day(
                    label,
                    Math.round(d.getJSONArray("temperature_2m_min").getDouble(i)).toInt(),
                    Math.round(d.getJSONArray("temperature_2m_max").getDouble(i)).toInt(),
                    d.getJSONArray("precipitation_probability_max").optInt(i, 0),
                    d.getJSONArray("weather_code").getInt(i)
                )
            }
            Wx(
                name,
                Math.round(cur.getDouble("temperature_2m")).toInt(),
                cur.getInt("weather_code"),
                Math.round(cur.getDouble("wind_speed_10m")).toInt(),
                days
            )
        } catch (e: IOException) {
            throw Exception("Das Wetter konnte ich nicht laden. Prüfe die Internetverbindung.")
        }
    }

    suspend fun speak(city: String): String {
        val w = fetch(city)
        val t = w.days.getOrNull(1)
        return "In ${w.city} sind es gerade ${w.temp} Grad, ${describe(w.code)}. " +
            "Heute werden es bis zu ${w.days[0].max} Grad bei ${w.days[0].rain} Prozent Regenwahrscheinlichkeit." +
            (if (t != null) " Morgen ${t.min} bis ${t.max} Grad, ${describe(t.code)}." else "")
    }
}

object News {
    data class Item(val title: String, val source: String, val link: String)

    /** Anzeigename -> Google-News-Thema; „q:“ bedeutet Suchbegriff. */
    val categories = linkedMapOf(
        "Top" to "",
        "Technik" to "TECHNOLOGY",
        "Gaming" to "q:Videospiele Gaming",
        "Sport" to "SPORTS",
        "Wirtschaft" to "BUSINESS",
        "Politik" to "NATION",
        "Welt" to "WORLD",
        "Wissenschaft" to "SCIENCE"
    )

    private const val TAIL = "hl=de&gl=DE&ceid=DE:de"

    private fun urlFor(cat: String): String {
        val v = categories[cat] ?: ""
        return when {
            v.isEmpty() -> "https://news.google.com/rss?$TAIL"
            v.startsWith("q:") -> "https://news.google.com/rss/search?q=${Net.enc(v.drop(2))}&$TAIL"
            else -> "https://news.google.com/rss/headlines/section/topic/$v?$TAIL"
        }
    }

    /** Erkennt das Thema in einem Satz („Technik-News“, „Sportnachrichten“ …). */
    fun categoryIn(text: String): String {
        val low = text.lowercase(Locale.GERMAN)
        return when {
            low.contains("gaming") || low.contains("spiele") || low.contains("videospiel") -> "Gaming"
            low.contains("technik") || low.contains("tech") -> "Technik"
            low.contains("sport") || low.contains("fußball") -> "Sport"
            low.contains("wirtschaft") || low.contains("börse") -> "Wirtschaft"
            low.contains("politik") -> "Politik"
            low.contains("wissenschaft") -> "Wissenschaft"
            low.contains("welt") || low.contains("ausland") -> "Welt"
            else -> "Top"
        }
    }

    suspend fun fetch(cat: String = "Top", max: Int = 12): List<Item> = withContext(Dispatchers.IO) {
        val xml = try {
            Net.get(urlFor(cat))
        } catch (e: IOException) {
            throw Exception("Die Nachrichten konnte ich nicht laden. Prüfe die Internetverbindung.")
        }
        val out = ArrayList<Item>()
        val p = Xml.newPullParser()
        p.setInput(StringReader(xml))
        var ev = p.eventType
        var inItem = false
        var t = ""
        var l = ""
        var s = ""
        while (ev != XmlPullParser.END_DOCUMENT && out.size < max) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "item" -> { inItem = true; t = ""; l = ""; s = "" }
                    "title" -> if (inItem) t = p.nextText()
                    "link" -> if (inItem) l = p.nextText()
                    "source" -> if (inItem) s = p.nextText()
                }
            } else if (ev == XmlPullParser.END_TAG && p.name == "item") {
                inItem = false
                val title = if (s.isNotEmpty() && t.endsWith(" - $s")) t.removeSuffix(" - $s") else t
                if (title.isNotBlank()) out.add(Item(title.trim(), s.ifBlank { "Google News" }, l))
            }
            ev = p.next()
        }
        out
    }

    suspend fun speak(cat: String): String {
        val items = fetch(cat, 3)
        if (items.isEmpty()) return "Dazu habe ich gerade keine Meldungen gefunden."
        val head = if (cat == "Top") "Die aktuellen Schlagzeilen:" else "Die aktuellen Meldungen zu $cat:"
        return head + " " + items.mapIndexed { i, it -> "${i + 1}. ${it.title}, laut ${it.source}." }.joinToString(" ")
    }
}
