package de.jarvis.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Ruft die Google-Gemini-REST-API auf (kostenloser Schlüssel von aistudio.google.com). */
object GeminiClient {
    private fun system(): String {
        val title = Prefs.title.ifBlank { "Sir" }
        val now = SimpleDateFormat("EEEE, d. MMMM yyyy, HH:mm 'Uhr'", Locale.GERMANY).format(Date())
        return "Du bist J.A.R.V.I.S., der KI-Butler aus Iron Man, jetzt als deutscher Sprachassistent auf dem Handy. " +
            "Stil: gepflegt, ruhig, souverän, mit trockenem britischem Humor, höflich-ironisch, nie albern. " +
            "Sprich den Nutzer als \"$title\" an, aber nicht in jedem Satz, und setze die Anrede ohne Kommas, zum Beispiel Guten Morgen $title statt Guten Morgen, $title. " +
            "Antworte immer auf Deutsch in höchstens drei kurzen Sätzen, ohne Markdown, Listen, Sternchen oder Emojis, " +
            "weil die Antwort vorgelesen wird. Beginne gern mit einer knappen Bestätigung wie Sehr wohl, Natürlich oder " +
            "Selbstverständlich, variiere aber. Erfinde keine Fakten; wenn du etwas nicht weißt, sag es elegant. " +
            "Aktuelles Datum und aktuelle Uhrzeit: $now. " +
            "Die App erledigt Befehle separat: Apps öffnen, WhatsApp vorbereiten, Notizen, Aufgaben, Termine, Erinnerungen, " +
            "Wecker, Timer, Wetter, Nachrichten und die Bildschirmsteuerung. " +
            "Behaupte nie, du hättest so etwas getan, wenn du nur antwortest. " +
            "${Chats.projectContext()}" +
            "Daten aus dem Dashboard des Nutzers (darfst du für Antworten nutzen): ${MiniData.summary()}"
    }

    // ---------- Schlüssel- und Modellverwaltung ----------

    class ApiError(val code: Int, msg: String) : Exception(msg)

    enum class Kind { SHORT_CHAT, CHAT, VISION }

    private val cooldown = HashMap<String, Long>()

    private fun keyId(k: String) = k.takeLast(6)
    private fun cooling(k: String) = (cooldown[keyId(k)] ?: 0L) > System.currentTimeMillis()
    private fun cool(k: String, ms: Long) {
        cooldown[keyId(k)] = System.currentTimeMillis() + ms
    }

    /** Reihenfolge der Modelle: automatisch passendes zuerst, dann Hauptmodell, dann Reserven. */
    private fun models(kind: Kind): List<String> {
        val list = ArrayList<String>()
        if (Prefs.autoModel && kind == Kind.SHORT_CHAT && Prefs.fastModel.isNotBlank()) list.add(Prefs.fastModel)
        list.add(Prefs.model)
        Prefs.fallbackModels.split(',').map { it.trim() }.filter { it.isNotEmpty() }.forEach { list.add(it) }
        return list.distinct()
    }

    private fun httpPost(url: String, headerName: String, headerValue: String, body: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty(headerName, headerValue)
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw ApiError(code, text.take(160))
            return text
        } finally {
            conn.disconnect()
        }
    }

    private fun post(model: String, key: String, body: JSONObject): String =
        httpPost("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent", "x-goog-api-key", key, body.toString())

    // ---------- OpenAI-kompatible Anbieter (NVIDIA, eigene URL) ----------

    private fun chatUrl(e: KeyEntry): String {
        val base = (if (e.provider == Provider.NVIDIA) "https://integrate.api.nvidia.com/v1" else e.url.trim()).trimEnd('/')
        return if (base.endsWith("/chat/completions")) base else "$base/chat/completions"
    }

    /** Übersetzt die Gemini-Anfrage in das Chat-Format (Bilder werden nicht übertragen). */
    private fun toOpenAi(body: JSONObject, model: String): JSONObject {
        val msgs = JSONArray()
        var sys = body.optJSONObject("system_instruction")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text") ?: ""
        if (body.optJSONObject("generationConfig")?.optString("responseMimeType") == "application/json") {
            sys += "\n\nAntworte ausschließlich mit einem gültigen JSON-Objekt, ohne Markdown und ohne Text davor oder danach."
        }
        if (sys.isNotBlank()) msgs.put(JSONObject().put("role", "system").put("content", sys))
        val c = body.optJSONArray("contents") ?: JSONArray()
        for (i in 0 until c.length()) {
            val m = c.getJSONObject(i)
            val parts = m.optJSONArray("parts") ?: continue
            val sb = StringBuilder()
            for (k in 0 until parts.length()) sb.append(parts.getJSONObject(k).optString("text"))
            msgs.put(
                JSONObject().put("role", if (m.optString("role") == "model") "assistant" else "user").put("content", sb.toString())
            )
        }
        return JSONObject().put("model", model).put("messages", msgs).put("temperature", 0.6).put("max_tokens", 1024)
    }

    private fun postOpenAi(e: KeyEntry, model: String, body: JSONObject): String =
        httpPost(chatUrl(e), "Authorization", "Bearer ${e.key}", toOpenAi(body, model).toString())

    private fun extractOpenAi(raw: String): String {
        try {
            val txt = JSONObject(raw).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content") ?: ""
            val clean = txt.replace(Regex("<think>[\\s\\S]*?</think>"), "").trim()
            return clean.ifEmpty { "Dazu habe ich keine Antwort erhalten." }
        } catch (e: JSONException) {
            throw Exception("Die Antwort des KI-Dienstes war unverständlich.")
        }
    }

    private fun friendly(code: Int, model: String): String = when (code) {
        400 -> "Die Anfrage wurde abgelehnt. Prüfe die API-Schlüssel in den Einstellungen."
        401, 403 -> "Kein API-Schlüssel wird akzeptiert. Bitte prüfe sie in den Einstellungen."
        404 -> "Das KI-Modell „$model“ gibt es nicht (mehr). Ändere den Modellnamen in den Einstellungen."
        429 -> "Das Kontingent aller Schlüssel ist gerade aufgebraucht. Bitte versuche es später noch einmal."
        500, 502, 503, 504 -> "Der KI-Dienst ist überlastet. Versuche es gleich noch einmal."
        else -> "Der KI-Dienst meldet Fehler $code."
    }

    /** Probiert die Schlüssel-Ablagen in der eingestellten Reihenfolge (und bei Gemini die Modelle), bis eine Anfrage gelingt. */
    private fun callWithFailover(body: JSONObject, kind: Kind): String {
        val all = Prefs.keyEntries.filter { it.key.isNotBlank() }
        if (all.isEmpty()) {
            throw Exception(
                "Für diese Funktion brauche ich einen KI-Schlüssel (zum Beispiel kostenlos von Gemini oder NVIDIA). " +
                    "Trage ihn bitte in den Einstellungen ein, ${Prefs.title}."
            )
        }
        val entries = all.filter { (kind != Kind.VISION || it.provider == Provider.GEMINI) && (it.provider != Provider.CUSTOM || it.url.isNotBlank()) }
        if (entries.isEmpty()) {
            throw Exception(
                if (kind == Kind.VISION) "Zum Ansehen des Bildschirms brauche ich einen Gemini-Schlüssel. Trage ihn in den Einstellungen ein, ${Prefs.title}."
                else "Bei der Ablage „Eigene URL“ fehlt die Adresse. Bitte in den Einstellungen ergänzen."
            )
        }
        var lastCode = 0
        var lastModel = Prefs.model
        var network: Exception? = null
        for (pass in 0..1) {
            var attempted = false
            for (e in entries) {
                if (pass == 0 && cooling(e.key)) continue
                val gemini = e.provider == Provider.GEMINI
                val models = if (gemini) models(kind) else listOf(e.model.ifBlank { Provider.defaultModel(e.provider) })
                modelLoop@ for (model in models) {
                    lastModel = model
                    attempted = true
                    try {
                        val raw = if (gemini) post(model, e.key, body) else postOpenAi(e, model, body)
                        Usage.record(e.key, model, null)
                        return if (gemini) extract(raw) else extractOpenAi(raw)
                    } catch (x: ApiError) {
                        lastCode = x.code
                        Usage.record(e.key, model, "${x.code}")
                        when (x.code) {
                            401, 403 -> { cool(e.key, 10 * 60_000L); break@modelLoop }
                            429 -> { cool(e.key, 60_000L); break@modelLoop }
                            500, 502, 503, 504 -> { cool(e.key, 20_000L); break@modelLoop }
                        }
                    } catch (x: java.net.SocketTimeoutException) {
                        network = x
                        Usage.record(e.key, model, "Zeit")
                        break@modelLoop
                    } catch (x: IOException) {
                        network = x
                        Usage.record(e.key, model, "Netz")
                        break@modelLoop
                    }
                }
            }
            if (attempted) break
        }
        if (lastCode == 0 && network != null) {
            throw Exception(
                if (network is java.net.SocketTimeoutException)
                    "Der KI-Dienst hat zu lange gebraucht (Zeitüberschreitung). Versuche es noch einmal."
                else "Verbindungsfehler zum KI-Dienst. Prüfe die Internetverbindung."
            )
        }
        throw Exception(friendly(lastCode, lastModel))
    }

    private fun extract(raw: String): String {
        try {
            val cands = JSONObject(raw).optJSONArray("candidates")
            val parts = cands?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                ?: return "Dazu kann ich leider nichts sagen, ${Prefs.title}."
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
            return sb.toString().trim().ifEmpty { "Dazu habe ich keine Antwort erhalten." }
        } catch (e: JSONException) {
            throw Exception("Die Antwort des KI-Dienstes war unverständlich.")
        }
    }

    /** history: Paare aus Rolle ("user" oder "model") und Text. Wirft Exception mit deutscher Meldung. */
    suspend fun ask(history: List<Pair<String, String>>): String = withContext(Dispatchers.IO) {
        val contents = JSONArray()
        for ((role, text) in history) {
            contents.put(
                JSONObject()
                    .put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system()))))
            .put("contents", contents)
        val last = history.lastOrNull { it.first == "user" }?.second ?: ""
        val kind = if (last.length < 90 && history.size <= 4) Kind.SHORT_CHAT else Kind.CHAT
        callWithFailover(body, kind)
    }

    /** Einmalige Anfrage, optional mit Bildschirmfoto (JPEG als Base64) und optional als JSON-Antwort. */
    suspend fun generate(system: String, userText: String, imageB64: String?, json: Boolean): String =
        withContext(Dispatchers.IO) {
            val parts = JSONArray().put(JSONObject().put("text", userText))
            if (imageB64 != null) {
                parts.put(
                    JSONObject().put(
                        "inline_data",
                        JSONObject().put("mime_type", "image/jpeg").put("data", imageB64)
                    )
                )
            }
            val body = JSONObject()
                .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            if (json) body.put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
            callWithFailover(body, if (imageB64 != null) Kind.VISION else Kind.CHAT)
        }
}

/** Zählt Aufrufe und Fehler je Schlüssel (nur die letzten 6 Zeichen werden gespeichert). */
object Usage {
    fun record(key: String, model: String, error: String?) {
        try {
            val all = JSONObject(Prefs.usageJson)
            val id = key.takeLast(6)
            val o = all.optJSONObject(id) ?: JSONObject()
            o.put("calls", o.optInt("calls") + 1)
            if (error != null) {
                o.put("errors", o.optInt("errors") + 1)
                o.put("lastError", error)
            }
            o.put("last", System.currentTimeMillis())
            o.put("model", model)
            all.put(id, o)
            Prefs.usageJson = all.toString()
        } catch (_: Exception) {
        }
    }

    fun reset() {
        Prefs.usageJson = "{}"
    }

    /** Eine Zeile pro Schlüssel für die Einstellungen. */
    fun lines(): List<String> {
        val all = try {
            JSONObject(Prefs.usageJson)
        } catch (_: Exception) {
            JSONObject()
        }
        return Prefs.keyEntries.filter { it.key.isNotBlank() }.map { e ->
            val o = all.optJSONObject(e.key.takeLast(6))
            val head = "${e.name.ifBlank { "Schlüssel" }} (${Provider.label(e.provider)} …${e.key.takeLast(4)})"
            if (o == null) "$head: noch nicht benutzt"
            else {
                val err = if (o.optInt("errors") > 0) ", ${o.optInt("errors")} Fehler (zuletzt ${o.optString("lastError")})" else ""
                "$head: ${o.optInt("calls")} Aufrufe$err"
            }
        }
    }
}
