package de.jarvis.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Ruft die Google-Gemini-REST-API auf (kostenloser Schlüssel von aistudio.google.com). */
object GeminiClient {
    private fun system(): String {
        val title = Prefs.title.ifBlank { "Sir" }
        val now = SimpleDateFormat("EEEE, d. MMMM yyyy, HH:mm 'Uhr'", Locale.GERMANY).format(Date())
        return "Du bist J.A.R.V.I.S., der KI-Butler aus Iron Man, jetzt als deutscher Sprachassistent auf dem Handy. " +
            "Stil: gepflegt, ruhig, souverän, mit trockenem britischem Humor, höflich-ironisch, nie albern. " +
            "Sprich den Nutzer als \"$title\" an, aber nicht in jedem Satz, und setze die Anrede ohne Kommas, zum Beispiel Guten Morgen $title statt Guten Morgen, $title. " +
            "Antworte immer auf Deutsch in höchstens drei kurzen Sätzen, ohne Markdown, Listen, Sternchen oder Emojis, " +
            "weil die Antwort vorgelesen wird. Beginne gern mit einer knappen Bestätigung wie Sehr wohl, Natürlich oder " +
            "Selbstverständlich, variiere aber. Erfinde keine Fakten; wenn du etwas nicht weißt, sag es elegant. " +
            "Aktuelles Datum und aktuelle Uhrzeit: $now. " +
            "Die App erledigt Befehle separat: Apps öffnen, WhatsApp vorbereiten, Notizen, Aufgaben, Termine, Erinnerungen, " +
            "Wecker, Timer, Wetter, Nachrichten und die Bildschirmsteuerung. " +
            "Behaupte nie, du hättest so etwas getan, wenn du nur antwortest. " +
            "${Chats.projectContext()}" +
            "Daten aus dem Dashboard des Nutzers (darfst du für Antworten nutzen): ${MiniData.summary()}"
    }

    // ---------- Schlüssel- und Modellverwaltung ----------

    class ApiError(val code: Int, msg: String) : Exception(msg)

    enum class Kind { SHORT_CHAT, CHAT, VISION }

    private val cooldown = HashMap<String, Long>()

    private fun keyId(k: String) = k.takeLast(6)
    private fun cooling(k: String) = (cooldown[keyId(k)] ?: 0L) > System.currentTimeMillis()
    private fun cool(k: String, ms: Long) {
        cooldown[keyId(k)] = System.currentTimeMillis() + ms
    }

    /** Reihenfolge der Modelle: automatisch passendes zuerst, dann Hauptmodell, dann Reserven. */
    private fun models(kind: Kind): List<String> {
        val list = ArrayList<String>()
        if (Prefs.autoModel && kind == Kind.SHORT_CHAT && Prefs.fastModel.isNotBlank()) list.add(Prefs.fastModel)
        list.add(Prefs.model)
        Prefs.fallbackModels.split(',').map { it.trim() }.filter { it.isNotEmpty() }.forEach { list.add(it) }
        return list.distinct()
    }

    private fun post(model: String, key: String, body: JSONObject): String {
        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw ApiError(code, text.take(160))
            return text
        } finally {
            conn.disconnect()
        }
    }

    private fun friendly(code: Int, model: String): String = when (code) {
        400 -> "Die Anfrage wurde abgelehnt. Prüfe die API-Schlüssel in den Einstellungen."
        401, 403 -> "Kein API-Schlüssel wird akzeptiert. Bitte prüfe sie in den Einstellungen."
        404 -> "Das KI-Modell „$model“ gibt es nicht (mehr). Ändere den Modellnamen in den Einstellungen."
        429 -> "Das kostenlose Kontingent aller Schlüssel ist gerade aufgebraucht. Bitte versuche es später noch einmal."
        500, 502, 503, 504 -> "Der KI-Dienst ist überlastet. Versuche es gleich noch einmal."
        else -> "Der KI-Dienst meldet Fehler $code."
    }

    /** Probiert Schlüssel und Modelle der Reihe nach, bis eine Anfrage gelingt. Liefert den Antworttext der KI. */
    private fun callWithFailover(body: JSONObject, kind: Kind): String {
        val keys = Prefs.apiKeys
        if (keys.isEmpty()) {
            throw Exception(
                "Für diese Funktion brauche ich einen kostenlosen Gemini-Schlüssel. " +
                    "Trage ihn bitte in den Einstellungen ein, ${Prefs.title}."
            )
        }
        var lastCode = 0
        var lastModel = Prefs.model
        var network: Exception? = null
        for (pass in 0..1) {
            var attempted = false
            for (model in models(kind)) {
                lastModel = model
                var modelBroken = false
                for (k in keys) {
                    if (modelBroken) break
                    if (pass == 0 && cooling(k)) continue
                    attempted = true
                    try {
                        val raw = post(model, k, body)
                        Usage.record(k, model, null)
                        return extract(raw)
                    } catch (e: ApiError) {
                        lastCode = e.code
                        Usage.record(k, model, "${e.code}")
                        when (e.code) {
                            401, 403 -> cool(k, 10 * 60_000L)
                            429 -> cool(k, 60_000L)
                            500, 502, 503, 504 -> cool(k, 20_000L)
                            400, 404 -> modelBroken = true
                        }
                    } catch (e: java.net.SocketTimeoutException) {
                        network = e
                        Usage.record(k, model, "Zeit")
                    } catch (e: IOException) {
                        network = e
                        Usage.record(k, model, "Netz")
                        break
                    }
                }
            }
            if (attempted) break
        }
        if (lastCode == 0 && network != null) {
            throw Exception(
                if (network is java.net.SocketTimeoutException)
                    "Der KI-Dienst hat zu lange gebraucht (Zeitüberschreitung). Versuche es noch einmal."
                else "Verbindungsfehler zum KI-Dienst. Prüfe die Internetverbindung."
            )
        }
        throw Exception(friendly(lastCode, lastModel))
    }

    private fun extract(raw: String): String {
        try {
            val cands = JSONObject(raw).optJSONArray("candidates")
            val parts = cands?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                ?: return "Dazu kann ich leider nichts sagen, ${Prefs.title}."
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
            return sb.toString().trim().ifEmpty { "Dazu habe ich keine Antwort erhalten." }
        } catch (e: JSONException) {
            throw Exception("Die Antwort des KI-Dienstes war unverständlich.")
        }
    }

    /** history: Paare aus Rolle ("user" oder "model") und Text. Wirft Exception mit deutscher Meldung. */
    suspend fun ask(history: List<Pair<String, String>>): String = withContext(Dispatchers.IO) {
        val contents = JSONArray()
        for ((role, text) in history) {
            contents.put(
                JSONObject()
                    .put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system()))))
            .put("contents", contents)
        val last = history.lastOrNull { it.first == "user" }?.second ?: ""
        val kind = if (last.length < 90 && history.size <= 4) Kind.SHORT_CHAT else Kind.CHAT
        callWithFailover(body, kind)
    }

    /** Einmalige Anfrage, optional mit Bildschirmfoto (JPEG als Base64) und optional als JSON-Antwort. */
    suspend fun generate(system: String, userText: String, imageB64: String?, json: Boolean): String =
        withContext(Dispatchers.IO) {
            val parts = JSONArray().put(JSONObject().put("text", userText))
            if (imageB64 != null) {
                parts.put(
                    JSONObject().put(
                        "inline_data",
                        JSONObject().put("mime_type", "image/jpeg").put("data", imageB64)
                    )
                )
            }
            val body = JSONObject()
                .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            if (json) body.put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
            callWithFailover(body, if (imageB64 != null) Kind.VISION else Kind.CHAT)
        }
}

/** Zählt Aufrufe und Fehler je Schlüssel (nur die letzten 6 Zeichen werden gespeichert). */
object Usage {
    fun record(key: String, model: String, error: String?) {
        try {
            val all = JSONObject(Prefs.usageJson)
            val id = key.takeLast(6)
            val o = all.optJSONObject(id) ?: JSONObject()
            o.put("calls", o.optInt("calls") + 1)
            if (error != null) {
                o.put("errors", o.optInt("errors") + 1)
                o.put("lastError", error)
            }
            o.put("last", System.currentTimeMillis())
            o.put("model", model)
            all.put(id, o)
            Prefs.usageJson = all.toString()
        } catch (_: Exception) {
        }
    }

    fun reset() {
        Prefs.usageJson = "{}"
    }

    /** Eine Zeile pro Schlüssel für die Einstellungen. */
    fun lines(): List<String> {
        val all = try {
            JSONObject(Prefs.usageJson)
        } catch (_: Exception) {
            JSONObject()
        }
        return Prefs.apiKeys.mapIndexed { i, k ->
            val o = all.optJSONObject(k.takeLast(6))
            if (o == null) "Schlüssel ${i + 1} (…${k.takeLast(4)}): noch nicht benutzt"
            else {
                val err = if (o.optInt("errors") > 0) ", ${o.optInt("errors")} Fehler (zuletzt ${o.optString("lastError")})" else ""
                "Schlüssel ${i + 1} (…${k.takeLast(4)}): ${o.optInt("calls")} Aufrufe$err"
            }
        }
    }
}
