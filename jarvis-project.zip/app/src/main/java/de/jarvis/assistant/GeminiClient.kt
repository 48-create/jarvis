package de.jarvis.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Ruft die Google-Gemini-REST-API auf (kostenloser Schlüssel von aistudio.google.com). */
object GeminiClient {
    private const val SYSTEM =
        "Du bist JARVIS, ein höflicher, trocken-humorvoller deutscher Sprachassistent im Stil eines " +
            "Butlers. Antworte immer auf Deutsch und kurz (höchstens drei Sätze), ohne Markdown, " +
            "Listen oder Sternchen, weil deine Antwort vorgelesen wird. Sprich den Nutzer gelegentlich " +
            "mit Sir an. Wenn du etwas nicht sicher weißt, sag das ehrlich. Du kannst selbst keine Apps " +
            "bedienen; das erledigt die App separat."

    /** history: Paare aus Rolle ("user" oder "model") und Text. Wirft Exception mit deutscher Meldung. */
    suspend fun ask(history: List<Pair<String, String>>): String = withContext(Dispatchers.IO) {
        val key = Prefs.apiKey
        if (key.isBlank()) {
            throw Exception(
                "Für Gespräche brauche ich einen kostenlosen Gemini-Schlüssel. " +
                    "Trage ihn bitte oben rechts in den Einstellungen ein, Sir."
            )
        }
        val contents = JSONArray()
        for ((role, text) in history) {
            contents.put(
                JSONObject()
                    .put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        val body = JSONObject()
            .put(
                "system_instruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM)))
            )
            .put("contents", contents)

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${Prefs.model}:generateContent")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 90000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""

            if (code !in 200..299) {
                throw Exception(
                    when (code) {
                        400 -> "Die Anfrage wurde abgelehnt. Prüfe den API-Schlüssel in den Einstellungen."
                        401, 403 -> "Der API-Schlüssel wird nicht akzeptiert. Bitte prüfe ihn in den Einstellungen."
                        404 -> "Das KI-Modell „${Prefs.model}“ gibt es nicht (mehr). Ändere den Modellnamen in den Einstellungen."
                        429 -> "Das kostenlose Kontingent ist gerade aufgebraucht. Bitte versuche es später noch einmal."
                        else -> "Der KI-Dienst meldet Fehler $code."
                    }
                )
            }

            val cands = JSONObject(text).optJSONArray("candidates")
            val parts = cands?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            if (parts == null) {
                "Dazu kann ich leider nichts sagen, Sir."
            } else {
                val sb = StringBuilder()
                for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
                sb.toString().trim().ifEmpty { "Dazu habe ich keine Antwort erhalten." }
            }
        } catch (e: java.net.SocketTimeoutException) {
            throw Exception("Der KI-Dienst hat zu lange gebraucht (Zeitüberschreitung). Versuche es noch einmal oder wähle in den Einstellungen ein schnelleres Modell, z. B. gemini-3.5-flash-lite.")
        } catch (e: IOException) {
            throw Exception("Verbindungsfehler zum KI-Dienst: ${e.javaClass.simpleName} ${e.message ?: ""}")
        } catch (e: JSONException) {
            throw Exception("Die Antwort des KI-Dienstes war unverständlich.")
        } finally {
            conn.disconnect()
        }
    }
}
