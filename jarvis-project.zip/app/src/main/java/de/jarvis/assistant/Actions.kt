package de.jarvis.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import androidx.core.content.ContextCompat

data class PendingWa(val name: String, val number: String?, val text: String)

object Actions {
    fun accessibilityEnabled(ctx: Context): Boolean {
        val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return s.contains(ctx.packageName + "/") && s.contains("SendAssistService")
    }

    /** Sucht einen Kontakt nach Namen. Liefert (Anzeigename, Nummer) oder null. */
    fun findContact(ctx: Context, name: String): Pair<String, String>? {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return null
        }
        return try {
            ctx.contentResolver.query(
                Phone.CONTENT_URI,
                arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER),
                "${Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$name%"),
                "${Phone.DISPLAY_NAME} ASC"
            )?.use { c -> if (c.moveToFirst()) c.getString(0) to c.getString(1) else null }
        } catch (e: Exception) {
            null
        }
    }

    /** Wandelt eine Nummer in internationale Ziffern um. Annahme: Nummern ohne Ländervorwahl sind deutsch (+49). */
    fun digits(raw: String): String? {
        val s = raw.filter { it.isDigit() || it == '+' }
        val d = when {
            s.startsWith("+") -> s.drop(1)
            s.startsWith("00") -> s.drop(2)
            s.startsWith("0") -> "49" + s.drop(1)
            else -> s
        }
        return d.filter { it.isDigit() }.ifEmpty { null }
    }

    /** Öffnet WhatsApp mit vorausgefülltem Text. Gesendet wird NICHT automatisch. */
    fun whatsAppIntent(p: PendingWa): Intent =
        if (p.number != null) {
            Intent(Intent.ACTION_VIEW, Uri.parse("whatsapp://send?phone=${p.number}&text=${Uri.encode(p.text)}"))
        } else {
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, p.text)
                setPackage("com.whatsapp")
            }
        }
}
