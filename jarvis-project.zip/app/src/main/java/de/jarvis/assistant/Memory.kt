package de.jarvis.assistant

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Mini-App „Gedächtnis“: dein Lernprofil ansehen, bearbeiten, ergänzen und löschen. */
@Composable
fun MemoryApp() {
    var cat by remember { mutableStateOf("Sonstiges") }
    var edit by remember { mutableStateOf<Fact?>(null) }
    var confirmClear by remember { mutableStateOf(false) }
    var auto by remember { mutableStateOf(Prefs.autoLearn) }
    var hist by remember { mutableStateOf(Prefs.useHistory) }
    val day = remember { SimpleDateFormat("d.M.yy", Locale.GERMANY) }

    Row(verticalAlignment = Alignment.CenterVertically) {
        Switch(checked = auto, onCheckedChange = { auto = it; Prefs.autoLearn = it })
        Spacer(Modifier.width(10.dp))
        Column {
            Text("Automatisch lernen", color = TextC, fontSize = 14.sp)
            Text(
                "JARVIS merkt sich dauerhafte Dinge aus Gesprächen (Vorlieben, Gewohnheiten, Korrekturen). Dafür wird die Nachricht kurz an die KI geschickt.",
                color = TextC.copy(alpha = 0.5f), fontSize = 11.sp
            )
        }
    }
    Spacer(Modifier.height(10.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        Switch(checked = hist, onCheckedChange = { hist = it; Prefs.useHistory = it })
        Spacer(Modifier.width(10.dp))
        Column {
            Text("Frühere Gespräche berücksichtigen", color = TextC, fontSize = 14.sp)
            Text(
                "Bei passenden Themen sucht JARVIS lokal in deinen ${Chats.chats.size} gespeicherten Chats und gibt kurze Ausschnitte an die KI.",
                color = TextC.copy(alpha = 0.5f), fontSize = 11.sp
            )
        }
    }

    Spacer(Modifier.height(18.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Brain.CATS.forEach { c -> HudButton(c.uppercase(Locale.GERMAN), filled = c == cat) { cat = c } }
    }
    Spacer(Modifier.height(8.dp))
    AddRow("Neue Information über dich …") { Brain.add(it, cat, "manual") }

    if (Brain.facts.isEmpty()) {
        Body("Noch nichts gespeichert. Sage: „Merk dir, dass ich Kaffee ohne Milch trinke“.", dim = true)
    }
    Brain.CATS.forEach { c ->
        val l = Brain.facts.filter { it.cat == c }
        if (l.isNotEmpty()) {
            Text(
                c.uppercase(Locale.GERMAN), color = Gold, fontSize = 11.sp, letterSpacing = 2.sp,
                modifier = Modifier.padding(top = 10.dp, bottom = 6.dp)
            )
            l.forEach { f ->
                key(f.id) {
                    ItemRow {
                        Column(Modifier.weight(1f).clickable { edit = f }.padding(vertical = 8.dp)) {
                            Body(f.text)
                            if (f.source == "auto") {
                                Text("gelernt · ${day.format(Date(f.updated))}", color = Cyan.copy(alpha = 0.6f), fontSize = 10.sp)
                            }
                        }
                        Text(
                            "⇄", color = Gold.copy(alpha = 0.8f), fontSize = 16.sp,
                            modifier = Modifier.clickable {
                                val n = Brain.CATS[(Brain.CATS.indexOf(f.cat) + 1) % Brain.CATS.size]
                                Brain.setCat(f.id, n)
                            }.padding(8.dp)
                        )
                        DeleteX { Brain.remove(f.id) }
                    }
                }
            }
        }
    }

    Spacer(Modifier.height(10.dp))
    Text(
        "⇄ wechselt die Kategorie, Antippen bearbeitet den Eintrag. Alles bleibt auf deinem Handy und ist in der Sicherung enthalten.",
        color = TextC.copy(alpha = 0.5f), fontSize = 11.sp
    )
    if (Brain.facts.isNotEmpty()) {
        Spacer(Modifier.height(12.dp))
        HudButton("ALLES VERGESSEN", accent = Gold) { confirmClear = true }
    }
    Spacer(Modifier.height(20.dp))

    edit?.let { f -> EditDialog("Eintrag bearbeiten", f.text, { Brain.edit(f.id, it) }) { edit = null } }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            containerColor = Color(0xFF07101C),
            title = { Text("Alles vergessen?") },
            text = { Text("Alle ${Brain.facts.size} Einträge werden endgültig gelöscht. Deine Chats bleiben erhalten.") },
            confirmButton = {
                TextButton(onClick = { Brain.clear(); confirmClear = false }) { Text("Alles löschen", color = Gold) }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Abbrechen") } }
        )
    }
}
