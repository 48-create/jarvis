package de.jarvis.assistant

import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

data class Fact(val id: Long, val text: String, val created: Long)

/**
 * Langzeitgedächtnis: JARVIS merkt sich dauerhafte Dinge aus deinen Chats (Name, Schule, Hobbys, Vorlieben, Pläne …).
 * - automatisch: wenn du etwas Persönliches sagst, extrahiert die KI im Hintergrund die Fakten
 * - ausdrücklich: „Merk dir, dass …“, „Vergiss …“, „Was weißt du über mich?“
 * Die Einträge fließen in jede KI-Antwort ein, sind im Dashboard verwaltbar und Teil der Sicherung.
 */
object Memory {
    const val NAME = "memory"
    private val I = RegexOption.IGNORE_CASE

    val facts = mutableStateListOf<Fact>()
    private var loaded = false
    private var seq = 0L
    private var lastLearn = 0L
    private fun newId(): Long = System.currentTimeMillis() * 100 + (seq++ % 100)

    fun init() {
        if (loaded) return
        loaded = true
        load()
    }

    fun load() {
        facts.clear()
        val a = Store.read(NAME)
        for (i in 0 until a.length()) {
            try {
                val o = a.getJSONObject(i)
                facts.add(Fact(o.getLong("id"), o.getString("text"), o.optLong("created")))
            } catch (_: Exception) {
            }
        }
    }

    private fun save() {
        val a = JSONArray()
        facts.forEach { a.put(JSONObject().put("id", it.id).put("text", it.text).put("created", it.created)) }
        Store.write(NAME, a)
    }

    private fun norm(s: String) = s.lowercase(Locale.GERMAN).replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()

    /** true = etwas Neues wurde gespeichert. Doppelte werden erkannt, ausführlichere Fassungen ersetzen kürzere. */
    fun add(text: String): Boolean {
        val t = text.trim().trimEnd('.', '!').trim()
        if (t.length < 4) return false
        val n = norm(t)
        for (i in facts.indices) {
            val m = norm(facts[i].text)
            if (m == n || m.contains(n)) return false
            if (n.contains(m)) {
                facts[i] = facts[i].copy(text = t); save(); return true
            }
        }
        facts.add(Fact(newId(), t, System.currentTimeMillis()))
        while (facts.size > 300) facts.removeAt(0)
        save()
        return true
    }

    fun edit(id: Long, text: String) {
        val i = facts.indexOfFirst { it.id == id }
        if (i >= 0 && text.isNotBlank()) {
            facts[i] = facts[i].copy(text = text.trim()); save()
        }
    }

    fun del(id: Long) {
        facts.removeAll { it.id == id }; save()
    }

    fun clear(): Int {
        val n = facts.size
        facts.clear(); save(); return n
    }

    /** Text für die System-Anweisung der KI: Gedächtnis plus Titel früherer Chats. */
    fun context(): String {
        val sb = StringBuilder()
        val f = facts.takeLast(40).reversed()
        if (f.isNotEmpty()) {
            sb.append("Gedächtnis über den Nutzer (nutze es natürlich, zähle es nicht ungefragt auf): ")
            var len = 0
            for (x in f) {
                if (len + x.text.length > 1800) break
                sb.append(x.text).append("; ")
                len += x.text.length + 2
            }
            sb.append(". ")
        }
        sb.append(Chats.recentContext())
        return sb.toString()
    }

    // ---------- automatisches Lernen ----------

    private val personal = Regex(
        "\\b(ich bin|ich heiße|ich heisse|mein|meine|meinen|meinem|meiner|ich habe|ich hab|ich mag|ich liebe|ich hasse|" +
            "ich wohne|ich komme aus|ich gehe|ich arbeite|ich lerne|ich spiele|ich esse|ich trinke|ich studiere|" +
            "ich werde|ich muss|ich will|ich möchte|ich brauche|ich schreibe|ich habe morgen)\\b", I
    )

    fun looksPersonal(t: String): Boolean = t.length in 12..600 && !t.startsWith("📷") && personal.containsMatchIn(t)

    private const val EXTRACT_SYSTEM =
        "Du pflegst das Gedächtnis eines Sprachassistenten. Aus der Nachricht des Nutzers extrahierst du nur dauerhafte, " +
            "später nützliche Fakten über den Nutzer: Name, Familie, Freunde, Haustiere, Schule, Klasse, Fächer, Prüfungen und " +
            "Termine mit Datum, Hobbys, Vorlieben, Abneigungen, Gewohnheiten, Wohnort, Beruf, Ziele. " +
            "Keine Fragen, keinen Smalltalk, keine einmaligen Befehle, nichts über den Assistenten. " +
            "Niemals Passwörter, Zugangsdaten, Zahlungsdaten, Ausweisnummern oder Adressen speichern. " +
            "Formuliere jeden Fakt als kurzen deutschen Satz mit Beginn „Der Nutzer“. Wenn nichts Dauerhaftes vorkommt, " +
            "gib eine leere Liste. Antworte NUR mit JSON: {\"facts\":[\"...\"]}"

    /** Lernt im Hintergrund aus einer Nutzer-Nachricht. Fehler werden still ignoriert. */
    suspend fun learn(user: String) {
        if (!Prefs.autoMemory) return
        val now = System.currentTimeMillis()
        if (now - lastLearn < 10_000L) return
        lastLearn = now
        try {
            val raw = GeminiClient.generate(EXTRACT_SYSTEM, "Nachricht des Nutzers: $user", null, true)
            val clean = raw.replace(Regex("```(?:json)?"), "").trim()
            val a = clean.indexOf('{')
            val b = clean.lastIndexOf('}')
            if (a < 0 || b <= a) return
            val arr = JSONObject(clean.substring(a, b + 1)).optJSONArray("facts") ?: return
            for (i in 0 until minOf(arr.length(), 3)) add(arr.optString(i))
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (_: Exception) {
        }
    }

    // ---------- ausdrückliche Sprachbefehle ----------

    private val wake = Regex("^(?:hey |hallo |hi |ok )?jarvis[,.:!]?\\s*", I)
    private val remember = Regex("^(?:bitte\\s+)?merk(?:e)?\\s+dir\\s*[:,]?\\s*(?:bitte\\s+)?(?:dass\\s+)?(.+)", I)
    private val forgetAll = Regex("^(?:bitte\\s+)?(?:vergiss|lösche|lösch|leere)\\s+(?:bitte\\s+)?(?:alles|dein gedächtnis|mein gedächtnis|das gedächtnis|alle erinnerungen an mich)", I)
    private val forget = Regex("^(?:bitte\\s+)?vergiss\\s+(?:bitte\\s+)?(?:dass\\s+|was ich (?:dir )?(?:über\\s+)?)?(.+)", I)
    private val ask = Regex(
        "was\\s+weißt\\s+du\\s+(?:alles\\s+|so\\s+)?(?:über|von)\\s+mich|was\\s+hast\\s+du\\s+dir\\s+(?:alles\\s+)?(?:über\\s+mich\\s+)?gemerkt|woran\\s+erinnerst\\s+du\\s+dich", I
    )

    /** Liefert die Antwort, wenn der Satz ein Gedächtnis-Befehl war, sonst null. */
    fun handleCommand(raw: String): String? {
        val t = raw.trim().replace(wake, "").trim().trimEnd('.', '!', '?')
        if (t.isEmpty()) return null
        val a = Prefs.title.ifBlank { "Sir" }

        if (ask.containsMatchIn(t)) {
            if (facts.isEmpty()) return "Bisher habe ich mir noch nichts gemerkt, $a. Sage zum Beispiel: Merk dir, dass ich Mathe schwierig finde."
            val top = facts.takeLast(6).reversed().joinToString(". ") { it.text.trimEnd('.') }
            return "Ich habe mir ${facts.size} Dinge gemerkt. Zuletzt: $top."
        }
        if (forgetAll.containsMatchIn(t)) {
            val n = clear()
            return if (n == 0) "Mein Gedächtnis ist bereits leer, $a." else "Erledigt, $a. Ich habe $n Einträge vergessen."
        }
        remember.find(t)?.let { m ->
            val body = m.groupValues[1].trim()
            if (Regex("\\b(termin|wecker|timer|erinner\\w*)\\b", I).containsMatchIn(body)) return null
            if (body.length < 4) return null
            val text = body.replaceFirstChar { it.uppercase() }
            return if (add(text)) "Gemerkt, $a." else "Das wusste ich bereits, $a."
        }
        forget.find(t)?.let { m ->
            val words = norm(m.groupValues[1]).split(' ').filter { it.length >= 3 }
            if (words.isEmpty()) return null
            var best: Fact? = null
            var bestScore = 0
            for (f in facts) {
                val n = norm(f.text)
                val score = words.count { n.contains(it) }
                if (score > bestScore) {
                    best = f; bestScore = score
                }
            }
            val b = best
            if (b != null && bestScore * 2 >= words.size) {
                del(b.id)
                return "Vergessen: ${b.text.trimEnd('.')}."
            }
        }
        return null
    }
}
