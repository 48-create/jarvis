package de.jarvis.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.max

/** Foto-Hilfe: Aufgabe fotografieren oder aus der Galerie wählen, Gemini liest und löst sie. */
object Photo {
    private const val MAX_SIDE = 1600

    fun system(): String {
        val title = Prefs.title.ifBlank { "Sir" }
        return "Du bist J.A.R.V.I.S., jetzt als geduldiger Nachhilfelehrer. Der Nutzer schickt ein Foto, meist eine Schul- oder " +
            "Studienaufgabe. Lies zuerst den Text auf dem Bild genau ab und prüfe Zahlen und Einheiten. Löse die Aufgabe dann Schritt " +
            "für Schritt, mit einer kurzen Begründung je Schritt, und nenne am Ende das Ergebnis deutlich nach dem Wort Ergebnis. " +
            "Bei mehreren Aufgaben bearbeite jede einzeln mit ihrer Nummer. Ist etwas unleserlich oder fehlt eine Angabe, sage genau, " +
            "was fehlt, statt zu raten. Erkläre so, dass ein Schüler den Weg selbst nachvollziehen kann. Schreibe auf Deutsch (bei " +
            "Fremdsprachen-Aufgaben in der Sprache der Aufgabe, mit deutscher Erklärung), ohne Markdown-Sternchen und ohne Überschriften " +
            "mit Rautezeichen. Rechnungen als normale Zeilen, Brüche als a/b, Wurzeln als √, Hochzahlen als x². " +
            "Ist auf dem Foto keine Aufgabe erkennbar, beschreibe kurz, was du siehst, und frage, was du tun sollst. " +
            "Die Anrede \"$title\" höchstens einmal und ohne Kommas."
    }

    /** Liest das Bild, dreht es richtig, verkleinert es und liefert JPEG als Base64. Läuft im Hintergrund-Thread. */
    fun encode(ctx: Context, uri: Uri): String {
        val res = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        res.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw Exception("Das Bild konnte nicht gelesen werden.")
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = res.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw Exception("Das Bild konnte nicht gelesen werden.")

        val orientation = try {
            res.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (_: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
        }
        if (!m.isIdentity) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)

        val longest = max(bmp.width, bmp.height)
        if (longest > MAX_SIDE) {
            val s = MAX_SIDE.toFloat() / longest
            bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true)
        }
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    /** Alte Kamerafotos aus dem Zwischenspeicher entfernen. */
    fun cleanup(ctx: Context) {
        try {
            val dir = File(ctx.cacheDir, "photos")
            val now = System.currentTimeMillis()
            dir.listFiles()?.forEach { if (now - it.lastModified() > 86_400_000L) it.delete() }
        } catch (_: Exception) {
        }
    }
}

@Composable
fun PhotoButton() {
    val ctx = LocalContext.current
    var show by remember { mutableStateOf(false) }
    var question by rememberSaveable { mutableStateOf("") }
    var camUri by rememberSaveable { mutableStateOf<Uri?>(null) }

    val cam = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = camUri
        if (ok && u != null) {
            JarvisEngine.askPhoto(u, question)
            question = ""
        }
    }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            JarvisEngine.askPhoto(uri, question)
            question = ""
        }
    }

    Text(
        "📷", fontSize = 24.sp,
        modifier = Modifier.clickable { show = true }.padding(horizontal = 6.dp, vertical = 8.dp)
    )

    if (show) {
        AlertDialog(
            onDismissRequest = { show = false },
            containerColor = Color(0xFF07101C),
            title = { Text("Foto-Hilfe") },
            text = {
                Column {
                    Text("Fotografiere eine Aufgabe oder wähle ein Bild. JARVIS liest sie und erklärt die Lösung im Chat.", fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = question, onValueChange = { question = it },
                        label = { Text("Was soll ich tun? (optional)") },
                        placeholder = { Text("z. B. nur Aufgabe 3 lösen") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Cyan, unfocusedBorderColor = Cyan.copy(alpha = 0.35f), cursorColor = Cyan,
                            focusedTextColor = TextC, unfocusedTextColor = TextC
                        )
                    )
                    Spacer(Modifier.height(6.dp))
                    Text("Tipp: gutes Licht, Blatt gerade halten, Schrift scharf.", fontSize = 11.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    show = false
                    try {
                        Photo.cleanup(ctx)
                        val dir = File(ctx.cacheDir, "photos").apply { mkdirs() }
                        val f = File(dir, "aufgabe-${System.currentTimeMillis()}.jpg")
                        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
                        camUri = uri
                        cam.launch(uri)
                    } catch (e: Exception) {
                        Toast.makeText(ctx, "Die Kamera konnte nicht gestartet werden.", Toast.LENGTH_SHORT).show()
                    }
                }) { Text("Kamera") }
            },
            dismissButton = {
                Column {
                    TextButton(onClick = {
                        show = false
                        try {
                            gallery.launch("image/*")
                        } catch (e: Exception) {
                            Toast.makeText(ctx, "Keine Galerie gefunden.", Toast.LENGTH_SHORT).show()
                        }
                    }) { Text("Galerie") }
                    TextButton(onClick = { show = false }) { Text("Abbrechen") }
                }
            }
        )
    }
}
