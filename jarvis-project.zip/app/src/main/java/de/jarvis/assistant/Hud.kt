package de.jarvis.assistant

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

internal fun hudLabel(s: Status): String = when (s) {
    Status.IDLE -> "BEREIT"
    Status.WAKE -> "STANDBY · HEY JARVIS"
    Status.LISTENING -> "ICH HÖRE ZU"
    Status.THINKING -> "VERARBEITE"
    Status.SPEAKING -> "SPRECHE"
}

private fun DrawScope.ring(c: Offset, rad: Float, rot: Float, segs: Int, frac: Float, w: Float, col: Color) {
    rotate(rot, pivot = c) {
        val step = 360f / segs
        for (i in 0 until segs) {
            drawArc(
                color = col,
                startAngle = i * step,
                sweepAngle = step * frac,
                useCenter = false,
                topLeft = Offset(c.x - rad, c.y - rad),
                size = Size(rad * 2f, rad * 2f),
                style = Stroke(width = w, cap = StrokeCap.Round)
            )
        }
    }
}

private fun DrawScope.ticks(c: Offset, rad: Float, rot: Float, count: Int, col: Color) {
    rotate(rot, pivot = c) {
        for (i in 0 until count) {
            val a = (i * 2.0 * PI / count).toFloat()
            val long = i % 6 == 0
            val len = if (long) rad * 0.07f else rad * 0.035f
            drawLine(
                col,
                Offset(c.x + cos(a) * rad, c.y + sin(a) * rad),
                Offset(c.x + cos(a) * (rad - len), c.y + sin(a) * (rad - len)),
                strokeWidth = if (long) 3f else 1.5f
            )
        }
    }
}

/** Der schwebende Jarvis-Orb: Glow, rotierende Ringe, Skala und Sprachwelle. */
@Composable
fun JarvisOrb(status: Status, diameter: Dp, onClick: () -> Unit) {
    val target = when (status) {
        Status.LISTENING -> Gold
        Status.THINKING -> Color(0xFFB48CFF)
        Status.IDLE -> Cyan.copy(alpha = 0.75f)
        else -> Cyan
    }
    val color by animateColorAsState(target, tween(450), label = "c")
    val amp by animateFloatAsState(
        when (status) {
            Status.SPEAKING -> 1f
            Status.LISTENING -> 0.55f
            Status.THINKING -> 0.2f
            else -> 0.08f
        },
        tween(500), label = "a"
    )
    val glow by animateFloatAsState(if (status == Status.IDLE) 0.45f else 1f, tween(600), label = "g")

    val t = rememberInfiniteTransition(label = "orb")
    val r1 by t.animateFloat(0f, 360f, infiniteRepeatable(tween(16000, easing = LinearEasing)), label = "r1")
    val r2 by t.animateFloat(360f, 0f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "r2")
    val r3 by t.animateFloat(0f, 360f, infiniteRepeatable(tween(4200, easing = LinearEasing)), label = "r3")
    val ph by t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(1600, easing = LinearEasing)), label = "ph")
    val pulse by t.animateFloat(
        0.92f, 1.08f,
        infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pu"
    )

    Canvas(
        Modifier
            .size(diameter)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClick() }
    ) {
        val c = center
        val r = size.minDimension / 2f

        drawCircle(
            Brush.radialGradient(listOf(color.copy(alpha = 0.32f * glow), Color.Transparent), center = c, radius = r),
            radius = r, center = c
        )
        ticks(c, r * 0.97f, r1 * 0.3f, 72, color.copy(alpha = 0.55f * glow))
        ring(c, r * 0.86f, r1, 3, 0.55f, 2.dp.toPx(), color.copy(alpha = 0.85f))
        ring(c, r * 0.74f, r2, 5, 0.35f, 4.dp.toPx(), color.copy(alpha = 0.55f * glow + 0.2f))
        drawCircle(color.copy(alpha = 0.35f), radius = r * 0.62f, center = c, style = Stroke(1.dp.toPx()))
        if (status == Status.THINKING) {
            ring(c, r * 0.58f, r3 * 3f, 3, 0.22f, 5.dp.toPx(), color)
        }

        // Sprachwelle
        val path = Path()
        val n = 160
        for (i in 0..n) {
            val a = i.toFloat() / n * 2f * PI.toFloat()
            val k = amp * r * 0.09f * (sin(a * 5f + ph) + 0.6f * sin(a * 9f - ph * 1.3f))
            val rad = r * 0.42f + k
            val x = c.x + cos(a) * rad
            val y = c.y + sin(a) * rad
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        drawPath(path, color.copy(alpha = 0.10f))
        drawPath(path, color.copy(alpha = 0.95f), style = Stroke(2.5.dp.toPx(), cap = StrokeCap.Round))

        // Kern
        val cr = r * 0.26f * pulse
        drawCircle(
            Brush.radialGradient(
                listOf(Color.White.copy(alpha = 0.95f), color.copy(alpha = 0.8f), Color.Transparent),
                center = c, radius = cr
            ),
            radius = cr, center = c
        )
    }
}

/** Text, der Zeichen für Zeichen erscheint. */
@Composable
fun TypeText(text: String, style: TextStyle, modifier: Modifier = Modifier, align: TextAlign = TextAlign.Start) {
    var shown by remember(text) { mutableStateOf(0) }
    LaunchedEffect(text) {
        shown = 0
        val step = maxOf(1, text.length / 120)
        while (shown < text.length) {
            delay(22)
            shown = minOf(text.length, shown + step)
        }
    }
    Text(text.take(shown), style = style, modifier = modifier, textAlign = align)
}

@Composable
fun HudButton(
    text: String,
    modifier: Modifier = Modifier,
    accent: Color = Cyan,
    filled: Boolean = false,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .clip(shape)
            .background(if (filled) accent else Color.Transparent)
            .border(1.dp, if (filled) Color.Transparent else accent.copy(alpha = 0.45f), shape)
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (filled) Dark else accent,
            fontSize = 12.sp,
            letterSpacing = 1.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
        )
    }
}

/** Ruhiger Hintergrund: dunkler Verlauf mit einem leisen Schimmer oben. */
@Composable
fun HudBackground() {
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFF03060D), Color(0xFF060E1B))))
        val c = Offset(size.width / 2f, 0f)
        val r = size.width * 0.9f
        drawCircle(
            Brush.radialGradient(listOf(Cyan.copy(alpha = 0.10f), Color.Transparent), center = c, radius = r),
            radius = r, center = c
        )
    }
}
