# JARVIS (Android, Kotlin + Jetpack Compose)
Build: `gradle assembleDebug` (JDK 17, Gradle 8.7, Android SDK 34).
Details und Grenzen siehe Chat-Anleitung.
