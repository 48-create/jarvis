# JARVIS (Android, Kotlin + Jetpack Compose)
Build: `gradle assembleDebug` (JDK 17, Gradle 8.7, Android SDK 34).

## Version 1.1 (Update 1)
- Dauerhafte Daten: `filesDir/data/*.json` (Notizen, Aufgaben, Termine, Erinnerungen). Überstehen APK-Updates.
- Dashboard (Reiter unten) mit Uhr/Wecker, Wetter, Kalender, Aufgaben, Notizen, Erinnerungen, News, Stoppuhr/Timer, Rechner; Kacheln anordnen.
- Sprachbefehle für alle Mini-Apps (erstellen, ändern, löschen, anzeigen), siehe MiniVoice.kt.
- Mehrere Gemini-Schlüssel, automatischer Wechsel bei Ausfall/Limit, Reserve-Modelle, automatische Modellwahl, Verbrauchsanzeige.
- Sicherung/Wiederherstellung der Mini-App-Daten (Einstellungen).

## APK-Update ohne Deinstallation
Immer mit demselben Signaturschlüssel bauen und `versionCode` erhöhen. Mit wechselnden Debug-Schlüsseln (anderer PC) lässt Android das Update nicht zu.
