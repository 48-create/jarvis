# JARVIS (Android, Kotlin + Jetpack Compose)
Build: `gradle assembleDebug` (JDK 17, Gradle 8.7, Android SDK 34).

## Version 1.1 (Update 1)
- Dauerhafte Daten: `filesDir/data/*.json` (Notizen, Aufgaben, Termine, Erinnerungen). Überstehen APK-Updates.
- Dashboard (Reiter unten) mit Uhr/Wecker, Wetter, Kalender, Aufgaben, Notizen, Erinnerungen, News, Stoppuhr/Timer, Rechner; Kacheln anordnen.
- Sprachbefehle für alle Mini-Apps (erstellen, ändern, löschen, anzeigen), siehe MiniVoice.kt.
- Mehrere Gemini-Schlüssel, automatischer Wechsel bei Ausfall/Limit, Reserve-Modelle, automatische Modellwahl, Verbrauchsanzeige.
- Sicherung/Wiederherstellung der Mini-App-Daten (Einstellungen).

## APK-Update ohne Deinstallation
Immer mit demselben Signaturschlüssel bauen und `versionCode` erhöhen. Mit wechselnden Debug-Schlüsseln (anderer PC) lässt Android das Update nicht zu.

## Version 1.2
- Mit Gemini-Schlüssel versteht die KI jeden Satz und führt ihn aus (Dashboard, Wecker, Timer, Wetter, News).
- AiActions.kt übersetzt gesprochene Sätze in Aktionen (Termin, Wecker, Timer, Erinnerung, Notiz, Aufgabe, verschieben, löschen). Die festen Muster aus MiniVoice sind nur noch Reserve ohne KI.
- Jarvis kennt jetzt die Dashboard-Daten und kann Fragen dazu beantworten („Was steht morgen an?“).
- Wecker und Timer: Jarvis meldet „gestellt“ nur noch, wenn der Start wirklich geklappt hat.
